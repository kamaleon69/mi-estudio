// Mi Estudio · Asistente en cualquier página (documentos, Word/Docs online, PDFs, webs)
// Panel lateral con chat de IA + 🔍 lupa para seleccionar una zona de la pantalla y preguntar por ella.
(() => {
  if(window.__msHelper){ window.__msHelper.toggle(); return; }
  const api = (typeof browser !== 'undefined' && browser.runtime) ? browser : chrome;
  const host = document.createElement('div'); host.id = '__msHelperHost';
  host.style.cssText = 'all:initial;position:fixed;z-index:2147483647;top:0;right:0;';
  const root = host.attachShadow({mode: 'open'});
  root.innerHTML = `<style>
    *{box-sizing:border-box;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif}
    .panel{position:fixed;top:0;right:0;width:min(400px,100vw);height:100vh;background:#fff;color:#111827;border-left:1px solid #d1d5db;box-shadow:-6px 0 24px rgba(0,0,0,.18);display:flex;flex-direction:column}
    .panel.off{display:none}
    .h{display:flex;align-items:center;gap:8px;padding:10px 12px;border-bottom:1px solid #e5e7eb}
    .h b{flex:1;font-size:15px}
    .ib{border:1px solid #d1d5db;background:#fff;border-radius:8px;height:30px;min-width:30px;padding:0 8px;cursor:pointer;font-size:13px}
    .ib:hover{background:#f3f4f6}
    .msgs{flex:1;overflow:auto;padding:12px;display:flex;flex-direction:column;gap:10px;background:#f8fafc}
    .m{max-width:92%;padding:9px 12px;border-radius:14px;font-size:14px;line-height:1.5;white-space:pre-wrap;word-wrap:break-word}
    .m.u{align-self:flex-end;background:#2563eb;color:#fff;border-bottom-right-radius:4px}
    .m.a{align-self:flex-start;background:#fff;border:1px solid #e2e8f0;border-bottom-left-radius:4px}
    .m.a code{background:#f1f5f9;padding:1px 4px;border-radius:4px;font-family:ui-monospace,monospace;font-size:12.5px}
    .m.a pre{background:#0f172a;color:#e2e8f0;padding:8px;border-radius:8px;overflow:auto;white-space:pre}
    .m img{display:block;max-width:100%;border-radius:8px;margin-bottom:6px}
    .m.e{align-self:stretch;background:#fef2f2;border:1px solid #fca5a5;color:#991b1b}
    .hint{color:#64748b;font-size:13px;line-height:1.5;padding:4px 2px}
    .hint b{color:#334155}
    .chips{display:flex;flex-wrap:wrap;gap:6px;padding:8px 12px 0;background:#fff}
    .chip{border:1px solid #cbd5e1;background:#f8fafc;border-radius:999px;padding:5px 10px;font-size:12.5px;cursor:pointer}
    .chip:hover{background:#eef2ff;border-color:#a5b4fc}
    .att{display:none;align-items:center;gap:8px;margin:8px 12px 0;padding:6px 8px;border:1px solid #c7d2fe;background:#eef2ff;border-radius:10px;font-size:12.5px;color:#3730a3}
    .att.on{display:flex} .att img{height:40px;border-radius:6px} .att span{flex:1} .att button{border:0;background:none;cursor:pointer;font-size:14px}
    .in{display:flex;gap:8px;padding:10px 12px 12px;background:#fff;border-top:1px solid #e5e7eb;align-items:flex-end}
    textarea{flex:1;resize:none;min-height:42px;max-height:140px;padding:10px;border:1px solid #cbd5e1;border-radius:12px;font-size:14px;outline:none}
    textarea:focus{border-color:#2563eb;box-shadow:0 0 0 3px rgba(37,99,235,.15)}
    .send{width:42px;height:42px;border:0;border-radius:12px;background:#2563eb;color:#fff;font-size:18px;cursor:pointer}
    .send:disabled{opacity:.5;cursor:wait}
    .lens{width:42px;height:42px;border:1px solid #cbd5e1;border-radius:12px;background:#fff;font-size:18px;cursor:pointer}
    .dots::after{content:'…';animation:d 1s steps(3) infinite}
    @keyframes d{0%{content:'.'}33%{content:'..'}66%{content:'...'}}
    .sel{position:fixed;inset:0;cursor:crosshair;background:rgba(15,23,42,.25);display:none}
    .sel.on{display:block}
    .box{position:fixed;border:2px solid #22c55e;background:rgba(34,197,94,.12);box-shadow:0 0 0 9999px rgba(15,23,42,.35)}
    .tip{position:fixed;left:50%;top:16px;transform:translateX(-50%);background:#0f172a;color:#fff;padding:8px 14px;border-radius:10px;font-size:14px}
  </style>
  <div class="sel"><div class="tip">🔍 Arrastra para seleccionar la zona · Esc para cancelar</div><div class="box" style="display:none"></div></div>
  <div class="panel">
    <div class="h"><span>💬</span><b>Asistente · Mi Estudio</b><button class="ib" data-new title="Nueva conversación">🗑</button><button class="ib" data-x title="Cerrar">✕</button></div>
    <div class="msgs"><div class="hint">Pregúntame lo que quieras sobre este documento o página.<br>• <b>🔍 Lupa</b>: selecciona una zona de la pantalla (un párrafo, un ejercicio, una imagen) y pregunta por ella.<br>• Si <b>seleccionas texto</b> en la página, lo uso como contexto.<br>• Te explico, resumo, corrijo y te ayudo a entenderlo; el trabajo lo haces tú.</div></div>
    <div class="chips"><span class="chip" data-q="Explícame esto de forma sencilla.">Explícamelo</span><span class="chip" data-q="Hazme un resumen con los puntos clave.">Resumir</span><span class="chip" data-q="Revisa la ortografía y la redacción y dime qué mejorar (sin reescribirlo entero).">Revisar redacción</span><span class="chip" data-q="Hazme 3 preguntas para comprobar si lo he entendido.">Ponme a prueba</span></div>
    <div class="att"><img alt=""><span></span><button title="Quitar">✕</button></div>
    <div class="in"><button class="lens" title="Lupa: seleccionar una zona de la pantalla">🔍</button><textarea placeholder="Escribe tu pregunta… (Enter para enviar)"></textarea><button class="send" title="Enviar">➤</button></div>
  </div>`;
  const $ = s => root.querySelector(s);
  const panel = $('.panel'), msgs = $('.msgs'), ta = $('textarea'), sendB = $('.send'), att = $('.att');
  let history = [], image = null, busy = false;
  const esc = s => String(s).replace(/[&<>"]/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;'}[c]));
  const md = s => esc(s).replace(/```([\s\S]*?)```/g, (_, c) => `<pre>${c.replace(/^\w*\n/, '')}</pre>`).replace(/`([^`\n]+)`/g, '<code>$1</code>').replace(/\*\*([^*\n]+)\*\*/g, '<b>$1</b>').replace(/^#{1,4}\s*(.+)$/gm, '<b>$1</b>').replace(/^\s*[-*]\s+/gm, '• ');
  const send = m => new Promise(res => { try{ const p = api.runtime.sendMessage(m, r => res(r)); if(p && p.then) p.then(res, e => res({error: e.message})); }catch(e){ res({error: e.message}); } });
  function bubble(cls, html){ const d = document.createElement('div'); d.className = 'm ' + cls; d.innerHTML = html; msgs.appendChild(d); msgs.scrollTop = msgs.scrollHeight; return d; }
  function setImage(url){ image = url; att.classList.toggle('on', !!url); if(url){ att.querySelector('img').src = url; att.querySelector('span').textContent = 'Zona seleccionada con la lupa'; } }
  att.querySelector('button').onclick = () => setImage(null);
  function selectedText(){
    let t = ''; try{ t = String(getSelection() || ''); }catch(e){}
    if(!t) for(const f of document.querySelectorAll('iframe')){ try{ t = String(f.contentWindow.getSelection() || ''); if(t) break; }catch(e){} }
    return t.trim().slice(0, 6000);
  }
  let lastSel = null;
  document.addEventListener('selectionchange', () => { const t = selectedText(); if(t) lastSel = {t, at: Date.now()}; });
  async function ask(q){
    q = (q || '').trim(); if(busy || (!q && !image)) return;
    let sel = selectedText(); if(!sel && lastSel && Date.now() - lastSel.at < 120000) sel = lastSel.t; lastSel = null;
    const shown = (image ? `<img src="${image}">` : '') + esc(q || 'Explícame lo que hay en la zona seleccionada.') + (sel ? `<div style="opacity:.8;font-size:12px;margin-top:4px">📎 con el texto seleccionado (${sel.length} caracteres)</div>` : '');
    bubble('u', shown);
    const turn = {role: 'user', text: (q || 'Explícame lo que hay en la imagen seleccionada.') + (sel ? '\n\n--- TEXTO SELECCIONADO EN LA PÁGINA ---\n' + sel : ''), image};
    history.push(turn); ta.value = ''; setImage(null);
    busy = true; sendB.disabled = true;
    const wait = bubble('a', '<span class="dots">Pensando</span>');
    const r = await send({type: 'helperChat', history: history.slice(-12), title: document.title.slice(0, 120), url: location.hostname});
    busy = false; sendB.disabled = false;
    if(!r || r.error){ wait.className = 'm e'; wait.innerHTML = esc((r && r.error) || 'No se pudo contactar con la IA.'); history.pop(); return; }
    wait.innerHTML = md(r.text || '(sin respuesta)');
    history.push({role: 'assistant', text: r.text || ''});
    for(const t of history) if(t.role === 'user' && t !== turn) t.image = null;   // solo se reenvía la imagen de la última pregunta
  }
  sendB.onclick = () => ask(ta.value);
  ta.addEventListener('keydown', e => { if(e.key === 'Enter' && !e.shiftKey){ e.preventDefault(); ask(ta.value); } e.stopPropagation(); }, true);
  ta.addEventListener('keyup', e => e.stopPropagation(), true); ta.addEventListener('keypress', e => e.stopPropagation(), true);
  root.querySelectorAll('.chip').forEach(c => c.onclick = () => ask(c.dataset.q));
  $('[data-x]').onclick = () => toggle(false);
  $('[data-new]').onclick = () => { history = []; msgs.querySelectorAll('.m').forEach(m => m.remove()); setImage(null); };

  // ---------- lupa ----------
  const sel = $('.sel'), box = $('.box');
  let start = null;
  async function lens(){
    if(busy) return;
    sel.classList.add('on'); box.style.display = 'none';
  }
  $('.lens').onclick = lens;
  sel.addEventListener('mousedown', e => { start = [e.clientX, e.clientY]; Object.assign(box.style, {display: 'block', left: e.clientX + 'px', top: e.clientY + 'px', width: '0px', height: '0px'}); });
  sel.addEventListener('mousemove', e => { if(!start) return; const x = Math.min(start[0], e.clientX), y = Math.min(start[1], e.clientY); Object.assign(box.style, {left: x + 'px', top: y + 'px', width: Math.abs(e.clientX - start[0]) + 'px', height: Math.abs(e.clientY - start[1]) + 'px'}); });
  sel.addEventListener('mouseup', async e => {
    if(!start) return;
    const x = Math.min(start[0], e.clientX), y = Math.min(start[1], e.clientY), w = Math.abs(e.clientX - start[0]), h = Math.abs(e.clientY - start[1]);
    start = null; sel.classList.remove('on'); box.style.display = 'none';
    if(w < 8 || h < 8) return;
    const wasOpen = !panel.classList.contains('off');
    host.style.visibility = 'hidden'; await new Promise(r => setTimeout(r, 150));
    const shot = await send({type: 'helperShot'});
    host.style.visibility = ''; toggle(true);
    if(!shot || !shot.dataUrl){ bubble('e', esc((shot && shot.error) || 'No he podido capturar la pantalla.') + '<br>Pulsa una vez el icono de la extensión en esta pestaña y vuelve a usar la lupa.'); return; }
    const img = new Image(); img.src = shot.dataUrl; await img.decode();
    const k = img.width / innerWidth, c = document.createElement('canvas'), s = Math.min(1, 1200 / (w * k));
    c.width = Math.round(w * k * s); c.height = Math.round(h * k * s);
    c.getContext('2d').drawImage(img, x * k, y * k, w * k, h * k, 0, 0, c.width, c.height);
    setImage(c.toDataURL('image/jpeg', 0.85)); ta.focus();
    if(!wasOpen) ta.placeholder = '¿Qué quieres saber de esta zona? (Enter para enviar)';
  });
  document.addEventListener('keydown', e => { if(e.key === 'Escape' && sel.classList.contains('on')){ start = null; sel.classList.remove('on'); } }, true);

  function toggle(v){ const on = v === undefined ? panel.classList.contains('off') : v; panel.classList.toggle('off', !on); if(on) setTimeout(() => ta.focus(), 50); }
  window.__msHelper = {toggle, lens: () => { lens(); }, ask: (q) => { toggle(true); ta.value = q; ta.focus(); }};
  api.runtime.onMessage.addListener(m => {
    if(!m) return;
    if(m.type === 'MS_HELP_TOGGLE') toggle();
    if(m.type === 'MS_HELP_LENS') lens();
    if(m.type === 'MS_HELP_ASK'){ toggle(true); ta.value = m.text || ''; ta.focus(); }
  });
  (document.body || document.documentElement).appendChild(host);
  toggle(true);
})();
