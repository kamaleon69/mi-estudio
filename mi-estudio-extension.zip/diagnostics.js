((scope)=>{
 'use strict';
 const SCHEMA='mi-estudio-error/1',MAX_IMAGE=1600000;
 function safeURL(value){try{const url=new URL(value);if(!/^https?:$/.test(url.protocol))return'';url.username='';url.password='';url.search='';url.hash='';return url.href;}catch{return'';}}
 function redact(value,secrets=[]){
  let text=String(value??'');for(const secret of [...new Set(secrets.filter(v=>typeof v==='string'&&v.length>=4))].sort((a,b)=>b.length-a.length))text=text.split(secret).join('[CLAVE_OCULTA]');
  return text.replace(/\b(?:AIza[\w-]{20,}|sk-[\w-]{12,}|gsk_[\w-]{12,})\b/g,'[CLAVE_OCULTA]').replace(/\bBearer\s+[\w.\-]+/gi,'Bearer [OCULTO]').replace(/https?:\/\/[^\s"'<>]+/g,url=>safeURL(url)||'[URL_OCULTA]').replace(/[\w.+-]+@[\w.-]+\.[a-z]{2,}/gi,'[CORREO_OCULTO]');
 }
 const forbidden=/^(?:__proto__|prototype|constructor|authorization|cookie|set-cookie|password|passwd|token|keys|ai|cfg|config|headers|.*(?:api|gemini|claude|openai|groq|openrouter).*key\d*)$/i;
 function clean(value,secrets=[],depth=0,seen=new WeakSet()){
  if(depth>10)return'[LÍMITE]';if(typeof value==='string')return redact(value,secrets).slice(0,24000);if(value===null||['boolean','number'].includes(typeof value))return value;if(typeof value!=='object')return undefined;
  if(seen.has(value))return'[REFERENCIA]';seen.add(value);let result;
  if(Array.isArray(value))result=value.slice(0,120).map(item=>clean(item,secrets,depth+1,seen));
  else result=Object.fromEntries(Object.entries(value).filter(([key])=>!forbidden.test(key)).slice(0,120).map(([key,item])=>[key,clean(item,secrets,depth+1,seen)]));
  seen.delete(value);return result;
 }
 function create(data,secrets=[]){const report=clean({schema:SCHEMA,createdAt:new Date().toISOString(),...data},secrets);report.schema=SCHEMA;return report;}
 function image(value){return typeof value==='string'&&value.length<=MAX_IMAGE&&/^data:image\/(?:jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/.test(value)?value:null;}
 function serialize(report,{kind='respuesta_incorrecta',note='',expected='',includeImage=false,analysisImage=null}={}){
  const data=clean({...report,incident:{kind,note:String(note).slice(0,6000),expected:String(expected).slice(0,6000)}});
  if(includeImage&&image(analysisImage))data.analysisImage=image(analysisImage);
  return JSON.stringify(data,null,2);
 }
 class Trace{
  constructor(limit=80,now=()=>Date.now()){this.limit=limit;this.now=now;this.events=[];}
  add(stage,data){const previous=this.events.at(-1),text=JSON.stringify(data);if(previous&&previous.stage===stage&&JSON.stringify(previous.data)===text){previous.count++;previous.lastAt=new Date(this.now()).toISOString();return;}this.events.push({at:new Date(this.now()).toISOString(),stage,data,count:1});if(this.events.length>this.limit)this.events.splice(0,this.events.length-this.limit);}
  list(){return JSON.parse(JSON.stringify(this.events));}
 }
 scope.MiEstudioDiagnostics={SCHEMA,MAX_IMAGE,safeURL,redact,clean,create,image,serialize,Trace};if(typeof module!=='undefined'&&module.exports)module.exports=scope.MiEstudioDiagnostics;
})(globalThis);
