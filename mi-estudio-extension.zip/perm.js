// Los enlaces antiguos llevan a la preparación inicial, antes de actuar.
const api=globalThis.browser?.runtime?browser:chrome;
location.replace(api.runtime.getURL('estado.html'));
