(() => {
 const api=globalThis.browser?.runtime?browser:chrome,$=id=>document.getElementById(id);
 const requirements=MiEstudioPermissions.REQUIRED;
 async function inspect(){
  try{
   const [saved,access]=await Promise.all([api.storage.local.get(['ai','installInfo']),api.permissions.contains(requirements)]);
   $('version').textContent='Versión '+api.runtime.getManifest().version;
   const provider=MiEstudioAI.provider(saved.ai||{}),key=MiEstudioAI.hasKey(saved.ai||{},provider);
   $('status').textContent=(saved.installInfo?.temporary?'Instalación temporal: hay que cargarla otra vez al reiniciar.\n':'')+(access?'Permisos iniciales: permitidos. Puedes comenzar.':'Faltan permisos iniciales. Pulsa Conceder permisos; todavía no se hará ninguna tarea.')+'\nAPI: '+(MiEstudioAI.NAMES[provider]||provider)+(key?' configurada.':' sin clave; configúrala en Ajustes.');
   $('access').disabled=access;$('start').disabled=!access;
  }catch(error){$('status').textContent='No se pudo comprobar: '+error.message;}
 }
 $('access').onclick=async()=>{try{const granted=await api.permissions.request(requirements);if(granted)await api.runtime.sendMessage({type:'setupComplete'});await inspect();if(!granted)$('status').textContent+='\nNo se han concedido los permisos. La extensión permanece en pausa.';}catch(error){$('status').textContent='No se pudo cambiar el permiso: '+error.message;}};
 $('start').onclick=async()=>{try{const result=await api.runtime.sendMessage({type:'setupStart'});if(result?.error)$('status').textContent=result.error;}catch(error){$('status').textContent=error.message;}};
 $('refresh').onclick=inspect;
 $('openApp').onclick=()=>api.tabs.create({url:'https://kamaleon69.github.io/mi-estudio/#cfg-ai'});
 inspect();
})();
