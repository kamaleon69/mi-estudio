// Mi Estudio · Asistente en cualquier página (documentos, Word/Docs online, PDFs, webs)
// Panel lateral con chat de IA + 🔍 lupa para seleccionar una zona de la pantalla y preguntar por ella.
(() => {
  if(document.getElementById('__msHelperHost'))return;
  const api = (typeof browser !== 'undefined' && browser.runtime) ? browser : chrome;
  const host = document.createElement('div'); host.id = '__msHelperHost';
  host.style.cssText = 'all:initial;position:fixed;z-index:2147483647;top:0;right:0;';
  const root = host.attachShadow({mode: 'open'});
  root.innerHTML = `<style>
    *{box-sizing:border-box;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif}
    .panel{position:fixed;top:0;right:0;width:min(400px,100vw);height:100vh;background:#fff;color:#111827;border-left:1px solid #d1d5db;box-shadow:-6px 0 24px rgba(0,0,0,.18);display:flex;flex-direction:column}
    .panel.off{display:none}
    .h{display:flex;align-items:center;gap:8px;padding:10px 12px;border-bottom:1px solid #e5e7eb}
    .h b{flex:1;font-size:15px}
    .ib{border:1px solid #d1d5db;background:#fff;border-radius:8px;height:30px;min-width:30px;padding:0 8px;cursor:pointer;font-size:13px}
    .ib:hover{background:#f3f4f6}
    .msgs{flex:1;overflow:auto;padding:12px;display:flex;flex-direction:column;gap:10px;background:#f8fafc}
    .m{max-width:92%;padding:9px 12px;border-radius:14px;font-size:14px;line-height:1.5;white-space:pre-wrap;word-wrap:break-word}
    .m.u{align-self:flex-end;background:#2563eb;color:#fff;border-bottom-right-radius:4px}
    .m.a{align-self:flex-start;background:#fff;border:1px solid #e2e8f0;border-bottom-left-radius:4px}
    .m.a code{background:#f1f5f9;padding:1px 4px;border-radius:4px;font-family:ui-monospace,monospace;font-size:12.5px}
    .m.a pre{background:#0f172a;color:#e2e8f0;padding:8px;border-radius:8px;overflow:auto;white-space:pre}
    .m img{display:block;max-width:100%;border-radius:8px;margin-bottom:6px}
    .m.e{align-self:stretch;background:#fef2f2;border:1px solid #fca5a5;color:#991b1b}
    .hint{color:#64748b;font-size:13px;line-height:1.5;padding:4px 2px}
    .hint b{color:#334155}
    .chips{display:flex;flex-wrap:wrap;gap:6px;padding:8px 12px 0;background:#fff}
    .chip{border:1px solid #cbd5e1;background:#f8fafc;border-radius:999px;padding:5px 10px;font-size:12.5px;cursor:pointer}
    .chip:hover{background:#eef2ff;border-color:#a5b4fc}
    .att{display:none;align-items:center;gap:8px;margin:8px 12px 0;padding:6px 8px;border:1px solid #c7d2fe;background:#eef2ff;border-radius:10px;font-size:12.5px;color:#3730a3}
    .att.on{display:flex} .att img{height:40px;border-radius:6px} .att span{flex:1} .att button{border:0;background:none;cursor:pointer;font-size:14px}
    .in{display:flex;gap:8px;padding:10px 12px 12px;background:#fff;border-top:1px solid #e5e7eb;align-items:flex-end}
    textarea{flex:1;resize:none;min-height:42px;max-height:140px;padding:10px;border:1px solid #cbd5e1;border-radius:12px;font-size:14px;outline:none}
    textarea:focus{border-color:#2563eb;box-shadow:0 0 0 3px rgba(37,99,235,.15)}
    .send{width:42px;height:42px;border:0;border-radius:12px;background:#2563eb;color:#fff;font-size:18px;cursor:pointer}
    .send:disabled{opacity:.5;cursor:wait}
    .lens{width:42px;height:42px;border:1px solid #cbd5e1;border-radius:12px;background:#fff;font-size:18px;cursor:pointer}
    .dots::after{content:'…';animation:d 1s steps(3) infinite}
    @keyframes d{0%{content:'.'}33%{content:'..'}66%{content:'...'}}
    .sel{position:fixed;inset:0;touch-action:none;z-index:2;cursor:crosshair;background:rgba(15,23,42,.25);display:none}
    .sel.on{display:block}
    .box{position:fixed;border:2px solid #22c55e;background:rgba(34,197,94,.12);box-shadow:0 0 0 9999px rgba(15,23,42,.35)}
    .tip{position:fixed;left:50%;top:16px;transform:translateX(-50%);background:#0f172a;color:#fff;padding:8px 14px;border-radius:10px;font-size:14px}
  </style>
  <div class="sel"><div class="tip">🔍 Arrastra para seleccionar la zona · Esc para cancelar</div><div class="box" style="display:none"></div></div>
  <div class="panel">
    <div class="h"><span>💬</span><b>Asistente · Mi Estudio</b><button class="ib" data-new title="Nueva conversación">🗑</button><button class="ib" data-x title="Cerrar">✕</button></div>
    <div class="msgs"><div class="hint">Pregúntame lo que quieras sobre este documento o página.<br>• <b>🔍 Lupa</b>: selecciona una zona de la pantalla (un párrafo, un ejercicio, una imagen) y pregunta por ella.<br>• Usa el menú contextual sobre texto seleccionado para preparar una consulta.<br>• Revisa el recorte. Al enviar, se usa la API configurada en Mi Estudio.<br>• Te explico, resumo, corrijo y te ayudo a entenderlo; el trabajo lo haces tú.</div></div>
    <div class="chips"><span class="chip" data-q="Explícame esto de forma sencilla.">Explícamelo</span><span class="chip" data-q="Hazme un resumen con los puntos clave.">Resumir</span><span class="chip" data-q="Revisa la ortografía y la redacción y dime qué mejorar (sin reescribirlo entero).">Revisar redacción</span><span class="chip" data-q="Hazme 3 preguntas para comprobar si lo he entendido.">Ponme a prueba</span></div>
    <div class="att"><img alt=""><span></span><button title="Quitar">✕</button></div>
    <div class="in"><button class="lens" title="Lupa: seleccionar una zona de la pantalla">🔍</button><textarea placeholder="Escribe tu pregunta… (Enter para enviar)"></textarea><button class="send" title="Enviar">➤</button></div>
  </div>`;
  const $ = s => root.querySelector(s);
  const panel = $('.panel'), msgs = $('.msgs'), ta = $('textarea'), sendB = $('.send'), att = $('.att');
  let history = [], image = null, busy = false;
  const esc = s => String(s).replace(/[&<>"]/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;'}[c]));
  const md = s => esc(s).replace(/```([\s\S]*?)```/g, (_, c) => `<pre>${c.replace(/^\w*\n/, '')}</pre>`).replace(/`([^`\n]+)`/g, '<code>$1</code>').replace(/\*\*([^*\n]+)\*\*/g, '<b>$1</b>').replace(/^#{1,4}\s*(.+)$/gm, '<b>$1</b>').replace(/^\s*[-*]\s+/gm, '• ');
  async function send(message){
    try{return await api.runtime.sendMessage(message);}
    catch(error){return {error:error.message};}
  }
  function bubble(cls, html){ const d = document.createElement('div'); d.className = 'm ' + cls; d.innerHTML = html; msgs.appendChild(d); msgs.scrollTop = msgs.scrollHeight; return d; }
  function setImage(url){ image = url; att.classList.toggle('on', !!url); if(url){ att.querySelector('img').src = url; att.querySelector('span').textContent = 'Zona seleccionada con la lupa'; } }
  att.querySelector('button').onclick = () => setImage(null);
  async function ask(q){
    q=(q||'').trim();
    if(busy||(!q&&!image))return;
    const attachment=image, question=q||'Explícame lo que hay en la zona seleccionada.';
    const turn={role:'user',text:question};
    bubble('u',(attachment?'<img alt="Zona elegida" src="'+esc(attachment)+'">':'')+esc(question));
    busy=true;sendB.disabled=true;$('[data-new]').disabled=true;
    const wait=bubble('a','<span class="dots">Pensando</span>');
    const context=history.slice(-6).map(t=>(t.role==='user'?'Pregunta: ':'Respuesta: ')+t.text).join('\n').slice(-6500);
    const result=await send({type:'helperChat',question,context,image:attachment});
    busy=false;sendB.disabled=false;$('[data-new]').disabled=false;
    if(!result?.text){wait.className='m e';wait.textContent=result?.error||'No se pudo contactar con la IA.';return;}
    wait.innerHTML=md(result.text);
    history=[...history,turn,{role:'assistant',text:result.text}].slice(-8);
    if(ta.value.trim()===q)ta.value='';
    if(image===attachment)setImage(null);
  }
  sendB.onclick = () => ask(ta.value);
  ta.addEventListener('keydown', e => { if(e.key === 'Enter' && !e.shiftKey){ e.preventDefault(); ask(ta.value); } e.stopPropagation(); }, true);
  ta.addEventListener('keyup', e => e.stopPropagation(), true); ta.addEventListener('keypress', e => e.stopPropagation(), true);
  root.querySelectorAll('.chip').forEach(c => c.onclick = () => ask(c.dataset.q));
  $('[data-x]').onclick = () => toggle(false);
  $('[data-new]').onclick = () => { history = []; msgs.querySelectorAll('.m').forEach(m => m.remove()); setImage(null); };

  // ---------- lupa ----------
  const sel = $('.sel'), box = $('.box');
  let start=null,capturing=false,restorePanel=true;
  function stopLens(){
    start=null;sel.classList.remove('on');box.style.display='none';toggle(restorePanel);
  }
  function lens(){
    if(busy||capturing||sel.classList.contains('on'))return;
    restorePanel=!panel.classList.contains('off');
    toggle(false);sel.classList.add('on');box.style.display='none';
  }
  $('.lens').onclick=lens;
  sel.addEventListener('pointerdown',event=>{
    if(!event.isPrimary||event.button!==0)return;
    sel.setPointerCapture(event.pointerId);
    start={x:event.clientX,y:event.clientY,id:event.pointerId};
    Object.assign(box.style,{display:'block',left:start.x+'px',top:start.y+'px',width:'0px',height:'0px'});
  });
  sel.addEventListener('pointermove',event=>{
    if(!start||event.pointerId!==start.id)return;
    Object.assign(box.style,{left:Math.min(start.x,event.clientX)+'px',top:Math.min(start.y,event.clientY)+'px',width:Math.abs(start.x-event.clientX)+'px',height:Math.abs(start.y-event.clientY)+'px'});
  });
  sel.addEventListener('pointercancel',stopLens);
  sel.addEventListener('pointerup',async event=>{
    if(!start||event.pointerId!==start.id)return;
    const rect={x:Math.min(start.x,event.clientX),y:Math.min(start.y,event.clientY),w:Math.abs(start.x-event.clientX),h:Math.abs(start.y-event.clientY),viewportWidth:innerWidth,viewportHeight:innerHeight};
    stopLens();
    if(rect.w<8||rect.h<8)return;
    capturing=true;host.style.visibility='hidden';
    const view=[innerWidth,innerHeight,scrollX,scrollY].join('|');
    try{
      await new Promise(resolve=>setTimeout(resolve,100));
      const result=await send({type:'helperShot',rect});
      if(view!==[innerWidth,innerHeight,scrollX,scrollY].join('|'))throw new Error('La vista cambió durante la captura. Selecciona la zona de nuevo.');
      if(!/^data:image\/jpeg;base64,[A-Za-z0-9+/=]+$/.test(result?.dataUrl||''))throw new Error(result?.error||'No se pudo capturar la zona.');
      setImage(result.dataUrl);
    }catch(error){bubble('e',esc(error.message));}
    finally{capturing=false;host.style.visibility='';toggle(true);}
  });
  document.addEventListener('keydown',event=>{
    if(event.key==='Escape'&&sel.classList.contains('on')){event.stopPropagation();stopLens();}
  },true);

  function toggle(v){ const on = v === undefined ? panel.classList.contains('off') : v; panel.classList.toggle('off', !on); if(on) setTimeout(() => ta.focus(), 50); }

  api.runtime.onMessage.addListener(m => {
    if(!m) return;
    if(m.type === 'MS_HELP_TOGGLE') toggle();
    if(m.type === 'MS_HELP_LENS') lens();
    if(m.type === 'MS_HELP_ASK'){ toggle(true); ta.value = m.text || ''; ta.focus(); }
  });
  (document.body || document.documentElement).appendChild(host);
  toggle(false);
})();
