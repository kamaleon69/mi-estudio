// El modelo vive en una página de la extensión: no en el service worker ni en Electude.
((scope) => {
  'use strict';
  const OPTIONS = {expectedInputs: [{type: 'text', languages: ['es', 'en']}], expectedOutputs: [{type: 'text', languages: ['es']}]};
  class LocalAI {
    constructor(lm, onState = () => {}){ this.lm = lm; this.onState = onState; this.status = 'closed'; this.session = null; this.controller = null; this.busy = false; this.generation = 0; this.askController = null; this.promptSession = null; }
    state(status, detail = '', progress = null){ this.status = status; this.detail = detail; this.onState({status, detail, progress}); }
    async availability(){
      if(!this.lm){ this.state('unsupported', 'Esta versión del navegador no expone LanguageModel. Usa Chrome de escritorio actualizado y consulta los requisitos.'); return 'unavailable'; }
      try{ const result = await this.lm.availability(OPTIONS); if(!this.session && !this.controller) this.state(result); return result; }
      catch(error){ this.state('error', error.message); return 'unavailable'; }
    }
    async prepare(){
      // Se llama directamente desde el botón: create conserva la activación del usuario.
      if(!this.lm || this.controller) return;
      this.stop(); const generation = this.generation;
      this.controller = new AbortController();
      this.state('preparing', 'Chrome está preparando el modelo. La primera descarga puede tardar varios minutos.');
      try{
        const session = await this.lm.create({...OPTIONS, signal: this.controller.signal, monitor: monitor => {
          monitor.addEventListener('downloadprogress', event => {
            if(generation !== this.generation) return;
            const progress = Math.min(1, Math.max(0, Number(event.loaded) || 0));
            this.state('downloading', progress === 1 ? 'Descarga completa. Chrome está preparando los archivos…' : 'Descargando el modelo…', progress);
          });
        }});
        if(generation !== this.generation){ session.destroy(); return; }
        this.session = session; this.controller = null; this.state('ready', 'Modelo listo. Mantén esta pestaña abierta para usarlo desde Electude.');
      }catch(error){
        if(generation !== this.generation) return;
        this.controller = null; this.state(error.name === 'AbortError' ? 'closed' : 'error', /activation|gesture/i.test(error.message) ? 'Vuelve a pulsar Preparar: Chrome necesita un clic para iniciar la descarga.' : error.message);
      }
    }
    cancelAsk(){
      this.generation++; this.askController?.abort(); this.askController = null;
      try{ this.promptSession?.destroy(); }catch(error){} this.promptSession = null; this.busy = false;
    }
    stop(){
      this.generation++; this.controller?.abort(); this.controller = null; this.askController?.abort(); this.askController = null;
      try{ this.promptSession?.destroy(); }catch(error){} this.promptSession = null; this.busy = false;
      try{ this.session?.destroy(); }catch(error){} this.session = null;
      this.state('closed', 'IA local detenida.');
    }
    async ask(text, timeout = 30000){
      if(this.status !== 'ready' || !this.session) throw new Error('La IA local no está lista. Abre su pestaña y pulsa Preparar.');
      if(this.busy) throw new Error('La IA local está respondiendo otra consulta.');
      this.busy = true; const generation = this.generation, controller = new AbortController(); this.askController = controller; let session, timer;
      const limit = new Promise((_, reject) => { timer = setTimeout(() => { controller.abort(); reject(new Error('La IA local superó el tiempo de espera.')); }, timeout); });
      try{
        const operation = (async () => {
          session = this.session.clone ? await this.session.clone({signal: controller.signal}) : await this.lm.create({...OPTIONS, signal: controller.signal});
          if(controller.signal.aborted || generation !== this.generation){ session.destroy(); throw new Error('Consulta local cancelada.'); }
          this.promptSession = session;
          return session.prompt(String(text), {signal: controller.signal});
        })();
        const result = await Promise.race([operation, limit]);
        if(generation !== this.generation) throw new Error('La IA local se ha detenido.');
        return String(result);
      }finally{ clearTimeout(timer); try{ session?.destroy(); }catch(error){} if(this.askController === controller){ this.askController = null; this.promptSession = null; this.busy = false; } }
    }
  }
  scope.MiEstudioLocal = {OPTIONS, LocalAI};
  if(typeof module !== 'undefined' && module.exports) module.exports = scope.MiEstudioLocal;
})(globalThis);
