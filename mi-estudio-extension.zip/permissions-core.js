((scope)=>{
 'use strict';
 const REQUIRED=Object.freeze({origins:['<all_urls>'],permissions:['clipboardWrite']});
 const message='Completa los permisos iniciales antes de analizar, capturar, sincronizar o autocompletar.';
 class Access{
  constructor(api){this.api=api;this.opening=null;this.returnTabId=null;}
  async status(){try{return{ready:await this.api.permissions.contains(REQUIRED),requirements:REQUIRED};}catch(error){return{ready:false,error:'No se pudieron comprobar los permisos: '+error.message,requirements:REQUIRED};}}
  async open(tabId){
   if(Number.isInteger(tabId))this.returnTabId=tabId;
   if(this.opening)return this.opening;
   this.opening=(async()=>{const url=this.api.runtime.getURL('estado.html'),tabs=await this.api.tabs.query({}),existing=tabs.find(tab=>tab.url?.split('#')[0]===url);if(existing){await this.api.tabs.update(existing.id,{active:true});return existing;}return this.api.tabs.create({url});})().finally(()=>this.opening=null);
   return this.opening;
  }
  async ensure(tabId){const state=await this.status();if(state.ready)return state;await this.open(tabId);return{...state,error:state.error||message,needsSetup:true};}
  async notify(){const state=await this.status();for(const tab of await this.api.tabs.query({}))if(/^https:\/\/[^/]*\.electude\.eu\//.test(tab.url||'')||tab.url?.startsWith('https://kamaleon69.github.io/mi-estudio/'))try{await this.api.tabs.sendMessage(tab.id,{type:'MS_PERMISSIONS_STATE',ready:state.ready});}catch{}return state;}
  async finish(){const state=await this.status();if(!state.ready)return{...state,error:message};await this.api.storage.local.set({permissionSetup:{version:1,at:Date.now()}});await this.notify();return state;}
  async start(){const state=await this.finish();if(!state.ready)return state;if(this.returnTabId!==null){try{const tab=await this.api.tabs.get(this.returnTabId);if(/^https:\/\/[^/]*\.electude\.eu\//.test(tab.url||'')||tab.url?.startsWith('https://kamaleon69.github.io/mi-estudio/')){await this.api.tabs.update(tab.id,{active:true});return state;}}catch{}}await this.api.tabs.create({url:'https://kamaleon69.github.io/mi-estudio/'});return state;}
 }
 scope.MiEstudioPermissions={REQUIRED,Access};if(typeof module!=='undefined'&&module.exports)module.exports=scope.MiEstudioPermissions;
})(globalThis);
