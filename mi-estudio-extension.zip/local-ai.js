'use strict';
const api = typeof browser !== 'undefined' && browser.runtime ? browser : chrome;
const $ = id => document.getElementById(id);
const names = {unsupported: 'IA local no compatible', unavailable: 'El modelo no está disponible en este equipo', downloadable: 'Modelo disponible para descargar', downloading: 'Descargando el modelo', available: 'Modelo descargado · pulsa Preparar', preparing: 'Preparando el modelo', ready: 'IA local lista', closed: 'IA local detenida', error: 'No se pudo preparar la IA local'};
let currentState = {status: 'closed'};
const engine = new MiEstudioLocal.LocalAI(globalThis.LanguageModel, state => {
  currentState = state;
  $('state').textContent = names[state.status] || state.status;
  $('detail').textContent = state.detail || (state.status === 'unavailable' ? 'Consulta los requisitos y el diagnóstico de Chrome.' : 'Pulsa Preparar para crear una sesión local.');
  $('progress').hidden = state.progress === null;
  if(state.progress !== null) $('progress').value = state.progress;
  $('test').disabled = state.status !== 'ready';
  $('prepare').disabled = ['preparing', 'downloading', 'ready', 'unsupported', 'unavailable'].includes(state.status);
  api.storage.local.set({localAIStatus: {...state, at: Date.now()}, ...(state.status === 'ready' ? {localAI: true} : {})});
});
$('prepare').onclick = () => engine.prepare();
$('stop').onclick = () => { engine.stop(); api.storage.local.set({localAI: false}); $('testResult').textContent = ''; };
$('test').onclick = async () => {
  $('test').disabled = true; $('testResult').textContent = 'Probando una consulta local…';
  try{ const start = Date.now(), result = await engine.ask('Responde en español con una frase breve: ¿para qué sirve un fusible eléctrico?'); $('testResult').textContent = result + '\nConsulta ejecutada en este ordenador en ' + ((Date.now() - start) / 1000).toFixed(1) + ' s.'; }
  catch(error){ $('testResult').textContent = error.message; }
  finally{ $('test').disabled = engine.status !== 'ready'; }
};
$('internals').onclick = () => api.runtime.sendMessage({type: 'openLocalInternals'});
api.runtime.onMessage.addListener((message, sender, reply) => {
  if(sender.id !== api.runtime.id) return;
  if(message.type === 'localRunnerStatus'){ reply({...currentState, busy: engine.busy}); return; }
  if(message.type === 'localRunnerAsk'){
    engine.ask(String(message.text || '').slice(0, 18000)).then(text => reply({text, local: true, model: 'Gemini Nano', precise: false}), error => reply({error: error.message})); return true;
  }
});
window.addEventListener('pagehide', () => engine.stop());
$('internals').hidden = api.runtime.getURL('').startsWith('moz-extension:');
engine.availability();
setInterval(() => { if(!engine.controller && !engine.session) engine.availability(); }, 3000);
