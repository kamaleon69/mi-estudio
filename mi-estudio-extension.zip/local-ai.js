'use strict';
const api = typeof browser !== 'undefined' && browser.runtime ? browser : chrome, $ = id => document.getElementById(id);
const names = {unsupported:'Chrome no ofrece la IA integrada',unavailable:'Modelo no disponible en este equipo',downloadable:'Pendiente de descarga',downloading:'Descargando el modelo',available:'Descargado · pulsa Preparar',preparing:'Preparando',ready:'Modelo listo para probar',closed:'Sin preparar',error:'No se pudo completar la operación'};
let lastPublished=0,lastStatus='';
let currentState = {status:'closed'}, selectedEngine = 'ollama', operation = null, generation = 0, tested = false, activeRequest = null;
function paint(state){
 currentState = state; $('state').textContent = names[state.status] || state.status; $('detail').textContent = state.detail || '';
 $('progress').hidden = state.progress == null; if(state.progress != null) $('progress').value = state.progress;
 $('test').disabled = state.status !== 'ready'; $('prepare').disabled = ['preparing','downloading','ready'].includes(state.status) || selectedEngine === 'chrome' && ['unsupported','unavailable'].includes(state.status);
 $('use').disabled = !tested || state.status !== 'ready';
 if(state.status!==lastStatus || Date.now()-lastPublished>1000){lastStatus=state.status;lastPublished=Date.now();api.storage.local.set({localAIStatus:{...state,engine:selectedEngine,at:Date.now()}});}
}
const nano = new MiEstudioLocal.LocalAI(globalThis.LanguageModel, state => { if(selectedEngine === 'chrome') paint(state); });
const ollama = new MiEstudioOllama.Ollama();
const errorState = error => paint({status:'error',detail:error.name === 'AbortError' ? 'Operación cancelada. Puedes volver a intentarlo.' : error.message});
async function permission(){
 const state=await api.runtime.sendMessage({type:'getSetupStatus'});
 if(!state?.ready){await api.runtime.sendMessage({type:'openSetup'});throw new Error('Completa primero los permisos iniciales de Mi Estudio. No se ha usado la IA local.');}
}

function begin(){operation?.abort();operation=new AbortController();tested=false;$('use').disabled=true;return {signal:operation.signal,id:++generation};}
async function connect(){
 const run=begin();paint({status:'preparing',detail:'Buscando Ollama y los modelos instalados…'});
 try{await permission();const state=await ollama.status($('model').value,run.signal);if(run.id!==generation)return;paint(state);$('installed').textContent='Modelos locales instalados: '+(state.models.join(', ')||'ninguno');}
 catch(error){if(run.id===generation)errorState(error);}
 finally{if(run.id===generation)operation=null;}
}
$('engine').onchange=()=>{generation++;operation?.abort();operation=null;nano.stop();selectedEngine=$('engine').value;tested=false;$('testResult').textContent='';$('ollamaHelp').hidden=selectedEngine!=='ollama';$('chromeHelp').hidden=selectedEngine!=='chrome';paint({status:'closed',detail:selectedEngine==='ollama'?'Instala y abre Ollama; pulsa Conectar.':'Pulsa Preparar para crear una sesión de Chrome.'});if(selectedEngine==='chrome')nano.availability();};
$('model').oninput=()=>{generation++;operation?.abort();operation=null;tested=false;$('use').disabled=true;paint({status:'closed',detail:'Modelo cambiado. Pulsa Conectar para comprobarlo.'});};
$('connect').onclick=connect;
$('prepare').onclick=async()=>{
 if(selectedEngine==='chrome'){try{await permission();tested=false;await nano.prepare();}catch(error){errorState(error);}return;}
 const run=begin();paint({status:'downloading',detail:'Conectando para descargar el modelo…'});
 (async()=>{try{await permission();const state=await ollama.pull($('model').value,step=>{if(run.id===generation)paint({status:'downloading',detail:step.status+(step.progress!=null?' · '+Math.round(step.progress*100)+' % de esta capa':''),progress:step.progress});},run.signal);if(run.id===generation)paint(state);}catch(error){if(run.id===generation)errorState(error);}finally{if(run.id===generation)operation=null;}})();
};
$('test').onclick=async()=>{
 $('test').disabled=true;$('use').disabled=true;tested=false;$('testResult').textContent='Ejecutando una respuesta real en tu ordenador…';
 const run=begin(),start=Date.now(),prompt='Responde en español con una frase: ¿para qué sirve un fusible eléctrico?';
 const requestController=operation,timer=setTimeout(()=>requestController.abort(),180000);
 try{await permission();const result=selectedEngine==='chrome'?await nano.ask(prompt,90000):await ollama.ask($('model').value,prompt,null,run.signal);if(run.id!==generation)return;const text=typeof result==='string'?result:result.text;if(!text.trim())throw new Error('El modelo respondió vacío.');tested=true;$('testResult').textContent=text+'\nEjecutado en este ordenador en '+((Date.now()-start)/1000).toFixed(1)+' s.';paint({...currentState,status:'ready',detail:'Prueba correcta. Pulsa Usar en Electude para seleccionarlo.'});}
 catch(error){if(run.id===generation){$('testResult').textContent=error.message;tested=false;}}
 finally{clearTimeout(timer);if(run.id===generation){operation=null;$('test').disabled=currentState.status!=='ready';$('use').disabled=!tested;}}
};
$('stop').onclick=()=>{generation++;operation?.abort();operation=null;nano.stop();tested=false;paint({status:'closed',detail:'Operación cancelada. No se ha borrado ningún modelo descargado.'});};
$('use').onclick=async()=>{if(!tested)return;await api.storage.local.set({localEngine:selectedEngine,ollamaModel:MiEstudioOllama.modelName($('model').value),localAI:true,elecMode:'fast'});$('detail').textContent='Seleccionado. Vuelve a Electude: Rápido usará '+(selectedEngine==='chrome'?'Gemini Nano. Mantén esta pestaña abierta.':'Ollama. Puedes cerrar esta pestaña, pero deja Ollama abierto.');};
$('internals').onclick=()=>api.runtime.sendMessage({type:'openLocalInternals'});
$('internals').hidden=api.runtime.getURL('').startsWith('moz-extension:');
const ownURL=new URL(api.runtime.getURL(''));
$('origin').textContent=ownURL.protocol+'//'+ownURL.host;
$('copyOrigin').onclick=async()=>{try{await permission();await navigator.clipboard.writeText($('origin').textContent);$('copyOrigin').textContent='Copiado';}catch(error){errorState(error);}};
api.runtime.onMessage.addListener((message,sender,reply)=>{
 if(sender.id!==api.runtime.id)return;
 if(message.type==='localRunnerStatus'){reply(selectedEngine==='chrome'?{...currentState,busy:nano.busy,vision:false}:{status:'closed'});return;}
 if(message.type==='localRunnerCancel' && activeRequest===message.requestId){nano.cancelAsk();return;}
 if(message.type==='localRunnerAsk'){
  if(selectedEngine!=='chrome'){reply({error:'Selecciona el motor local que has preparado.'});return;}
  activeRequest=message.requestId;
  nano.ask(String(message.text||'').slice(0,24000),90000).then(text=>reply({text,local:true,provider:'local',model:'Gemini Nano',precise:false}),error=>reply({error:error.message})).finally(()=>{if(activeRequest===message.requestId)activeRequest=null;});return true;
 }
});
window.addEventListener('pagehide',()=>{generation++;operation?.abort();nano.stop();});
api.storage.local.get(['localEngine','ollamaModel']).then(saved=>{$('engine').value=saved.localEngine||'ollama';$('model').value=saved.ollamaModel||'gemma3:4b';$('engine').onchange();});
setInterval(()=>{if(selectedEngine==='chrome'&&!nano.controller&&!nano.session&&['downloading','downloadable','available'].includes(currentState.status))nano.availability();},3000);
