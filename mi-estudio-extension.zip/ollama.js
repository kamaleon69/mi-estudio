// Cliente limitado al servidor Ollama de este ordenador. No contiene claves ni endpoints remotos.
((scope) => {
  'use strict';
  const BASE = 'http://127.0.0.1:11434';
  const modelName = value => {
    const name = String(value || 'gemma3:4b').trim();
    if(!/^[a-z0-9][a-z0-9._:/-]{0,150}$/i.test(name) || /cloud|https?:/i.test(name)) throw new Error('Elige un modelo local de Ollama; los modelos cloud y las URLs no se admiten aquí.');
    return name;
  };
  class Ollama {
    constructor(fetcher = (...args) => fetch(...args)){ this.fetch = fetcher; }
    async request(path, body, signal){
      let response;
      try{ response = await this.fetch(BASE + path, {method:body ? 'POST':'GET', headers:{'content-type':'application/json'}, ...(body ? {body:JSON.stringify(body)} : {}), signal, redirect:'error'}); }
      catch(error){ if(error.name === 'AbortError') throw error; throw new Error('No se puede conectar a Ollama en 127.0.0.1:11434. Instala y abre Ollama; comprueba el permiso de conexión local.'); }
      if(response.status === 403) throw new Error('Ollama rechaza el origen de la extensión (403). Configura OLLAMA_ORIGINS con el origen indicado abajo y reinicia Ollama.');
      if(!response.ok){const value = await response.json().catch(()=>({}));throw new Error('Ollama: '+(value.error || 'error '+response.status));}
      return response;
    }
    async status(model, signal){
      model = modelName(model);
      const response = await this.request('/api/tags', null, signal), body = await response.json();
      const models = (body.models || []).filter(m => !/cloud/i.test(m.name || m.model || '') && !m.remote_host && !m.remote_model);
      const installed = models.some(m => (m.name || m.model) === model || (m.name || m.model) === model + ':latest');
      if(!installed) return {status:'downloadable',model,models:models.map(m=>m.name || m.model),vision:false};
      const details = await (await this.request('/api/show', {model}, signal)).json();
      if(details.remote_host || details.remote_model) throw new Error('El modelo seleccionado es remoto. Elige un modelo descargado en este ordenador.');
      return {status:'ready',model,models:models.map(m=>m.name || m.model),vision:(details.capabilities || []).includes('vision'),detail:'Ollama conectado y modelo instalado. Pulsa Probar para comprobar una respuesta.'};
    }
    async pull(model, onProgress, signal){
      model = modelName(model);
      const response = await this.request('/api/pull', {model,stream:true}, signal), reader = response.body.getReader(), decoder = new TextDecoder();
      let buffer = '', success = false;
      const processLine = line => {
        if(!line.trim()) return; const value = JSON.parse(line);
        if(value.error) throw new Error(value.error);
        if(value.status === 'success') success = true;
        onProgress({status:value.status || 'Descargando',progress:value.total ? Math.max(0,Math.min(1,(value.completed || 0)/value.total)) : null});
      };
      try{ for(;;){const chunk = await reader.read();if(chunk.done)break;buffer += decoder.decode(chunk.value,{stream:true});let end;while((end=buffer.indexOf('\n'))>=0){processLine(buffer.slice(0,end));buffer=buffer.slice(end+1);}} buffer += decoder.decode();if(buffer.trim())processLine(buffer); }
      finally{reader.releaseLock();}
      if(!success) throw new Error('La descarga terminó sin confirmar el modelo. Vuelve a conectar y comprueba su estado.');
      return this.status(model, signal);
    }
    async ask(model, text, image, signal){
      const state = await this.status(model, signal);
      if(state.status !== 'ready') throw new Error('El modelo no está descargado. Abre Configurar IA local y descárgalo.');
      if(image && !state.vision) throw new Error('Este modelo local no admite imágenes. Elige un modelo con visión, por ejemplo gemma3:4b, o usa tu API.');
      const response = await this.request('/api/chat', {model:state.model,stream:false,keep_alive:'5m',messages:[{role:'user',content:text,...(image ? {images:[image.replace(/^data:image\/[^;]+;base64,/, '')]} : {})}],options:{temperature:0.1,num_ctx:8192,num_predict:2500}}, signal);
      const body = await response.json();
      if(body.error) throw new Error('Ollama: '+body.error);
      if(body.done !== true || body.done_reason === 'length' || !body.message?.content?.trim()) throw new Error('El modelo local no devolvió una respuesta completa. No se aplicará.');
      return {text:body.message.content,local:true,provider:'local',precise:false,model:'Ollama · '+state.model};
    }
  }
  scope.MiEstudioOllama = {BASE,modelName,Ollama};
  if(typeof module !== 'undefined' && module.exports) module.exports = scope.MiEstudioOllama;
})(globalThis);
