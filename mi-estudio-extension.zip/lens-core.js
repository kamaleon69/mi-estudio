((scope) => {
  function crop(rect, width, height) {
    const {x, y, w, h, viewportWidth, viewportHeight} = rect || {};
    if (![x,y,w,h,viewportWidth,viewportHeight,width,height].every(Number.isFinite) ||
        x < 0 || y < 0 || w < 8 || h < 8 || viewportWidth <= 0 || viewportHeight <= 0 ||
        width <= 0 || height <= 0 || x + w > viewportWidth || y + h > viewportHeight) {
      throw new Error('Selecciona una zona dentro del área visible.');
    }
    const sx = x * width / viewportWidth, sy = y * height / viewportHeight;
    const sw = w * width / viewportWidth, sh = h * height / viewportHeight;
    const scale = Math.min(1, 1600 / Math.max(sw, sh));
    return {sx, sy, sw, sh, width: Math.max(1, Math.round(sw * scale)), height: Math.max(1, Math.round(sh * scale))};
  }
  scope.MiEstudioLens = {crop};
  if (typeof module !== 'undefined') module.exports = scope.MiEstudioLens;
})(globalThis);
