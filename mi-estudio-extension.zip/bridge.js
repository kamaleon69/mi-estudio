// Puente entre la web de Mi Estudio y la extensión. Solo reenvía mensajes; no lee nada de la página.
const api = (typeof browser !== 'undefined' && browser.runtime) ? browser : chrome;
const VERSION = api.runtime.getManifest().version;
const hello=async()=>{let status;try{status=await api.runtime.sendMessage({type:'getSetupStatus'});}catch{}window.postMessage({type:'MS_EXT_PERMISSIONS',ready:status?.ready===true},location.origin);window.postMessage({type:'MS_EXT_HERE',version:VERSION},location.origin);};
hello();
document.addEventListener('DOMContentLoaded', hello);
window.addEventListener('message', e => {
  if(e.source !== window || !e.data || typeof e.data.type !== 'string') return;
  if(e.data.type === 'MS_EXT_PING') hello();
  if(e.data.type === 'MS_EXT_KEYS') api.runtime.sendMessage({type: 'keys', selectionExplicit: e.data.selectionExplicit === true, ...globalThis.MiEstudioAI.cleanKeys(e.data)}).then(r => { if(r && !r.error) window.postMessage({type: 'MS_EXT_AI_PREFS', provider: r.provider, geminiSlot: r.geminiSlot}, location.origin); }).catch(() => {});
  if(e.data.type === 'MS_EXT_OPEN_ELEC' && /^https:\/\/[^/]*electude\.eu\//.test(e.data.url || '')) api.runtime.sendMessage({type: 'openElec', url: e.data.url});
  if(e.data.type==='MS_EXT_OPEN_SETUP')api.runtime.sendMessage({type:'openSetup'});
  if(e.data.type === 'MS_EXT_CAPTURE') api.runtime.sendMessage({type: 'capture'});
  if(e.data.type==='MS_EXT_SYNC'){
    api.runtime.sendMessage({type:'sync',what:e.data.what,moodleUrl:e.data.moodleUrl,classroomUrl:e.data.classroomUrl,from:e.data.from})
      .catch(()=>window.postMessage({type:'MS_EXT_SYNC_FAILED'},location.origin));
  }
  if(e.data.type==='MS_EXT_SYNC_CANCEL')api.runtime.sendMessage({type:'syncCancel'}).catch(()=>{});
  if(e.data.type==='MS_EXT_SYNC_LOGIN')api.runtime.sendMessage({type:'syncLogin',source:e.data.source}).catch(()=>{});
});
api.runtime.onMessage.addListener(m => { if(m && typeof m.type === 'string' && m.type.startsWith('MS_')) window.postMessage(m, '*'); });
