// Mi Estudio · Ayuda IA en Electude: panel lateral que analiza el enunciado visible y señala la opción que la IA cree correcta.
// No pulsa nada ni envía respuestas: solo muestra la sugerencia y la explicación. Tú decides qué marcar.
(() => {
  if(window.__msElec) return; window.__msElec = true;
  const api = (typeof browser !== 'undefined' && browser.runtime) ? browser : chrome;
  const host = document.createElement('div'); host.id = '__msElecHost';
  host.style.cssText = 'all:initial;position:fixed;z-index:2147483647;top:0;right:0;';
  const root = host.attachShadow({mode: 'open'});
  root.innerHTML = `<style>
    *{box-sizing:border-box;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif}
    .fab{position:fixed;right:16px;bottom:16px;touch-action:none;width:52px;height:52px;border-radius:50%;border:0;background:#2563eb;color:#fff;font-size:24px;cursor:pointer;box-shadow:0 4px 14px rgba(0,0,0,.3)}
    .fab:hover{background:#1d4ed8}
    .panel{position:fixed;top:0;right:0;width:min(380px,100vw);height:100vh;background:#fff;color:#111827;border-left:1px solid #d1d5db;box-shadow:-6px 0 24px rgba(0,0,0,.18);display:none;flex-direction:column}
    .panel.on{display:flex}
    .h{display:flex;align-items:center;justify-content:space-between;padding:12px 14px;border-bottom:1px solid #e5e7eb;font-weight:700;font-size:15px}
    .x{border:1px solid #d1d5db;background:#fff;border-radius:8px;width:30px;height:30px;cursor:pointer;font-size:14px}
    .b{padding:14px;overflow:auto;flex:1;font-size:14px;line-height:1.5}
    .go{width:100%;padding:12px;border:0;border-radius:10px;background:#2563eb;color:#fff;font-size:15px;font-weight:600;cursor:pointer}
    .go:disabled{opacity:.6;cursor:wait}
    .ans{margin-top:14px;border-radius:16px;overflow:hidden;background:#fff;box-shadow:0 6px 20px rgba(16,185,129,.18),0 0 0 1px rgba(16,185,129,.35)}
    .ans .top{display:flex;align-items:center;gap:8px;padding:9px 14px;background:linear-gradient(135deg,#10b981,#059669);color:#fff;font-size:12px;font-weight:700;letter-spacing:.06em;text-transform:uppercase}
    .ans .pick{display:flex;align-items:flex-start;gap:12px;padding:14px;background:linear-gradient(180deg,#ecfdf5,#fff);font-size:18px;font-weight:800;line-height:1.3;color:#064e3b}
    .ans .ck{flex:none;width:30px;height:30px;border-radius:50%;background:#10b981;color:#fff;display:flex;align-items:center;justify-content:center;font-size:17px;box-shadow:0 2px 6px rgba(16,185,129,.4)}
    .ans .why{margin:0 14px 14px;padding:10px 12px;border-radius:10px;background:#f8fafc;border:1px solid #e2e8f0;color:#334155;font-size:13.5px;line-height:1.55;white-space:pre-wrap}
    .ans .why i{display:block;font-style:normal;font-weight:700;font-size:11.5px;color:#64748b;text-transform:uppercase;letter-spacing:.05em;margin-bottom:4px}
    .why{white-space:pre-wrap;color:#374151;margin-top:10px}
    .upd .warn{margin:0 0 10px}
    .loc{margin-top:8px;font-size:12.5px;color:#475569}
    .auto{display:flex;align-items:center;gap:10px;margin-top:10px;font-size:13.5px;color:#334155;cursor:pointer;user-select:none}
    .auto input{display:none}
    .sw{position:relative;flex:none;width:40px;height:22px;border-radius:11px;background:#cbd5e1;transition:background .2s}
    .sw::after{content:'';position:absolute;left:3px;top:3px;width:16px;height:16px;border-radius:50%;background:#fff;box-shadow:0 1px 3px rgba(0,0,0,.3);transition:left .2s}
    .auto input:checked + .sw{background:#10b981} .auto input:checked + .sw::after{left:21px}
    .cd{position:fixed;left:50%;bottom:24px;transform:translateX(-50%);display:none;align-items:center;gap:12px;padding:10px 14px;border-radius:12px;background:#0f172a;color:#fff;font-size:14px;box-shadow:0 8px 24px rgba(0,0,0,.3)}
    .cd.on{display:flex} .cd button{border:0;border-radius:8px;padding:6px 12px;background:#fff;color:#0f172a;font-weight:700;cursor:pointer}
    .fab.auto::after{content:'A';position:absolute;right:-2px;top:-2px;width:18px;height:18px;border-radius:50%;background:#10b981;color:#fff;font:700 11px/18px system-ui,sans-serif;text-align:center;box-shadow:0 0 0 2px #fff}
    .chip{display:inline-flex;align-items:center;gap:6px;padding:4px 10px;border-radius:999px;border:1px solid #cbd5e1;background:#f8fafc;cursor:pointer;font-size:12.5px}
    .chip.on{background:#ecfdf5;border-color:#10b981;color:#065f46;font-weight:700}
    .ask{margin-top:8px;padding:10px 12px;border-radius:10px;background:#eff6ff;border:1px solid #93c5fd;color:#1e3a8a;line-height:1.45}
    .ask .row .sm:first-child{background:#2563eb;color:#fff;border:0;font-weight:700}
    .vf{padding:10px 14px;display:flex;flex-direction:column;gap:8px}
    .vw{display:block;margin-top:2px;font-weight:400;font-size:12.5px;color:#475569}
    .mode{display:flex;gap:6px;margin-top:10px} .mode button{flex:1;padding:7px;border:1px solid #cbd5e1;background:#fff;border-radius:8px;cursor:pointer;font-size:12.5px} .mode button.on{background:#0f172a;color:#fff;border-color:#0f172a;font-weight:700}
    .vfr{display:flex;align-items:flex-start;gap:10px;font-size:14.5px;font-weight:600;color:#0f172a;line-height:1.35}
    .pill{flex:none;min-width:44px;text-align:center;padding:3px 8px;border-radius:999px;color:#fff;font-size:12.5px;font-weight:800}
    .pill.v{background:linear-gradient(135deg,#22c55e,#059669)} .pill.f{background:linear-gradient(135deg,#f87171,#dc2626)}
    .ans + .ans{margin-top:12px}
    .warn{margin-top:12px;padding:10px 12px;border-radius:10px;background:#fffbeb;border:1px solid #fcd34d;color:#78350f;font-size:13px;line-height:1.45;display:flex;flex-direction:column;gap:8px}
    .warn .sm{background:#f59e0b;color:#fff;border:0;font-weight:700}
    .note{margin-top:12px;font-size:12.5px;color:#6b7280}
    .err{margin-top:14px;border:1px solid #fca5a5;background:#fef2f2;border-radius:10px;padding:10px 12px;color:#991b1b}
    .row{display:flex;gap:8px;margin-top:10px}
    .sm{flex:1;padding:8px;border:1px solid #d1d5db;background:#fff;border-radius:8px;cursor:pointer;font-size:13px}
    .spin{display:inline-block;width:14px;height:14px;border:2px solid #fff;border-top-color:transparent;border-radius:50%;animation:s .8s linear infinite;vertical-align:-2px;margin-right:6px}
    @keyframes s{to{transform:rotate(360deg)}}
  </style>
  <button class="fab" title="Ayuda IA (Mi Estudio) · arrástrame si tapo algo">💡</button>
  <div class="cd"><span class="cdt"></span><button class="cdx">Cancelar</button></div>
  <div class="panel"><div class="h"><span>💡 Ayuda IA · Mi Estudio</span><button class="x" title="Cerrar">✕</button></div>
  <div class="b"><div class="upd"></div><button class="go">🔍 Analizar la pregunta</button><div class="mode"><button data-m="precise" title="Usa un modelo más potente: tarda unos segundos más">🎯 Preciso</button><button data-m="fast" title="Modelo ligero: más rápido, se equivoca más">⚡ Rápido</button></div><label class="auto"><input type="checkbox" class="autoChk"><span class="sw"></span><span><b>Automático:</b> analizar cada vez que cambie el ejercicio</span></label><label class="auto"><input type="checkbox" class="nextChk"><span class="sw"></span><span><b>Pasar solo:</b> cuando compruebes tu respuesta y salga «Correcte», ir a la siguiente</span></label><div class="loc"></div><div class="out"></div>
  <div class="note">La IA puede equivocarse: léete la explicación antes de marcar. La extensión no marca nada por ti.</div><div class="note"><a href="#" class="diag">🛠 Copiar diagnóstico</a> (si algo no se marca bien, pégamelo)</div></div></div>`;
  const $ = s => root.querySelector(s);
  const panel = $('.panel'), fab = $('.fab'), go = $('.go'), out = $('.out');
  const open = v => { panel.classList.toggle('on', v); fab.style.display = v ? 'none' : ''; };
  // botón movible (arrástralo si tapa algo de Electude); recuerda dónde lo dejas
  let drag = null, moved = false;
  const place = (x, y) => { x = Math.max(4, Math.min(innerWidth - 56, x)); y = Math.max(4, Math.min(innerHeight - 56, y)); fab.style.left = x + 'px'; fab.style.top = y + 'px'; fab.style.right = 'auto'; fab.style.bottom = 'auto'; return [x, y]; };
  try{ const p = JSON.parse(localStorage.getItem('__msElecFab') || 'null'); if(p) place(p[0], p[1]); else { fab.style.bottom = '90px'; } }catch(e){ fab.style.bottom = '90px'; }
  fab.addEventListener('pointerdown', e => { const r = fab.getBoundingClientRect(); drag = [e.clientX - r.left, e.clientY - r.top, e.clientX, e.clientY]; moved = false; fab.setPointerCapture(e.pointerId); });
  fab.addEventListener('pointermove', e => { if(!drag) return; if(Math.abs(e.clientX - drag[2]) + Math.abs(e.clientY - drag[3]) > 6) moved = true; if(moved) place(e.clientX - drag[0], e.clientY - drag[1]); });
  fab.addEventListener('pointerup', e => { if(drag && moved){ const r = fab.getBoundingClientRect(); try{ localStorage.setItem('__msElecFab', JSON.stringify([r.left, r.top])); }catch(_){} } drag = null; });
  fab.onclick = () => { if(moved){ moved = false; return; } open(true); };
  $('.x').onclick = () => { open(false); clearMarks(); };
  const esc = s => String(s).replace(/[&<>"]/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;'}[c]));

  // documentos accesibles (la página y sus iframes del mismo origen)
  // documentos y zonas accesibles: la página, sus iframes del mismo origen y los «shadow DOM» abiertos
  function docs(d = document, acc = []){
    acc.push(d);
    const root = d.body || d;
    for(const el of root.querySelectorAll('*')){
      if(el.id === '__msElecHost' || el.id === '__msElecPins') continue;
      if(el.shadowRoot) docs(el.shadowRoot, acc);
      if(el.tagName === 'IFRAME' || el.tagName === 'FRAME'){ try{ if(el.contentDocument && el.contentDocument.body) docs(el.contentDocument, acc); }catch(e){} }
    }
    return acc;
  }
  const rootOf = d => d.body || d;
  function pageText(){
    let t = docs().map(d => { try{ return d.body ? d.body.innerText : [...d.children].map(c => c.innerText || '').join('\n'); }catch(e){ return ''; } }).join('\n');
    return t.replace(/\n{3,}/g, '\n\n').trim().slice(0, 9000);
  }
  // marcas en la página
  let marks = [];
  function clearMarks(){ marks.forEach(([el, o, b]) => { Object.assign(el.style, o); if(b) b.remove(); }); marks = []; clearPins(); }
  const norm = s => String(s).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/^[\s(]*([a-h]|\d{1,2})[).:\-]\s+/, '').replace(/[«»"'.,;:¿?¡!()]/g, '').replace(/\s+/g, ' ').trim();
  // fila de opción: un bloque con hermanos parecidos (lista de respuestas), mejor si tiene casilla/tick
  function optionRow(el){
    let n = el;
    for(let k = 0; k < 5 && n && n.parentElement && n.tagName !== 'BODY'; k++, n = n.parentElement){
      const p = n.parentElement, sib = [...p.children].filter(c => c !== n && c.tagName === n.tagName && (c.className || '') === (n.className || '') && (c.innerText || '').trim());
      if(sib.length >= 1 && (n.innerText || '').trim().length < 300) return n;
    }
    return null;
  }
  const hasControl = el => !!el.querySelector('input[type=radio],input[type=checkbox],[role=radio],[role=checkbox],[role=option],svg,img,i[class*=icon],span[class*=check],div[class*=check]') || /^(radio|checkbox|option)$/.test(el.getAttribute('role') || '');
  const isHeading = el => !!el.closest('h1,h2,h3,h4,h5,h6,header,[role=heading],strong,b') || parseInt(getComputedStyle(el).fontWeight, 10) >= 600;
  function findOption(answer){
    const want = norm(answer); if(want.length < 1) return null;
    const cands = [];
    for(const d of docs()){
      const qEls = [...rootOf(d).querySelectorAll('p,div,span,h1,h2,h3,h4,label')].filter(x => /\?\s*$/.test((x.innerText || '').trim()) && (x.innerText || '').length < 400);
      for(const el of rootOf(d).querySelectorAll('label,li,td,button,span,div,p,a,option')){
        if(el.closest && el.closest('#__msElecHost')) continue;
        const r = el.getBoundingClientRect(); if(!r.width || !r.height) continue;
        const t = norm(el.innerText || ''); if(!t || t.length > want.length * 3 + 40) continue;
        if(!(t === want || (want.length > 3 && (t.includes(want) || (t.length > 3 && want.includes(t) && t.length > want.length * 0.6))))) continue;
        const row = optionRow(el);
        let score = 0;
        if(row){ score += 50; if(hasControl(row)) score += 60; }
        if(t === want) score += 15;
        if(t.length > want.length * 1.25 + 8) score -= 45;   // párrafo que solo contiene la frase (texto de la lección)
        if(isHeading(el)) score -= 70;
        if(qEls.some(q => q.compareDocumentPosition(el) & Node.DOCUMENT_POSITION_FOLLOWING)) score += 25;
        cands.push({el, row, score, len: t.length});
      }
    }
    if(!cands.length) return null;
    cands.sort((a, b) => b.score - a.score || a.len - b.len);
    const best = cands[0];
    return best.row || best.el.closest('label,li,tr,button') || best.el;
  }
  function mark(answer){
    const target = findOption(answer); if(!target) return false;
    styleRow(target, '✓ Respuesta IA', '#10b981');
    target.scrollIntoView({block: 'center', behavior: 'smooth'});
    return true;
  }
  function styleRow(target, label, color, icon){
    const doc = target.ownerDocument;
    const rgb = color === '#ef4444' ? '239,68,68' : '16,185,129';
    const badge = doc.createElement('span');
    badge.textContent = label;
    const grad = color === '#ef4444' ? '#f87171,#dc2626' : '#22c55e,#059669';
    badge.style.cssText = `all:initial;display:inline-flex;align-items:center;margin-left:12px;padding:4px 12px;border-radius:999px;background:linear-gradient(135deg,${grad});color:#fff;font:700 13px system-ui,-apple-system,sans-serif;letter-spacing:.02em;vertical-align:middle;box-shadow:0 3px 10px rgba(${rgb},.35);white-space:nowrap`;
    const st = target.style;
    marks.push([target, {outline: st.outline, outlineOffset: st.outlineOffset, background: st.background, boxShadow: st.boxShadow, borderRadius: st.borderRadius, transition: st.transition}, badge]);
    st.transition = 'box-shadow .5s ease, background .5s ease';
    st.outline = `2px solid ${color}`; st.outlineOffset = '2px'; st.borderRadius = '10px';
    st.background = `linear-gradient(90deg, rgba(${rgb},.22), rgba(${rgb},.08))`;
    const sh1 = `0 0 0 6px rgba(${rgb},.18), 0 4px 14px rgba(${rgb},.25)`, sh2 = `0 0 0 12px rgba(${rgb},.30), 0 4px 18px rgba(${rgb},.35)`;
    st.boxShadow = sh1;
    if(icon){ const is = icon.style; marks.push([icon, {outline: is.outline, outlineOffset: is.outlineOffset, borderRadius: is.borderRadius, boxShadow: is.boxShadow}]); is.outline = `3px solid ${color}`; is.outlineOffset = '3px'; is.borderRadius = '50%'; is.boxShadow = `0 0 0 7px rgba(${rgb},.3)`; }
    (target.querySelector('span,p,div,label') && target.children.length === 1 ? target.children[0] : target).appendChild(badge);
    let n = 0; const pulse = setInterval(() => { st.boxShadow = (n++ % 2) ? sh1 : sh2; if(n > 5){ clearInterval(pulse); st.boxShadow = sh1; } }, 500);
  }
  // verdadero/falso: marca la fila y el botón ✓ o ✗ que toca
  function markVF(stmt, isTrue){
    const row = findOption(stmt); if(!row) return false;
    const icons = rowIcons(row);
    const hint = x => ((x.getAttribute('aria-label') || '') + ' ' + (x.getAttribute('title') || '') + ' ' + (x.getAttribute('class') || '') + ' ' + (x.getAttribute('alt') || '') + ' ' + (x.getAttribute('data-value') || '')).toLowerCase();
    let icon = null;
    if(icons.length >= 2){
      icon = icons.find(x => isTrue ? /(true|correct|cert|vertader|verdader|check|tick|ok|yes|v)/.test(hint(x)) : /(false|incorrect|wrong|fals|cross|close|x|no)/.test(hint(x)));
      if(!icon) icon = isTrue ? icons[1] : icons[0];   // en Electude: primero ✗, luego ✓
    }
    styleRow(row, isTrue ? '✓ Verdadero' : '✗ Falso', isTrue ? '#10b981' : '#ef4444', icon);
    return true;
  }
  // puntos sobre el dibujo (coordenadas 0-1000 de la captura)
  let pinHost = null;
  function clearPins(){ if(pinHost){ pinHost.remove(); pinHost = null; } }
  function snapHotspot(x, y, used = []){
    let best = null, bd = 1e9;
    for(let r = 0; r <= 48; r += 8) for(let a = 0; a < (r ? 12 : 1); a++){
      const px = x + r * Math.cos(a * Math.PI / 6), py = y + r * Math.sin(a * Math.PI / 6);
      for(const el of document.elementsFromPoint(px, py)){
        if(el.closest('#__msElecHost,#__msElecPins')) continue;
        const b = el.getBoundingClientRect(); if(b.width < 6 || b.height < 6 || b.width > 70 || b.height > 70) continue;
        const cs = getComputedStyle(el);
        if(!(cs.cursor === 'pointer' || /circle|button|hotspot|point|dot|marker/i.test((el.getAttribute('class') || '') + el.tagName) || el.getAttribute('role') === 'button')) continue;
        const cx = b.left + b.width / 2, cy = b.top + b.height / 2, d = Math.hypot(cx - x, cy - y);
        if(used.some(u => Math.hypot(u[0] - cx, u[1] - cy) < 6)) continue;
        if(d < bd){ bd = d; best = [cx, cy]; }
      }
    }
    return best;
  }
  function drawPins(points){
    clearPins();
    pinHost = document.createElement('div'); pinHost.id = '__msElecPins';
    pinHost.style.cssText = 'all:initial;position:absolute;left:0;top:0;width:0;height:0;z-index:2147483646;pointer-events:none';
    const sr = pinHost.attachShadow({mode: 'open'});
    sr.innerHTML = `<style>
      .pin{position:absolute;width:46px;height:46px;margin:-23px 0 0 -23px;border-radius:50%;border:3px solid #10b981;background:rgba(16,185,129,.18);box-shadow:0 0 0 4px rgba(255,255,255,.85),0 4px 14px rgba(0,0,0,.3);animation:p 1.1s ease-in-out 4}
      .pin::after{content:'';position:absolute;left:50%;top:50%;width:8px;height:8px;margin:-4px 0 0 -4px;border-radius:50%;background:#059669}
      .num{position:absolute;left:50%;top:50%;width:26px;height:26px;margin:-13px 0 0 -13px;border-radius:50%;background:linear-gradient(135deg,#22c55e,#059669);color:#fff;font:800 15px/26px system-ui,sans-serif;text-align:center;box-shadow:0 0 0 2px #fff,0 2px 6px rgba(0,0,0,.35);z-index:1}
      .pin.multi::after{display:none}
      .n{position:absolute;left:30px;top:-14px;min-width:22px;height:22px;padding:0 6px;border-radius:11px;background:linear-gradient(135deg,#22c55e,#059669);color:#fff;font:700 12px/22px system-ui,sans-serif;text-align:center;box-shadow:0 2px 6px rgba(0,0,0,.3);white-space:nowrap}
      @keyframes p{50%{transform:scale(1.35);box-shadow:0 0 0 10px rgba(16,185,129,.25),0 4px 14px rgba(0,0,0,.3)}}
    </style>`;
    const used = [], multi = points.length > 1;
    points.forEach((p, i) => {
      let x = p.x / 1000 * innerWidth, y = p.y / 1000 * innerHeight;
      const s = snapHotspot(x, y, used); if(s){ x = s[0]; y = s[1]; used.push(s); }
      const d = document.createElement('div'); d.className = 'pin' + (multi ? ' multi' : ''); d.style.left = (x + scrollX) + 'px'; d.style.top = (y + scrollY) + 'px';
      d.innerHTML = `${multi ? `<span class="num">${i + 1}</span>` : ''}<span class="n">${multi ? (i + 1) + ' · ' : ''}${esc(p.label || 'Aquí').slice(0, 40)}</span>`;
      sr.appendChild(d);
    });
    document.documentElement.appendChild(pinHost);
  }
  const send = m => new Promise(res => { try{ const p = api.runtime.sendMessage(m, r => res(r)); if(p && p.then) p.then(res, e => res({error: e.message})); }catch(e){ res({error: e.message}); } });
  // ---------- IA en tu propio ordenador (Gemini Nano de Chrome), solo si aceptas ----------
  const LM = globalThis.LanguageModel;
  let localOn = false;
  const loc = $('.loc');
  async function renderLocal(){
    if(!LM){ loc.innerHTML = ''; return; }
    let av = 'unavailable'; try{ av = await LM.availability({expectedInputs: [{type: 'text'}, {type: 'image'}]}); }catch(e){ try{ av = await LM.availability(); }catch(_){} }
    if(av === 'unavailable'){ loc.innerHTML = ''; return; }
    loc.innerHTML = `<span class="chip ${localOn ? 'on' : ''}" title="Usa la IA que trae Chrome, ejecutada en tu ordenador">⚡ IA de tu ordenador: ${localOn ? 'activada' : 'desactivada'}</span>`;
    loc.querySelector('.chip').onclick = () => {
      if(localOn){ localOn = false; api.storage.local.set({localAI: false}); renderLocal(); return; }
      loc.innerHTML = `<div class="ask"><b>¿Usar la potencia de tu ordenador?</b><br>Chrome ejecutará su IA (Gemini Nano) en este ordenador: funciona sin internet y, en ordenadores potentes, responde más rápido. ${av === 'available' ? '' : 'La primera vez Chrome descargará el modelo (unos GB; necesita bastante espacio libre en el disco).'}<br><small>Es menos precisa que Gemini o Claude en la nube. Si falla o la pregunta es sobre el dibujo, se usará la IA en la nube.</small><div class="row"><button class="sm" data-y>Aceptar</button><button class="sm" data-n>No, gracias</button></div><div class="dl"></div></div>`;
      loc.querySelector('[data-n]').onclick = () => renderLocal();
      loc.querySelector('[data-y]').onclick = async () => {
        const dl = loc.querySelector('.dl');
        try{
          dl.textContent = 'Preparando la IA local…';
          const s = await LM.create({monitor(m){ m.addEventListener('downloadprogress', ev => { dl.textContent = 'Descargando el modelo… ' + Math.round((ev.loaded || 0) * 100) + '%'; }); }});
          s.destroy && s.destroy();
          localOn = true; api.storage.local.set({localAI: true}); renderLocal();
        }catch(err){ dl.textContent = 'No se pudo activar en este ordenador: ' + err.message; }
      };
    };
  }
  try{ api.storage.local.get('localAI').then ? api.storage.local.get('localAI').then(r => { localOn = !!r.localAI; renderLocal(); }) : api.storage.local.get('localAI', r => { localOn = !!r.localAI; renderLocal(); }); }catch(e){}
  async function askLocal(text, dataUrl){
    const {prompt} = await send({type: 'elecPrompt'});
    let s = null;
    try{
      const content = [{type: 'text', value: prompt + '\n\n--- TEXTO DE LA PÁGINA ---\n' + text}];
      if(dataUrl){ try{ s = await LM.create({expectedInputs: [{type: 'text'}, {type: 'image'}]}); content.push({type: 'image', value: await (await fetch(dataUrl)).blob()}); }catch(e){ s = null; content.length = 1; } }
      if(!s) s = await LM.create();
      const out = await s.prompt([{role: 'user', content}]);
      return {text: out, local: true};
    }finally{ try{ s && s.destroy(); }catch(e){} }
  }
  // filas con dos botones (✗ y ✓): son preguntas de «cert o fals» para CADA fila, puede haber varias correctas
  const isIconish = el => { if(!el.getBoundingClientRect) return false; const r = el.getBoundingClientRect(); return r.width >= 10 && r.height >= 10 && r.width <= 50 && r.height <= 50 && Math.abs(r.width - r.height) < 14 && (el.innerText || el.textContent || '').trim().length <= 2; };
  function rowIcons(row){
    const all = [...row.querySelectorAll('*')].filter(isIconish);
    const top = all.filter(x => !all.some(y => y !== x && y.contains(x)));
    // solo los que están a la izquierda del texto (o en línea con él)
    return top.sort((a, b) => a.getBoundingClientRect().left - b.getBoundingClientRect().left);
  }
  function vfRows(){
    const rows = new Set();
    for(const d of docs()) for(const ic of rootOf(d).querySelectorAll('*')){
      if(!isIconish(ic) || (ic.closest && ic.closest('#__msElecHost,#__msElecPins'))) continue;
      const row = optionRow(ic); if(!row || rows.has(row)) continue;
      const t = (row.innerText || '').trim();
      if(rowIcons(row).length >= 2 && t.length >= 2 && t.length < 300 && visible(row)) rows.add(row);
    }
    return [...rows].filter(r => ![...rows].some(o => o !== r && o.contains(r))).map(r => (r.innerText || '').replace(/✓ (Respuesta IA|Verdadero)|✗ Falso/g, '').trim());
  }
  async function analyze(){
    clearMarks(); go.disabled = true; go.innerHTML = '<span class="spin"></span> Analizando…'; out.innerHTML = '';
    try{
      host.style.visibility = 'hidden'; await new Promise(r => setTimeout(r, 150));
      const shot = await send({type: 'elecShot'});
      host.style.visibility = '';
      if(!(shot && shot.dataUrl)) go.innerHTML = '<span class="spin"></span> Analizando (solo texto)…';
      const vr = vfRows();
      const ptxt = pageText() + (vr.length >= 2 ? '\n\n[NOTA DE ESTRUCTURA: esta actividad es de «cert o fals» (correcte/fals): cada una de estas ' + vr.length + ' afirmaciones tiene su propio botón ✗ y ✓, y puede haber VARIAS correctas. Responde con una línea VF para CADA una, sin RESPUESTA:]\n' + vr.map(t => '- ' + t).join('\n') : ''), img = shot && shot.dataUrl || null;
      let r = null;
      if(localOn && LM){
        go.innerHTML = '<span class="spin"></span> Analizando en tu ordenador…';
        try{ r = await askLocal(ptxt, img); if(!/(RESPUESTA|VF|PUNTO|ACCI[OÓ]N)\s*:/i.test(r.text || '')) r = null; }catch(e){ r = null; }
        if(!r) go.innerHTML = '<span class="spin"></span> Analizando en la nube…';
      }
      if(!r){ if(mode === 'precise') go.innerHTML = '<span class="spin"></span> Pensando con el modelo preciso…'; r = await send({type: 'elecAsk', text: ptxt, image: img, url: location.href, mode}); }
      if(!r || r.error){
        out.innerHTML = `<div class="err">${esc(r && r.error || 'No se pudo contactar con la IA.')}</div>` + (r && r.nokey ? '<div class="row"><button class="sm" data-cl>✳ Preguntar en Claude</button><button class="sm" data-app>🔑 Añadir clave</button></div>' : '');
        const b = out.querySelector('[data-app]'); if(b) b.onclick = () => send({type: 'openApp'});
        const c = out.querySelector('[data-cl]'); if(c) c.onclick = () => send({type: 'openClaude', q: r.prompt || ''});
        return;
      }
      const txt = String(r.text || '').replace(/\*\*/g, '').trim();
      const why = (txt.match(/POR QU[EÉ]\s*:\s*([\s\S]+)/i) || [])[1];
      const answers = [...txt.matchAll(/^\s*RESPUESTA\s*:\s*(.+)$/gim)].map(m => m[1].trim());
      const vfs = [...txt.matchAll(/^\s*VF\s*:\s*(.+?)\s*=>?\s*(V|F|VERDADERO|FALSO)\b\s*(?:[|\-–:]\s*(.+))?$/gim)].map(m => ({s: m[1].replace(/^["«]|["»]$/g, '').trim(), t: /^V/i.test(m[2]), why: (m[3] || '').trim()}));
      const pins = [...txt.matchAll(/^\s*PUNTO\s*:\s*(.*?)\s*\|?\s*x\s*=\s*(\d+(?:\.\d+)?)\s*[,;]?\s*y\s*=\s*(\d+(?:\.\d+)?)/gim)].map(m => ({label: m[1].replace(/[|:\-\s]+$/, '').trim(), x: Math.min(1000, +m[2]), y: Math.min(1000, +m[3])}));
      const acts = [...txt.matchAll(/^\s*ACCI[OÓ]N\s*:\s*(.+)$/gim)].map(m => m[1].trim());
      let html = '', notes = [];
      if(answers.length){
        let ok = 0; answers.forEach(a => { if(mark(a)) ok++; });
        html += `<div class="ans"><div class="top">💡 Respuesta sugerida</div>${answers.map(a => `<div class="pick"><span class="ck">✓</span><span>${esc(a.replace(/[.\s]+$/, ''))}</span></div>`).join('')}</div>`;
        notes.push(ok ? '✓ La opción está resaltada en verde en la página.' : 'No he encontrado la opción en la página para señalarla; mírala arriba.');
      }
      if(vfs.length){
        let ok = 0; vfs.forEach(v => { if(markVF(v.s, v.t)) ok++; });
        html += `<div class="ans"><div class="top">⚖️ Verdadero o falso</div><div class="vf">${vfs.map(v => `<div class="vfr"><span class="pill ${v.t ? 'v' : 'f'}">${v.t ? '✓ V' : '✗ F'}</span><span>${esc(v.s.replace(/[.\s]+$/, ''))}${v.why ? `<small class="vw">${esc(v.why)}</small>` : ''}</span></div>`).join('')}</div></div>`;
        notes.push(ok ? `✓ He marcado en la página ${ok === vfs.length ? 'cada afirmación' : ok + ' de ' + vfs.length + ' afirmaciones'} con el botón que toca (verde ✓ verdadero, rojo ✗ falso).` : 'No he encontrado las afirmaciones en la página; míralas arriba.');
      }
      if(pins.length){
        if(shot && shot.dataUrl){ drawPins(pins); notes.push(pins.length > 1 ? '📍 He numerado en el dibujo cada componente en el orden de la lista: haz clic en el 1, luego en el 2…' : '📍 He puesto un círculo verde en el dibujo donde hay que hacer clic.'); }
        html += `<div class="ans"><div class="top">📍 ${pins.length > 1 ? 'Orden de clics en el dibujo' : 'Haz clic en el dibujo'}</div><div class="vf">${pins.map((p, i) => `<div class="vfr"><span class="pill v">${pins.length > 1 ? i + 1 : '📍'}</span><span>${esc(p.label || 'Punto señalado')}</span></div>`).join('')}</div></div>`;
      }
      if(acts.length) html += `<div class="ans"><div class="top">👆 Qué hacer</div><div class="vf">${acts.map(a => `<div class="vfr"><span>${esc(a)}</span></div>`).join('')}</div></div>`;
      if(why && html) html = html.replace(/<\/div>$/, `<div class="why"><i>Por qué</i>${esc(why.trim())}</div></div>`);
      out.innerHTML = html || `<div class="why">${esc(txt)}</div>`;
      notes.forEach(n => out.insertAdjacentHTML('beforeend', `<div class="note">${n}</div>`));
      if(!(shot && shot.dataUrl)){
        out.insertAdjacentHTML('beforeend', '<div class="warn"><span>📸 <b>La IA no ha podido ver la pantalla</b>, solo el texto. Para preguntas sobre el dibujo (hacer clic, localizar piezas) necesita verla.</span><button class="sm" data-perm>Permitir que vea la pantalla de Electude</button><span>o pulsa una vez el icono de la extensión 🧩 en esta pestaña.</span></div>');
        const p = out.querySelector('[data-perm]'); if(p) p.onclick = () => send({type: 'askPerm'});
      }
    }catch(e){ out.innerHTML = `<div class="err">${esc(e.message)}</div>`; }
    finally{ host.style.visibility = ''; go.disabled = false; go.textContent = '🔍 Analizar la pregunta'; }
  }
  go.onclick = analyze;
  let mode = 'precise';
  const setMode = (m, save) => { mode = m === 'fast' ? 'fast' : 'precise'; root.querySelectorAll('.mode button').forEach(b => b.classList.toggle('on', b.dataset.m === mode)); if(save) api.storage.local.set({elecMode: mode}); };
  root.querySelectorAll('.mode button').forEach(b => b.onclick = () => setMode(b.dataset.m, true));
  setMode('precise');
  try{ const g = api.storage.local.get('elecMode'); if(g && g.then) g.then(r => setMode(r.elecMode || 'precise')); else api.storage.local.get('elecMode', r => setMode(r.elecMode || 'precise')); }catch(e){}
  let updChecked = false;
  async function showUpdate(){
    if(updChecked) return; updChecked = true;
    const u = await send({type: 'checkUpdate'});
    if(u && u.newer){
      $('.upd').innerHTML = `<div class="warn"><span>🆕 <b>Hay una versión nueva de la extensión</b> (tienes la v${esc(u.mine)}, nueva v${esc(u.latest)}).</span><button class="sm" data-u>Cómo actualizarla</button></div>`;
      $('.upd [data-u]').onclick = () => send({type: 'openUpdate'});
      fab.title = 'Hay una versión nueva de la extensión';
    }
  }
  setTimeout(showUpdate, 1500);
  $('.diag').onclick = async ev => {
    ev.preventDefault();
    const D = docs(), path = el => { const p = []; for(let n = el, k = 0; n && k < 6 && n.tagName; n = n.parentElement || (n.getRootNode && n.getRootNode().host), k++) p.unshift(n.tagName.toLowerCase() + (n.id ? '#' + n.id : '') + (typeof n.className === 'string' && n.className ? '.' + n.className.trim().split(/\s+/).slice(0, 2).join('.') : '')); return p.join(' > '); };
    const ifr = [...document.querySelectorAll('iframe')].map(f => { let same = false; try{ same = !!f.contentDocument; }catch(e){} return (f.src || '').replace(/\?.*/, '').slice(0, 80) + (same ? ' (accesible)' : ' (otro origen)'); });
    const icons = []; for(const d of D) for(const el of rootOf(d).querySelectorAll('*')) if(isIconish(el) && !(el.closest && el.closest('#__msElecHost'))) icons.push(path(el));
    const info = {v: api.runtime.getManifest().version, url: location.href.replace(/\?.*/, ''), zonas: D.length, iframes: ifr, filasVF: vfRows(), iconos: icons.slice(0, 12), texto: pageText().slice(0, 600)};
    const s = JSON.stringify(info, null, 1);
    try{ await navigator.clipboard.writeText(s); ev.target.textContent = '✅ Copiado: pégalo en el chat'; }catch(e){ out.innerHTML = '<div class="why" style="font-size:11px">' + esc(s) + '</div>'; }
  };
  // ---------- pasar a la siguiente después de que TÚ compruebes y salga «Correcte» ----------
  // No elige ni comprueba respuestas: solo pulsa la flecha de «siguiente» por ti.
  let nextOn = false, fbWas = false, cdTimer = null;
  const OKFB = /^\s*(correcte|correcto|correct|ben fet|molt bé|muy bien)\b/i;
  const visible = el => { const r = el.getBoundingClientRect(); const cs = el.ownerDocument.defaultView.getComputedStyle(el); return r.width > 0 && r.height > 0 && cs.visibility !== 'hidden' && cs.display !== 'none'; };
  const disabled = el => el.disabled || el.getAttribute('aria-disabled') === 'true' || /disabled|inactive/i.test(el.getAttribute('class') || '') || parseFloat(el.ownerDocument.defaultView.getComputedStyle(el).opacity) < 0.6;
  function okFeedback(){
    for(const d of docs()) for(const el of rootOf(d).querySelectorAll('div,p,span,section')){
      if(el.closest('#__msElecHost')) continue;
      const t = (el.innerText || '').trim(); if(t.length > 400 || !OKFB.test(t)) continue;
      if(visible(el)) return el;
    }
    return null;
  }
  function findNext(near){
    const all = [];
    for(const d of docs()) all.push(...d.querySelectorAll('button,a,[role=button],[onclick]'));
    const c = all.filter(el => !el.closest('#__msElecHost') && visible(el) && !disabled(el));
    const hint = el => ((el.getAttribute('aria-label') || '') + ' ' + (el.getAttribute('title') || '') + ' ' + (el.getAttribute('class') || '') + ' ' + (el.id || '') + ' ' + (el.innerText || '')).toLowerCase();
    const named = c.filter(el => /(next|seg[uü]ent|siguiente|endavant|forward|chevron-right|arrow-right|continua|continuar)/.test(hint(el)) && !/(prev|anterior|back|enrere|left)/.test(hint(el)));
    if(named.length) return named.sort((a, b) => b.getBoundingClientRect().left - a.getBoundingClientRect().left)[0];
    // flechas sin nombre: botones pequeños sin texto, debajo del recuadro de la respuesta; la de más a la derecha
    const nb = near ? near.getBoundingClientRect() : null;
    const icons = c.filter(el => { const r = el.getBoundingClientRect(); return !(el.innerText || '').trim() && r.width <= 70 && r.height <= 70 && (!nb || (r.top >= nb.top - 10 && r.top - nb.bottom < 200)); });
    if(icons.length >= 2) return icons.sort((a, b) => b.getBoundingClientRect().left - a.getBoundingClientRect().left)[0];
    return null;
  }
  function cancelCd(){ clearInterval(cdTimer); cdTimer = null; $('.cd').classList.remove('on'); }
  $('.cdx').onclick = cancelCd;
  function startCd(fb){
    if(cdTimer) return;
    let n = 2; const cd = $('.cd'), t = $('.cdt');
    t.textContent = '✅ Correcte · paso a la siguiente en ' + n + '…'; cd.classList.add('on');
    cdTimer = setInterval(() => {
      n--; if(n > 0){ t.textContent = '✅ Correcte · paso a la siguiente en ' + n + '…'; return; }
      cancelCd();
      const nx = findNext(fb);
      if(nx){ nx.click(); } else { t.textContent = 'No encuentro el botón de siguiente: pásalo tú.'; cd.classList.add('on'); setTimeout(() => cd.classList.remove('on'), 2500); }
    }, 1000);
  }
  function checkNext(){
    if(!nextOn) return;
    const fb = okFeedback(), now = !!fb;
    if(now && !fbWas) startCd(fb);
    if(!now && cdTimer) cancelCd();
    fbWas = now;
  }
  function setNext(v, save){ nextOn = v; $('.nextChk').checked = v; fbWas = !!okFeedback(); if(save) api.storage.local.set({elecNext: v}); if(!v) cancelCd(); }
  $('.nextChk').onchange = ev => setNext(ev.target.checked, true);
  try{ const g = api.storage.local.get('elecNext'); if(g && g.then) g.then(r => setNext(!!r.elecNext)); else api.storage.local.get('elecNext', r => setNext(!!r.elecNext)); }catch(e){}
  // ---------- modo automático: analiza solo cuando cambia el ejercicio ----------
  let autoOn = false, lastSig = '', autoTimer = null, busy = false, lastRun = 0;
  const FEED = /^(correcte|incorrecte|correcto|incorrecto|torna-ho a provar|vuelve a intentarlo|ben fet|molt bé|muy bien|resposta correcta|respuesta correcta)\b.*$/gim;
  const sig = () => pageText().replace(/✓ Respuesta IA|✓ Verdadero|✗ Falso/g, '').replace(FEED, '').replace(/\s+/g, ' ').trim();
  const looksLikeTask = t => /\?|clica|haz clic|fes clic|localitza|localiza|selecciona|marca|indica|mou |mueve|arrossega|arrastra|escriu|escribe|tria|elige|verdader|vertader|fals[oe]?\b/i.test(t);
  function setAuto(v, save){
    autoOn = v; $('.autoChk').checked = v; fab.classList.toggle('auto', v);
    if(save) api.storage.local.set({elecAuto: v});
    if(v){ lastSig = ''; scheduleAuto(300); }
  }
  function scheduleAuto(ms = 1200){
    if(!autoOn) return;
    clearTimeout(autoTimer);
    autoTimer = setTimeout(async () => {
      if(!autoOn || busy || document.hidden) return;
      const s = sig(); if(!s || s === lastSig || !looksLikeTask(s)) return;
      if(Date.now() - lastRun < 3000){ scheduleAuto(3000); return; }
      lastSig = s; lastRun = Date.now();
      open(true); busy = true; try{ await analyze(); }finally{ busy = false; lastSig = sig(); }
    }, ms);
  }
  $('.autoChk').onchange = ev => setAuto(ev.target.checked, true);
  try{ const g = api.storage.local.get('elecAuto'); if(g && g.then) g.then(r => setAuto(!!r.elecAuto)); else api.storage.local.get('elecAuto', r => setAuto(!!r.elecAuto)); }catch(e){}
  const watch = d => { try{ new MutationObserver(muts => { if(nextOn) setTimeout(checkNext, 250); if(autoOn && !busy && muts.some(m => !(m.target.closest && m.target.closest('#__msElecPins')))) scheduleAuto(); }).observe(d.body || d.documentElement, {childList: true, subtree: true, characterData: true}); }catch(e){} };
  const startWatch = () => { docs().forEach(watch); document.querySelectorAll('iframe').forEach(f => f.addEventListener('load', () => { try{ watch(f.contentDocument); }catch(e){} scheduleAuto(); })); };
  if(document.body) startWatch(); else document.addEventListener('DOMContentLoaded', startWatch);
  document.addEventListener('visibilitychange', () => { if(!document.hidden) scheduleAuto(600); });
  api.runtime.onMessage.addListener(m => { if(m && m.type === 'MS_ELEC_OPEN'){ open(true); if(m.analyze) analyze(); } });
  const mount = () => { if(!document.getElementById('__msElecHost')) (document.body || document.documentElement).appendChild(host); };
  if(document.body) mount(); else document.addEventListener('DOMContentLoaded', mount);
  new MutationObserver(() => { if(!host.isConnected) mount(); }).observe(document.documentElement, {childList: true, subtree: false});
})();
