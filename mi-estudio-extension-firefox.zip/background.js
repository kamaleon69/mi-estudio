// Mi Estudio · Sincronizar — abre Moodle/Classroom en una ventanita, lee tus tareas con tu sesión y se las pasa a la app.
if(typeof importScripts === 'function') importScripts('permissions-core.js','diagnostics.js','ai-providers.js','task-autofill.js','lens-core.js', 'electude-visual.js', 'electude-core.js', 'ollama.js');
const Providers = globalThis.MiEstudioAI;
const Core = globalThis.MiEstudioElectude;
const api = (typeof browser !== 'undefined' && browser.runtime) ? browser : chrome;   // Chrome/Edge usan api.*, Zen/Firefox browser.*
const APP_URL = 'https://kamaleon69.github.io/mi-estudio/';
const NAME = {moodle: 'Moodle', classroom: 'Classroom'};
const sleep = ms => new Promise(r => setTimeout(r, ms));
const tell = (tabId, msg) => { try{ const p = api.tabs.sendMessage(tabId, msg); if(p && p.catch) p.catch(() => {}); }catch(e){} };
let syncJob = null;
const aiJobs = new Map();
const access=new globalThis.MiEstudioPermissions.Access(api);
const isInternal=sender=>sender.id===api.runtime.id&&(!sender.url||sender.url.startsWith(api.runtime.getURL('')));
const workMessages=new Set(['sync','capture','localAsk','elecAsk','elecShot','elecVerifyVF','elecVerifyChoices','openLocalAI','localStatus','helperShot','helperChat','syncLogin']);

api.runtime.onMessage.addListener((m,sender,reply)=>{
  if(workMessages.has(m?.type)){access.ensure(sender.tab?.id).then(state=>{if(!state.ready){if(m.type==='capture')tell(sender.tab.id,{type:'MS_EXT_CAPERR',text:state.error});if(m.type==='sync'){tell(sender.tab.id,{type:'MS_EXT_SETUP_REQUIRED',text:state.error});tell(sender.tab.id,{type:'MS_EXT_DONE'});}reply(state);return;}handleMessage(m,sender,reply);}).catch(error=>reply({error:error.message}));return true;}
  return handleMessage(m,sender,reply);
});
function handleMessage(m, sender, reply){
  if(m?.type==='getSetupStatus'){access.status().then(reply);return true;}
  if(m?.type==='openSetup'||m?.type==='askPerm'){access.open(sender.tab?.id).then(()=>reply({opened:true}),error=>reply({error:error.message}));return true;}
  if(m?.type==='setupComplete'&&isInternal(sender)){access.finish().then(reply);return true;}
  if(m?.type==='setupStart'&&isInternal(sender)){access.start().then(reply);return true;}
  if(m?.type==='createErrorReport'&&sender.tab&&/^https:\/\/[^/]*\.electude\.eu\//.test(sender.tab.url||'')){saveErrorReport(m,sender).then(reply,error=>reply({error:error.message}));return true;}
  if(m?.type==='sync'&&sender.tab){runSync(sender.tab.id,m);reply({accepted:true});}
  if(m?.type==='syncCancel'&&syncJob&&sender.tab?.id===syncJob.owner){
    cancelSync(syncJob).then(()=>reply({cancelled:true}),error=>reply({error:error.message}));
    return true;
  }
  if(m?.type==='syncLogin'&&syncJob&&sender.tab?.id===syncJob.owner){
    focusLogin(syncJob,m.source).then(reply,error=>reply({error:error.message}));
    return true;
  }
  if(['helperShot','helperChat'].includes(m?.type)){
    if(!sender.tab||sender.frameId!==0||sender.id!==api.runtime.id||!isWebPage(sender.url)){
      reply({error:'Abre Lens desde el icono en una página web.'});
      return;
    }
    const operation=m.type==='helperShot'?helperShot(sender.tab,m.rect):helperChat(m);
    operation.then(reply,error=>reply({error:error.message}));
    return true;
  }
  if(m && m.type === 'capture' && sender.tab) captureElectude(sender.tab.id);
  if(m && m.type === 'keys'){ syncAISettings(m).then(reply, e => reply({error: e.message})); return true; }
  if(m && m.type === 'getAISettings'){ api.storage.local.get('ai').then(r => reply(Providers.publicSettings(r.ai || {}))); return true; }
  if(m && m.type === 'setAIProvider'){ selectAI(m).then(reply, e => reply({error: e.message})); return true; }
  if(m && m.type === 'openApp'){ openAppTab('#cfg-ai'); }
  if(m && m.type === 'openLocalAI'){ openLocalAI().then(reply, error => reply({error: error.message})); return true; }
  if(m && m.type === 'openLocalInternals'){ api.tabs.create({url: 'chrome://on-device-internals'}).catch(() => {}); return; }
  if(m && m.type === 'localStatus'){ localStatus().then(reply); return true; }
  if(m && m.type === 'localAsk' && sender.tab && /^https:\/\/[^/]*electude\.eu\//.test(sender.tab.url || '')){
    const previous=aiJobs.get(sender.tab.id);previous?.controller.abort();
    const job={controller:new AbortController(),requestId:m.requestId,local:true};aiJobs.set(sender.tab.id,job);
    askLocalModel(m,job.controller.signal).then(reply,error=>reply({error:error.message})).finally(()=>{if(aiJobs.get(sender.tab.id)===job)aiJobs.delete(sender.tab.id);});return true;
  }
  if(m && m.type === 'elecPrompt'){ reply({prompt: ELEC_PROMPT}); return; }
  if(m && m.type === 'checkUpdate'){ checkUpdate().then(reply); return true; }
  if(m && m.type === 'openUpdate'){ openAppTab('#ext-update'); }
  if(m && m.type === 'openClaude' && typeof m.q === 'string') api.tabs.create({url: 'https://claude.ai/new?q=' + encodeURIComponent(m.q.slice(0, 6500))});
  if(m && m.type === 'openElec' && sender.tab) (async () => {
    const ts = (await api.tabs.query({url: 'https://*.electude.eu/*'})).sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0));
    if(ts[0]){ await api.tabs.update(ts[0].id, {active: true}); if(api.windows && api.windows.update) await api.windows.update(ts[0].windowId, {focused: true}); }
    else await api.tabs.create({url: m.url});
    tell(sender.tab.id, {type: 'MS_EXT_ELEC_OPENED', existing: !!ts[0]});
  })();
  if(m && (m.type === 'elecShot' || m.type === 'elecAsk' || m.type === 'elecCancel' || m.type === 'elecVerifyVF' || m.type==='elecVerifyChoices') && sender.tab && /^https:\/\/[^/]*electude\.eu\//.test(sender.tab.url || '')){
    if(m.type === 'elecVerifyVF'||m.type==='elecVerifyChoices'){ verifyVFScreen(sender.tab,m).then(reply,error=>reply({error:error.message}));return true; }
    if(m.type === 'elecCancel'){ const job = aiJobs.get(sender.tab.id); if(job && job.requestId === m.requestId){job.controller.abort();if(job.local)api.runtime.sendMessage({type:'localRunnerCancel',requestId:m.requestId}).catch(()=>{});} reply({cancelled: true}); return; }
    if(m.type === 'elecShot'){ elecShot(sender.tab, m).then(reply, e => reply({error: e.message})); return true; }
    const previous = aiJobs.get(sender.tab.id); if(previous) previous.controller.abort();
    const job = {controller: new AbortController(), requestId: m.requestId}; aiJobs.set(sender.tab.id, job);
    elecAsk(m, job.controller.signal).then(reply, e => reply({error: e.message})).finally(() => { if(aiJobs.get(sender.tab.id) === job) aiJobs.delete(sender.tab.id); });
    return true;
  }
}
async function saveErrorReport(message,sender){
 const D=globalThis.MiEstudioDiagnostics,{ai={}}=await api.storage.local.get('ai'),secrets=Object.entries(ai).filter(([key])=>/key/i.test(key)).map(([,value])=>value);
 const report=D.create({...message.report,version:api.runtime.getManifest().version,sourceURL:D.safeURL(sender.tab.url)},secrets),id=Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,10);
 const draft={id,at:Date.now(),report,analysisImage:D.image(message.analysisImage)};
 try{await api.storage.local.set({errorReportDraft:draft});}catch{draft.analysisImage=null;await api.storage.local.set({errorReportDraft:draft});}
 await api.tabs.create({url:api.runtime.getURL('informe.html')+'#'+id});return{opened:true};
}
async function openLocalAI(){
  const url = api.runtime.getURL('local-ai.html'), tabs = (await api.tabs.query({})).filter(tab => tab.url === url);
  if(tabs[0]) await api.tabs.update(tabs[0].id, {active: true}); else await api.tabs.create({url});
  return {opened: true};
}
async function localRelay(message){
  try{
    const tabs = (await api.tabs.query({})).filter(tab => tab.url === api.runtime.getURL('local-ai.html'));
    if(!tabs.length) return {status: 'closed', error: 'Abre la página de IA local y pulsa Preparar.'};
    return await api.runtime.sendMessage(message) || {status: 'closed', error: 'La página de IA local no responde. Recárgala.'};
  }catch(error){ return {status: 'closed', error: 'La IA local no está preparada: ' + error.message}; }
}
async function localStatus(){
  const config=await api.storage.local.get(['localEngine','ollamaModel']);
  if(config.localEngine==='chrome') return {...await localRelay({type:'localRunnerStatus'}),engine:'chrome'};
  const allowed=await api.permissions.contains({origins:['http://127.0.0.1/*']});
  if(!allowed) return {status:'closed',engine:'ollama',error:'Abre Configurar IA local y permite la conexión a Ollama.'};
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),5000);
  try{return {...await new globalThis.MiEstudioOllama.Ollama().status(config.ollamaModel,controller.signal),engine:'ollama'};}
  catch(error){return {status:'error',engine:'ollama',error:error.name==='AbortError'?'Ollama no responde. Comprueba que esté abierto.':error.message};}
  finally{clearTimeout(timer);}
}
async function askLocalModel(message,signal){
  const config=await api.storage.local.get(['localEngine','ollamaModel']);
  const text=questionPrompt(message,false)+'\n\n'+String(message.text || '').slice(0,config.localEngine==='chrome'?10000:15000);
  if(config.localEngine==='chrome'){
    if(message.requiresVision) return {error:'Gemini Nano aquí solo admite texto. Usa Ollama con visión o desactiva IA local para consultar tu API.'};
    return localRelay({type:'localRunnerAsk',requestId:message.requestId,text});
  }
  if(!await api.permissions.contains({origins:['http://127.0.0.1/*']}))return {error:'Falta permiso local. Abre Configurar IA local y pulsa Conectar.'};
  const controller=new AbortController(),abort=()=>controller.abort(),timer=setTimeout(abort,180000);
  if(signal){if(signal.aborted)abort();else signal.addEventListener('abort',abort,{once:true});}
  try{return await new globalThis.MiEstudioOllama.Ollama().ask(config.ollamaModel,text,(message.requiresVision||message.manualQuiz)?message.image:null,controller.signal);}
  finally{clearTimeout(timer);signal?.removeEventListener('abort',abort);}
}
async function syncAISettings(m){
  const saved = await api.storage.local.get('aiSelectionOverride');
  const ai = Providers.mergeSelection(m, saved.aiSelectionOverride, m.selectionExplicit === true);
  await api.storage.local.set({ai, ...(m.selectionExplicit === true ? {aiSelectionOverride: null} : {})});
  return Providers.publicSettings(ai);
}
async function selectAI(m){
  const {ai = {}} = await api.storage.local.get('ai');
  const selected = {...ai, aiProvider: m.provider, geminiSlot: m.geminiSlot === 'secondary' ? 'secondary' : 'primary'};
  if(!Providers.hasKey(selected, m.provider)) return {error: 'Configura primero la clave de ese proveedor en Mi Estudio → Ajustes → Asistentes IA.'};
  await api.storage.local.set({ai: selected, aiSelectionOverride: {aiProvider: selected.aiProvider, geminiSlot: selected.geminiSlot}});
  for(const tab of await api.tabs.query({url: APP_URL + '*'})) tell(tab.id, {type: 'MS_EXT_AI_PREFS', provider: selected.aiProvider, geminiSlot: selected.geminiSlot});
  return Providers.publicSettings(selected);
}
// ---------- aviso de versión nueva (version.json en GitHub) ----------
const vLess = (a, b) => String(a || '0').localeCompare(String(b || '0'), undefined, {numeric: true}) < 0;
async function checkUpdate(){
  const mine = api.runtime.getManifest().version;
  if(!(await access.status()).ready)return{mine,needsSetup:true};
  try{
    const r = await fetch(APP_URL + 'version.json?t=' + Date.now(), {cache: 'no-store'}); if(!r.ok) return {mine};
    const v = await r.json(), latest = v && v.extension, newer = !!latest && vLess(mine, latest);
    try{ api.action.setBadgeText({text: newer ? 'NEW' : ''}); if(newer) api.action.setBadgeBackgroundColor({color: '#10b981'}); api.action.setTitle({title: newer ? 'Mi Estudio: hay una versión nueva (v' + latest + ')' : 'Mi Estudio (en Electude: ayuda IA)'}); }catch(e){}
    return {mine, latest, newer};
  }catch(e){ return {mine}; }
}
api.runtime.onInstalled.addListener(async details=>{await api.storage.local.set({installInfo:{temporary:details?.temporary===true,version:api.runtime.getManifest().version,at:Date.now()}});if(!(await access.status()).ready)await access.open();else checkUpdate();});
for(const event of [api.permissions.onAdded,api.permissions.onRemoved])event?.addListener(()=>access.notify().catch(()=>{}));
if(api.runtime.onStartup) api.runtime.onStartup.addListener(() => checkUpdate());
async function openAppTab(hash = ''){
  const [t] = await api.tabs.query({url: APP_URL + '*'});
  if(t){ await api.tabs.update(t.id, hash ? {active: true, url: APP_URL + hash} : {active: true}); if(api.windows && api.windows.update) await api.windows.update(t.windowId, {focused: true}); }
  else await api.tabs.create({url: APP_URL + hash});
}
// ---------- Ayuda IA en Electude ----------
async function elecShot(tab, request = {}){
  let dataUrl;
  try{
    const [before] = await api.tabs.query({active: true, windowId: tab.windowId});
    if(!before || before.id !== tab.id || before.url !== tab.url) return {dataUrl: null, needActive: true};
    dataUrl = await api.tabs.captureVisibleTab(tab.windowId, {format: 'jpeg', quality: 90});
    const [after] = await api.tabs.query({active: true, windowId: tab.windowId});
    if(!after || after.id !== tab.id || after.url !== before.url) return {dataUrl: null, needActive: true};
  }catch(e){ return {dataUrl: null, needPerm: true}; }
  let hotspots = [];
  try{
    const bmp = await createImageBitmap(await (await fetch(dataUrl)).blob());
    try{
      const k = Math.min(1, 1800 / bmp.width), canvas = new OffscreenCanvas(Math.round(bmp.width * k), Math.round(bmp.height * k));
      const context = canvas.getContext('2d', {willReadFrequently: true});
      context.drawImage(bmp, 0, 0, canvas.width, canvas.height);
      const viewport = request.viewport;
      if(viewport && viewport.width > 0 && viewport.height > 0 && Array.isArray(request.regions)){
        const pixels = globalThis.MiEstudioVisual.purpleDots(context.getImageData(0, 0, canvas.width, canvas.height));
        hotspots = globalThis.MiEstudioVisual.inventory(request.hotspots || [], pixels, request.regions.slice(0, 40), viewport);
        // Las etiquetas H identifican puntos detectados, sin alterar su centro.
        context.font = 'bold 14px sans-serif';
        for(const point of hotspots){
          const x = point.x / 1000 * canvas.width, y = point.y / 1000 * canvas.height;
          const label = point.id, w = context.measureText(label).width + 8;
          const lx = Math.max(0, Math.min(canvas.width - w, x + 9)), ly = Math.max(16, y - 9);
          context.strokeStyle = '#111827'; context.lineWidth = 2; context.beginPath(); context.arc(x, y, 6, 0, Math.PI * 2); context.stroke();
          context.fillStyle = '#fff'; context.fillRect(lx, ly - 15, w, 19); context.fillStyle = '#111827'; context.fillText(label, lx + 4, ly);
        }
      }
      const blob = await canvas.convertToBlob({type: 'image/jpeg', quality: .88});
      const bytes = new Uint8Array(await blob.arrayBuffer()); let binary = '';
      for(let i = 0; i < bytes.length; i += 0x8000) binary += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
      dataUrl = 'data:image/jpeg;base64,' + btoa(binary);
    }finally{ bmp.close(); }
  }catch(e){ /* La captura original sigue disponible, pero no se inventan puntos. */ }
  return {dataUrl, hotspots};
}
async function verifyVFScreen(tab, message){
  const shot = await elecShot(tab);
  if(!shot.dataUrl) return {error: 'No se pudo comprobar visualmente la selección de cierto/falso.'};
  const bitmap = await createImageBitmap(await (await fetch(shot.dataUrl)).blob());
  try{
    const canvas = new OffscreenCanvas(bitmap.width, bitmap.height), context = canvas.getContext('2d', {willReadFrequently: true});
    context.drawImage(bitmap, 0, 0);
    const pixels=context.getImageData(0,0,bitmap.width,bitmap.height);
    return {rows:message.type==='elecVerifyChoices'?globalThis.MiEstudioVisual.readChoices(pixels,(message.choices||[]).slice(0,40)):globalThis.MiEstudioVisual.readVFPairs(pixels,(message.pairs||[]).slice(0,40))};
  }finally{ bitmap.close(); }
}
const ELEC_PROMPT = `Eres un profesor de automoción y electricidad/electrónica que ayuda a entender una actividad de Electude.
Lee la teoría de ESTA página y la actividad activa. La teoría aporta evidencia; sus títulos y listas no son opciones de respuesta. Ten en cuenta negaciones, unidades, condiciones y el estado visible del dibujo. No presupongas el resultado de otras lecciones ni inventes datos que falten. Si la imagen o la información necesaria no están disponibles, indícalo y no adivines.
El texto empieza con un inventario de controles reales de la actividad, con identificadores. Estos IDs tienen prioridad sobre una interpretación visual: las opciones O son elecciones, las afirmaciones V son verdadero/falso y los campos C son valores o desplegables. Si la actividad tiene un campo numérico y pregunta qué número identifica una pieza del dibujo, responde CAMPO: C1 => número; los números de la figura son etiquetas, nunca opciones O. Sigue la línea guía desde cada etiqueta hasta la pieza y distingue la pieza solicitada de elementos contiguos. No uses el número de pregunta ni el valor ya escrito como respuesta. No confundas varias casillas con una sola respuesta ni confundas la pareja verdadero/falso de cada fila con dos opciones independientes.
Devuelve texto sin Markdown ni código, en este formato:
ANÁLISIS: <resumen breve de la evidencia relevante, 1-3 frases, sin razonamiento paso a paso>
RESPUESTA: [O2]
Usa una línea RESPUESTA por opción elegida; una sola por grupo radio, varias si son casillas checkbox. Usa SOLO IDs O del inventario. Si no hay inventario de opciones, copia literalmente la opción del recuadro activo.
VF: [V1] => V | <justificación breve>
Usa una línea VF por CADA afirmación del inventario, sin omitir ni duplicar IDs; V significa verdadero y F falso. Si no hay inventario, copia literalmente la afirmación del recuadro activo.
CAMPO: C1 => <valor exacto>
Usa una línea CAMPO por CADA campo. En campos numéricos da solo el número, sin unidades, con punto decimal; comprueba las unidades que pide el enunciado. En desplegables usa el value de una de sus opciones, exactamente. En texto, da únicamente el texto que hay que escribir. No pongas comillas ni explicaciones en el valor.
Escribe SOLO los tipos de línea que correspondan a los controles de la actividad. No mezcles IDs con otros ejercicios ni inventes selectores. Revisa que todos los grupos, afirmaciones y campos tengan respuesta.
Para localizar piezas en el dibujo: recibe un inventario H de puntos detectados y sus etiquetas H sobre la captura. Responde PUNTO: <nombre> | id=H3, una línea por componente en el orden exacto pedido. Elige SOLO un ID H del inventario por componente, sin repetir IDs. Sigue las líneas guía y relaciona la pieza con su punto de clic real, no con el centro visual de la pieza. Si el punto no existe o la asociación es ambigua, no inventes IDs ni coordenadas: usa ACCIÓN para indicar que falta verificarlo y FIABILIDAD: BAJA. Para una acción manual no representada por los controles: ACCIÓN: <instrucción concreta>.
FIABILIDAD: <ALTA, MEDIA o BAJA; usa BAJA si falta evidencia para contestar>
POR QUÉ: <explicación clara en 2-4 frases basada en la lección o en la imagen; si no hay apoyo explícito, di qué dato falta>.
Si hay una pregunta con opciones visibles, ofrece la sugerencia con RESPUESTA: y el texto exacto de la opción aunque el inventario esté vacío. Las instrucciones de inicio del cuestionario no son el enunciado. Si no se ve ninguna pregunta, dilo en una frase.`;
const VF_PROMPT = `
REGLAS ESPECÍFICAS DE CIERTO/FALSO:
Lee PRIMERO la pregunta común. Cada frase se evalúa respecto a ese enunciado y a su sujeto concreto. Una frase corta puede completar implícitamente la pregunta (p. ej., una propiedad, ventaja o condición); no la juzgues como un enunciado sin sujeto ni la confundas con una opción de respuesta única.
Conserva el catalán o español original y sus negaciones: no, mai/nunca, només/solo, sempre/siempre, més/más y menys/menos. Distingue la pieza de la que se habla de las piezas próximas. Comprueba las condiciones y el alcance de cada frase; no generalices la teoría de otro sistema o lección.
Evalúa CADA ID por separado. Todas las frases pueden ser verdaderas, todas falsas o cualquier mezcla. No impongas un reparto V/F. La ausencia de información NO convierte una frase en falsa: si no puedes justificarla, indica confianza BAJA.
Antes de emitir el resultado, contrasta cada decisión con la teoría de esta actividad y revisa si tu justificación realmente apoya V o contradice la afirmación para F. Da solo el resultado y una justificación breve por fila, sin razonamiento paso a paso.
Por CADA fila devuelve estas tres líneas (IDs, sin copiar ni reformular la afirmación):
VF: [V1] => V | <justificación concreta en una frase>
APOYO: [V1] => <cita literal breve de 3-25 palabras de la TEORÍA recibida, que respalde la justificación>
CONFIANZA: [V1] => ALTA
Usa ALTA, MEDIA o BAJA para CONFIANZA. Si falta evidencia, escribe APOYO: [V1] => SIN APOYO y CONFIANZA: [V1] => BAJA; no inventes citas. Las frases de la pregunta, las opciones ya marcadas y los colores de una corrección no son teoría ni prueba de su verdad. No uses RESPUESTA ni omitas filas cuando el inventario sea de verdadero/falso.
`;
function questionPrompt(message, precise){ return (message.vf ? 'Eres un tutor de automoción. Usa exclusivamente el contexto de esta lección.\n'+VF_PROMPT+'\nTermina con FIABILIDAD: ALTA, MEDIA o BAJA y POR QUÉ: una explicación breve.\n' : ELEC_PROMPT) + (message.manualQuiz ? '\nPrioriza la sección PREGUNTA VISIBLE PARA RESPONDER A MANO. Usa la captura si está presente. Empieza por RESPUESTA: y la propuesta, seguida de POR QUÉ. No inventes referencias a controles.' : '') + (precise ? '' : '\nSé conciso sin omitir filas, justificaciones ni evidencia.'); }
const G_CHAIN = ['gemini-3.5-flash-lite', 'gemini-flash-lite-latest', 'gemini-3.1-flash-lite'];
const G_PRECISE = ['gemini-3.8-flash', 'gemini-3.5-flash', 'gemini-flash-latest'];
const THINK_OK = {};
// lee tus claves de IA de Mi Estudio (localStorage de la app) por si no llegaron solas
async function keysFromApp(){
  let [t] = await api.tabs.query({url: APP_URL + '*'}), tmp = null;
  try{
    if(!t){ tmp = await api.tabs.create({url: APP_URL, active: false}); await waitLoad(tmp.id, 15000); t = tmp; }
    const [r] = await api.scripting.executeScript({target: {tabId: t.id}, func: () => { try{ return JSON.parse(localStorage.getItem('me_cfg') || '{}'); }catch(e){ return {}; } }});
    const k = Providers.cleanKeys((r && r.result) || {});
    if(Object.keys(Providers.NAMES).some(p => Providers.hasKey(k, p))) await syncAISettings(k);
    return (await api.storage.local.get('ai')).ai || k;
  }catch(e){ return {}; }
  finally{ if(tmp) try{ await api.tabs.remove(tmp.id); }catch(e){} }
}
let quotaStorePromise = null;
function quotaStore(){
  if(!quotaStorePromise) quotaStorePromise = api.storage.local.get('aiQuota').then(result => result.aiQuota || {}).catch(() => ({}));
  return quotaStorePromise;
}
async function rememberQuota(key, value){
  const saved = await quotaStore(); saved[key] = value;
  for(const id of Object.keys(saved)) if(saved[id].cooldownUntil <= Date.now()) delete saved[id];
  try{ await api.storage.local.set({aiQuota: saved}); }catch(e){}
}
async function checkQuota(provider, key, model){
  const saved = await quotaStore(), value = saved[Providers.quotaKey(provider, key, model)];
  return value && value.cooldownUntil > Date.now() ? value : null;
}
async function handleQuota(j, r, provider, key, model){
  const quota = Providers.quota(j, r.status, {provider, model, retryAfter: r.headers && r.headers.get && r.headers.get('retry-after')});
  if(quota) await rememberQuota(Providers.quotaKey(provider, key, model), quota);
  return quota;
}
// El límite cubre también la lectura del cuerpo y el conjunto de alternativas.
async function aiRequest(url, options, timeout, signal){
  const controller = new AbortController(), timer = setTimeout(() => controller.abort(), timeout);
  const onAbort = () => controller.abort();
  if(signal){ if(signal.aborted) controller.abort(); else signal.addEventListener('abort', onAbort, {once: true}); }
  try{
    const r = await fetch(url, {...options, signal: controller.signal});
    const j = await r.json().catch(() => ({}));
    return {r, j};
  }catch(e){ return {r: {ok: false, status: 0}, j: {error: {message: e.name === 'AbortError' ? 'se agotó el tiempo de espera' : e.message}}}; }
  finally{ clearTimeout(timer); signal?.removeEventListener('abort', onAbort); }
}
async function elecAsk(m, signal){
  if(signal?.aborted) return {cancelled: true};
  let {ai = {}} = await api.storage.local.get('ai');
  if(!Object.keys(Providers.NAMES).some(p => Providers.hasKey(ai, p))) ai = await keysFromApp();
  const img = !(m.vf && !m.requiresVision) && typeof m.image === 'string' && /^data:image\/jpeg;base64,/.test(m.image) ? m.image.split(',')[1] : null;
  const requirePrecise = m.requirePrecise === true;
  const precise = requirePrecise || m.mode !== 'fast';
  const P = questionPrompt(m, precise);
  const text = P + '\n\n--- TEXTO DE LA PÁGINA ---\n' + String(m.text || '').slice(0, 16000);
  const provider = Providers.provider(ai), activeGeminiKey = Providers.geminiKey(ai);
  if(!Providers.hasKey(ai, provider)) return {error: 'Añade una clave de Gemini, Groq, OpenRouter Free, Claude u OpenAI en Mi Estudio → Ajustes → Asistentes IA.', nokey: true, prompt: text.slice(0, 6500)};
  if(provider === 'groq' || provider === 'openrouter'){
    let config; try{ config = Providers.chatConfig(ai, provider); }catch(e){ return {error: e.message}; }
    const {url, key, model} = config;
    if(img && m.requiresVision && provider === 'groq' && /gpt-oss/.test(model)) return {error: 'Este modelo de Groq solo admite texto. Elige Qwen con visión en Ajustes para analizar imágenes.'};
    const paused = await checkQuota(provider, key, model);
    if(paused) return paused;
    const requestText = provider === 'groq' ? P + '\n\n' + String(m.text || '').slice(0, 8000) : text;
    const body = Providers.chatBody([{role: 'user', text: requestText, images: img && !(provider === 'groq' && /gpt-oss/.test(model)) ? [{mime: 'image/jpeg', data: img}] : []}], {model, maxOutputTokens: provider === 'groq' ? 1536 : 4096});
    const {r, j} = await aiRequest(url, {method: 'POST', headers: {'content-type': 'application/json', Authorization: 'Bearer ' + key}, body: JSON.stringify(body)}, 50000, signal);
    if(!r.ok || j.error) return await handleQuota(j, r, provider, key, model) || {error: Providers.NAMES[provider] + ': ' + (j.error && j.error.message || r.status)};
    const choice = j.choices && j.choices[0], output = choice && choice.message && choice.message.content;
    if(!choice || choice.finish_reason !== 'stop' || typeof output !== 'string' || !output.trim()) return {error: Providers.NAMES[provider] + ' devolvió una respuesta vacía o incompleta. No se aplicará.'};
    return {text: output, model: j.model || model, provider, precise};
  }
  if(provider === 'openai'){
    const model = ai.openaiModel || 'gpt-5.5', paused = await checkQuota('openai', ai.openaiKey, model);
    if(paused) return paused;
    const body = Providers.openaiBody([{role: 'user', text, images: img ? [{mime: 'image/jpeg', data: img}] : []}], {model, maxOutputTokens: 4096});
    const {r, j} = await aiRequest('https://api.openai.com/v1/responses', {method: 'POST', headers: {'content-type': 'application/json', Authorization: 'Bearer ' + ai.openaiKey}, body: JSON.stringify(body)}, 50000, signal);
    if(!r.ok) return await handleQuota(j, r, 'openai', ai.openaiKey, model) || {error: 'OpenAI: ' + ((j.error && j.error.message) || r.status)};
    if(j.error||j.status!=='completed')return {error:'OpenAI no ha terminado la respuesta ('+(j.status||'sin estado final')+'). No se aplicará.'};
    const output = Providers.outputText(j);
    return output.trim() ? {text: output, model, provider: 'openai', precise} : {error: 'OpenAI devolvió una respuesta vacía.'};
  }
  if(provider === 'claude'){
    const content = []; if(img) content.push({type: 'image', source: {type: 'base64', media_type: 'image/jpeg', data: img}}); content.push({type: 'text', text});
    const selected = ai.claudeModel || 'claude-sonnet-5-5';
    const model = precise ? (requirePrecise && /haiku/i.test(selected) ? 'claude-sonnet-5-5' : selected) : 'claude-haiku-5-5';
    const paused = await checkQuota('claude', ai.claudeKey, model); if(paused) return paused;
    const {r, j} = await aiRequest('https://api.anthropic.com/v1/messages', {method: 'POST', headers: {'content-type': 'application/json', 'x-api-key': ai.claudeKey, 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true'}, body: JSON.stringify({model, max_tokens: precise ? 3000 : 1800, messages: [{role: 'user', content}]})}, 45000, signal);
    if(!r.ok) return await handleQuota(j, r, 'claude', ai.claudeKey, model) || {error: 'Claude: ' + ((j.error && j.error.message) || r.status)};
    if(j.stop_reason !== 'end_turn') return {error: 'Claude devolvió una respuesta incompleta. Vuelve a analizarla.'};
    const output = (j.content || []).filter(c => c.type === 'text').map(c => c.text).join('\n');
    return output.trim() ? {text: output, model, precise: precise && !/haiku/i.test(model)} : {error: 'Claude devolvió una respuesta vacía.'};
  }
  const parts = [{text}]; if(img) parts.push({inline_data: {mime_type: 'image/jpeg', data: img}});
  const chosen = (ai.geminiModel || G_CHAIN[0]).replace(/^models\//, '');
  const candidates = precise ? (/lite/.test(chosen) ? [...G_PRECISE, chosen, ...G_CHAIN] : [chosen, ...G_PRECISE, ...G_CHAIN]) : (/lite/.test(chosen) ? [chosen, ...G_CHAIN] : [...G_CHAIN, chosen]);
  const chain = precise ? candidates.filter(model => !/lite/i.test(model)) : candidates;
  const deadline = Date.now() + 50000;
  let last = '', lastQuota = null;
  for(const model of [...new Set(chain)]){
    if(signal?.aborted) return {cancelled: true};
    const paused = await checkQuota('gemini', activeGeminiKey, model);
    if(paused){ if(!lastQuota || paused.cooldownUntil < lastQuota.cooldownUntil) lastQuota = paused; continue; }
    const fast = /lite/.test(model);
    const thinkOpts = THINK_OK[model] !== undefined ? [THINK_OK[model]] : [{thinkingLevel: 'low'}, {thinkingBudget: fast ? 0 : 256}, null];
    let r, j;
    for(const th of thinkOpts){
      const remaining = deadline - Date.now();
      if(remaining < 500) return {error: 'Gemini: se agotó el tiempo de espera. ' + last};
      const generationConfig = {temperature: 0.1, maxOutputTokens: fast && !m.vf ? 1800 : 3000}; if(th) generationConfig.thinkingConfig = th;
      ({r, j} = await aiRequest('https://generativelanguage.googleapis.com/v1beta/models/' + encodeURIComponent(model) + ':generateContent', {method: 'POST', headers: {'content-type': 'application/json', 'x-goog-api-key': activeGeminiKey}, body: JSON.stringify({contents: [{role: 'user', parts}], generationConfig})}, Math.min(remaining, fast ? 18000 : 22000), signal));
      if(r.status === 400 && /think/i.test((j.error && j.error.message) || '')) continue;
      if(r.ok) THINK_OK[model] = th;
      break;
    }
    if(r.ok){
      const candidate = (j.candidates || [])[0] || {};
      if(candidate.finishReason !== 'STOP'){last='respuesta no finalizada ('+(candidate.finishReason||'sin estado final')+')';if(candidate.finishReason==='MAX_TOKENS')continue;return {error:'Gemini: '+last+'. No se aplicará.'};}
      const output = ((candidate.content || {}).parts || []).filter(p => !p.thought).map(p => p.text || '').join('');
      if(output.trim()) return {text: output, model, precise: precise && !/lite/i.test(model)};
      last = 'respuesta vacía'; continue;
    }
    last = (j.error && j.error.message) || ('error ' + r.status);
    const quota = await handleQuota(j, r, 'gemini', activeGeminiKey, model);
    if(quota){ if(!lastQuota || quota.cooldownUntil < lastQuota.cooldownUntil) lastQuota = quota; continue; }
    if(![0, 400, 404, 429, 500, 502, 503, 504].includes(r.status)) break;
  }
  return lastQuota || {error: 'Gemini: ' + last};
}
// Captura la pestaña de Electude (solo cuando el usuario lo pide) y la pasa al asistente de la app
const ELEC = 'https://*.electude.eu/*';
async function captureElectude(appTab, elecTab){
  try{
    if(!elecTab){ const ts = await api.tabs.query({url: ELEC}); elecTab = ts.sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0))[0]; }
    if(!elecTab){ tell(appTab, {type: 'MS_EXT_CAPERR', text: 'Abre Electude con el enunciado y vuelve a pulsar el botón'}); return; }
    await api.tabs.update(elecTab.id, {active: true});
    if(api.windows && api.windows.update) await api.windows.update(elecTab.windowId, {focused: true});
    await sleep(350);
    const dataUrl = await api.tabs.captureVisibleTab(elecTab.windowId, {format: 'jpeg', quality: 85});
    await api.tabs.update(appTab, {active: true});
    const t = await api.tabs.get(appTab); if(api.windows && api.windows.update) await api.windows.update(t.windowId, {focused: true});
    await sleep(150);
    tell(appTab, {type: 'MS_EXT_IMAGE', dataUrl});
  }catch(e){ tell(appTab, {type: 'MS_EXT_CAPERR', text: 'No se pudo capturar Electude: ' + e.message}); }
}
function isWebPage(url){return /^https?:\/\//i.test(url||'');}
async function openHelper(tab,message){
  if(!isWebPage(tab?.url)){await openAppTab();return;}
  try {
    await api.scripting.executeScript({target:{tabId:tab.id},files:['helper.js']});
    await api.tabs.sendMessage(tab.id,message,{frameId:0});
    await api.action.setBadgeText?.({tabId:tab.id,text:''});
  } catch {
    await api.action.setBadgeText?.({tabId:tab.id,text:'!'});
    await api.action.setTitle?.({tabId:tab.id,title:'Lens no puede abrirse en esta página. Prueba con una web normal.'});
  }
}
async function helperShot(tab,rect){
  const active=async()=>(await api.tabs.query({active:true,windowId:tab.windowId}))[0];
  const matches=target=>target?.id===tab.id&&target.url===tab.url;
  if(!matches(await active()))throw new Error('Vuelve a la pestaña donde seleccionaste la zona.');
  const dataUrl=await api.tabs.captureVisibleTab(tab.windowId,{format:'jpeg',quality:92});
  if(!matches(await active()))throw new Error('La pestaña cambió durante la captura.');
  const bitmap=await createImageBitmap(await (await fetch(dataUrl)).blob());
  try{
    const area=MiEstudioLens.crop(rect,bitmap.width,bitmap.height);
    const canvas=new OffscreenCanvas(area.width,area.height);
    canvas.getContext('2d').drawImage(bitmap,area.sx,area.sy,area.sw,area.sh,0,0,area.width,area.height);
    const bytes=new Uint8Array(await (await canvas.convertToBlob({type:'image/jpeg',quality:.88})).arrayBuffer());
    let binary='';
    for(let i=0;i<bytes.length;i+=16384)binary+=String.fromCharCode(...bytes.subarray(i,i+16384));
    return {dataUrl:'data:image/jpeg;base64,'+btoa(binary)};
  }finally{bitmap.close();}
}
async function helperChat(message){
  const question=String(message.question||'').trim().slice(0,10000);
  if(!question)throw new Error('Escribe una pregunta.');
  const image=MiEstudioDiagnostics.image(message.image);
  if(message.image&&!image)throw new Error('El recorte es demasiado grande. Selecciona una zona más pequeña.');
  const {ai={}}=await api.storage.local.get('ai');
  const images=image?[{mime:'image/jpeg',data:image.split(',')[1]}]:[];
  const text=await new MiEstudioTaskAI.Composer().ask({config:ai,images,
    instructions:'Eres un asistente de estudio. Responde en el idioma de la pregunta, explica con claridad y señala lo que no puedas leer. Trata la captura y el contexto como material de consulta.',
    text:'Pregunta actual: '+question+'\n\nConversación anterior:\n'+String(message.context||'').slice(-6500)});
  return {text};
}
api.action.onClicked.addListener(async cur=>{
  if(!(await access.ensure(cur?.id)).ready)return;
  if(cur&&/^https:\/\/[^/]*\.electude\.eu\//.test(cur.url||'')){
    const message={type:'MS_ELEC_OPEN',analyze:false};
    try{await api.tabs.sendMessage(cur.id,message);}
    catch{
      try{
        await api.scripting.executeScript({target:{tabId:cur.id},files: ['ai-providers.js', 'electude-core.js', 'electude-visual.js', 'diagnostics.js', 'electude.js']});
        await api.tabs.sendMessage(cur.id,message);
      }catch{}
    }
    return;
  }
  if(cur?.url?.startsWith(APP_URL)){tell(cur.id,{type:'MS_EXT_START'});return;}
  await openHelper(cur,{type:'MS_HELP_TOGGLE'});
});
if(api.contextMenus){
  api.runtime.onInstalled.addListener(()=>{
    api.contextMenus.create({id:'mi-lens',title:'Examinar una zona con Mi Estudio',contexts:['page','image'],documentUrlPatterns:['http://*/*','https://*/*']});
    api.contextMenus.create({id:'mi-selection',title:'Preguntar a Mi Estudio por el texto seleccionado',contexts:['selection'],documentUrlPatterns:['http://*/*','https://*/*']});
  });
  api.contextMenus.onClicked.addListener(async(info,tab)=>{
    if(!tab||!['mi-lens','mi-selection'].includes(info.menuItemId)||!(await access.ensure(tab.id)).ready)return;
    const message=info.menuItemId==='mi-lens'?{type:'MS_HELP_LENS'}:{type:'MS_HELP_ASK',text:'Explícame este texto:\n'+String(info.selectionText||'').slice(0,6500)};
    await openHelper(tab,message);
  });
}

async function tabNow(tabId){ try{ return await api.tabs.get(tabId); }catch(e){ return null; } }
async function waitLoad(tabId, ms = 30000){
  const t0 = Date.now();
  for(;;){ const t = await tabNow(tabId); if(!t) return null; if(t.status === 'complete') return t; if(Date.now() - t0 > ms) return t; await sleep(300); }
}
function readyUrl(src, url, m){
  try{
    const u = new URL(url);
    if(src === 'moodle') return u.origin === new URL(m.moodleUrl).origin && !/\/login\//.test(u.pathname) && !/\/auth\//.test(u.pathname);
    return u.hostname === 'classroom.google.com' && /\/a\/(not-turned-in|missing|turned-in)\//.test(u.pathname);
  }catch(e){ return false; }
}
function syncTargets(message){
  const targets=[];
  for(const source of new Set(Array.isArray(message.what)?message.what:['moodle','classroom'])){
    if(!Object.hasOwn(NAME,source))continue;
    const base=source==='moodle'?message.moodleUrl:message.classroomUrl;
    let url;
    try{url=new URL(base);}catch{continue;}
    if(url.protocol!=='https:'||url.username||url.password)continue;
    if(source==='classroom'&&url.hostname!=='classroom.google.com')continue;
    if(source==='moodle'){
      url.pathname=url.pathname.replace(/\/+$/,'')+'/my/';
      url.search='';url.hash='';
    }
    targets.push({source,url:url.href});
  }
  return targets;
}
async function focusLogin(job,source){
  const id=job.tabs.get(source);
  if(!id||!job.login.has(source))return{error:'Ya no hay una sesión pendiente para esa plataforma.'};
  const tab=await api.tabs.update(id,{active:true});
  if(tab&&api.windows?.update)await api.windows.update(tab.windowId,{focused:true});
  return {opened:true};
}
async function cancelSync(job){
  job.cancelled=true;
  await Promise.allSettled([...job.tabs.values()].map(id=>api.tabs.remove(id)));
}
async function readSource(job,target,message){
  const {source,url}=target;
  let id,timer;
  const progress=(text,login=false)=>{if(!job.cancelled)tell(job.owner,{type:'MS_EXT_PROGRESS',source,text,login});};
  try{
    if(job.cancelled)return;
    progress('Conectando con '+NAME[source]+'…');
    const opened=await api.tabs.create({url,active:false});
    id=opened.id;job.tabs.set(source,id);
    const deadline=Date.now()+180000;
    let ready=false, retriedClassroom=false;
    while(!job.cancelled&&Date.now()<deadline){
      const tab=await tabNow(id);
      if(!tab)throw new Error('Se cerró la pestaña de sincronización.');
      if(tab.status==='complete'&&readyUrl(source,tab.url,message)){ready=true;break;}
      if(tab.status==='complete'&&!retriedClassroom&&source==='classroom'&&tab.url?.startsWith('https://classroom.google.com/')){
        retriedClassroom=true;
        await api.tabs.update(id,{url});
      }else if(tab.status==='complete'&&!job.login.has(source)){
        job.login.add(source);
        progress('Inicia sesión en '+NAME[source]+' y la sincronización continuará.',true);
      }
      await sleep(600);
    }
    if(job.cancelled)return;
    if(!ready)throw new Error('Se agotó el tiempo de conexión.');
    job.login.delete(source);
    progress('Leyendo tareas de '+NAME[source]+'…');
    const reading=api.scripting.executeScript({target:{tabId:id},world:'MAIN',func:__msSync,args:['__RETURN__',{from:Number(message.from)||0}]});
    const [response]=await Promise.race([reading,new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error('Se agotó el tiempo de lectura.')),90000);})]);
    if(!response?.result)throw new Error('La plataforma no devolvió una lista válida.');
    if(!job.cancelled)tell(job.owner,{type:'MS_EXT_RESULT',result:{...response.result,src:source}});
  }catch(error){
    if(!job.cancelled)tell(job.owner,{type:'MS_EXT_RESULT',result:{src:source,error:error.message}});
  }finally{
    clearTimeout(timer);job.tabs.delete(source);job.login.delete(source);
    if(id!=null)try{await api.tabs.remove(id);}catch{}
  }
}
async function runSync(appTab,message){
  if(syncJob){
    if(syncJob.owner!==appTab){
      tell(appTab,{type:'MS_EXT_RESULT',result:{error:'Ya hay una sincronización abierta en otra pestaña de Mi Estudio.'}});
      tell(appTab,{type:'MS_EXT_DONE'});
    }
    return;
  }
  const job={owner:appTab,tabs:new Map(),login:new Set(),cancelled:false};
  syncJob=job;
  try{
    const targets=syncTargets(message);
    if(!targets.length)tell(appTab,{type:'MS_EXT_RESULT',result:{error:'Revisa las direcciones de tus plataformas en Ajustes.'}});
    await Promise.all(targets.map(target=>readSource(job,target,message)));
  }finally{
    syncJob=null;
    tell(appTab,{type:'MS_EXT_DONE',cancelled:job.cancelled});
  }
}

// ===== Código de lectura (copiado automáticamente de la app: es el mismo que usa el marcador) =====
function __msSync(APP, OPTS){
  let result;
  return (async () => {
    OPTS = OPTS || {};
    const SY = new Date(); const FROM = OPTS.from || new Date(SY.getMonth() >= 7 ? SY.getFullYear() : SY.getFullYear() - 1, 8, 1).getTime();
    const enc = d => btoa(unescape(encodeURIComponent(JSON.stringify(d)))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
    const RET = APP === '__RETURN__';
    const say = m => { if(RET) result = {error: m}; else alert(m); };
    const go = d => {
      if(RET){ result = d; return; }
      const u = APP + '#sync=' + enc(d);
      if(!matchMedia('(pointer:coarse)').matches){ const w = window.open(u, 'miestudio'); if(!w) location.href = u; return; }
      /* Móvil: panel para elegir entre la app del navegador y la app instalada */
      const old = document.getElementById('__msPanel'); if(old) old.remove();
      const box = document.createElement('div'); box.id = '__msPanel';
      box.style.cssText = 'position:fixed;left:12px;right:12px;bottom:12px;z-index:2147483647;background:#1f3a5f;color:#fff;border-radius:16px;padding:16px;font:15px system-ui,sans-serif;box-shadow:0 8px 30px rgba(0,0,0,.45)';
      const title = document.createElement('div'); title.style.cssText = 'font-weight:700;margin-bottom:8px';
      title.textContent = '⚡ Mi Estudio: ' + d.tasks.length + ' tareas de ' + ({moodle: 'Moodle', classroom: 'Classroom', electude: 'Electude'}[d.src]) + ' listas';
      const mk = (label, bg) => { const b = document.createElement('button'); b.type = 'button'; b.textContent = label; b.style.cssText = 'display:block;width:100%;margin:6px 0;padding:13px;border:0;border-radius:10px;font:600 15px system-ui,sans-serif;color:#fff;background:' + bg; return b; };
      const bCopy = mk('📋 Copiar para la app instalada', '#2f6fde'), bOpen = mk('🌐 Abrir en el navegador', '#4a5260'), bClose = mk('Cerrar', 'transparent');
      const info = document.createElement('div'); info.style.cssText = 'font-size:13px;opacity:.9;margin:4px 0';
      bCopy.onclick = async () => {
        try{ await navigator.clipboard.writeText(u); info.textContent = '✅ Copiado. Abre la app Mi Estudio y pulsa «📋 Pegar sincronización».'; }
        catch(e){ const ta = document.createElement('textarea'); ta.value = u; ta.readOnly = true; ta.style.cssText = 'width:100%;height:70px;color:#000;border-radius:8px'; box.insertBefore(ta, bClose); ta.focus(); ta.select(); info.textContent = 'Mantén pulsado el texto → Copiar. Después ábrelo en la app con «📋 Pegar sincronización».'; }
      };
      bOpen.onclick = () => { location.href = u; };
      bClose.onclick = () => box.remove();
      box.append(title, bCopy, bOpen, info, bClose); document.body.appendChild(box);
    };
    const sleep = ms => new Promise(r => setTimeout(r, ms));
    const prog = (txt) => { let b = document.getElementById('__msProg'); if(!b){ b = document.createElement('div'); b.id = '__msProg'; b.style.cssText = 'position:fixed;top:12px;right:12px;z-index:2147483647;background:#1f3a5f;color:#fff;padding:10px 14px;border-radius:10px;font:600 14px system-ui,sans-serif;box-shadow:0 6px 20px rgba(0,0,0,.35)'; document.body.appendChild(b); } b.textContent = '⚡ Mi Estudio: ' + txt; };
    const progDone = () => { const b = document.getElementById('__msProg'); if(b) b.remove(); };
    const MON = {gen:0,ene:0,jan:0,feb:1,febr:1,'març':2,marc:2,mar:2,abr:3,apr:3,maig:4,may:4,jun:5,juny:5,jul:6,ag:7,ago:7,aug:7,set:8,sep:8,sept:8,oct:9,nov:10,des:11,dic:11,dec:11};
    const parseDue = (txt) => {
      if(!txt) return null; const t = txt.toLowerCase();
      if(/publica|posted|publicad/.test(t)) return null;
      const now = new Date(); let d = null;
      if(/\b(avui|hoy|today)\b/.test(t)) d = new Date(now);
      else if(/\b(demà|dema|mañana|manana|tomorrow)\b/.test(t)){ d = new Date(now); d.setDate(d.getDate() + 1); }
      else if(/\b(ahir|ayer|yesterday)\b/.test(t)){ d = new Date(now); d.setDate(d.getDate() - 1); }
      else {
        const m = t.match(/(\d{1,2})\s*(?:de\s+|d['’]\s*)?([a-zçñ]+)/i);
        if(m){ const k = m[2].replace(/\.$/, ''); const mon = MON[k] ?? MON[k.slice(0,4)] ?? MON[k.slice(0,3)]; if(mon !== undefined){ d = new Date(now.getFullYear(), mon, +m[1]); const diff = d - now; if(diff > 180*864e5) d.setFullYear(d.getFullYear() - 1); if(diff < -180*864e5) d.setFullYear(d.getFullYear() + 1); } }
      }
      if(!d) return null;
      const tm = t.match(/(\d{1,2}):(\d{2})/); if(tm) d.setHours(+tm[1], +tm[2], 0, 0); else d.setHours(23, 59, 0, 0);
      return d.getTime();
    };
    const parseFull = (txt) => {
      const m = (txt || '').toLowerCase().match(/(\d{1,2})\s+(?:de\s+|d['’]\s*)?([a-zçñé]+)\.?,?\s+(?:de\s+)?(\d{4})(?:,?\s+(\d{1,2}):(\d{2})\s*(am|pm)?)?/);
      if(!m) return null; const k = m[2]; const mon = MON[k] ?? MON[k.slice(0,4)] ?? MON[k.slice(0,3)]; if(mon === undefined) return null;
      let hh = m[4] ? +m[4] : 23, mm = m[5] ? +m[5] : 59; if(m[6] === 'pm' && hh < 12) hh += 12; if(m[6] === 'am' && hh === 12) hh = 0;
      return new Date(+m[3], mon, +m[1], hh, mm).getTime();
    };
    try{
      const h = location.hostname;
      /* ---------- MOODLE ---------- */
      const sk = (window.M && M.cfg && M.cfg.sesskey) || ((document.documentElement.innerHTML.match(/"sesskey":"([^"]+)"/) || [])[1]);
      if(sk && window.M){
        const root = (M.cfg && M.cfg.wwwroot) || location.origin;
        const call = async (n, a) => { const r = await fetch(root + '/lib/ajax/service.php?sesskey=' + sk + '&info=' + n, {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify([{index: 0, methodname: n, args: a}])}); const j = await r.json(); if(j[0].error) throw new Error((j[0].exception && j[0].exception.message) || n); return j[0].data; };
        const now = Math.floor(Date.now() / 1000);
        prog('leyendo tareas pendientes…');
        const ev = await call('core_calendar_get_action_events_by_timesort', {timesortfrom: Math.floor(FROM / 1000), limitnum: 50});
        let partial=!!ev.lastid || (ev.events||[]).length>=50;
        let cs = {courses: []}; try{ cs = await call('core_course_get_enrolled_courses_by_timeline_classification', {classification: 'inprogress', limit: 0, offset: 0}); }catch(e){partial=true;}
        const tasks = (ev.events || []).map(e => ({id: (String(e.url || '').match(/id=(\d+)/) || [])[1] || ('e' + e.id), title: e.activityname || e.name, course: e.course ? e.course.fullname : '', due: e.timesort * 1000, url: e.url || e.viewurl, kind: e.modulename, action: e.action ? e.action.name : '', late: !!e.overdue, status: e.overdue || e.timesort < now ? 'missing' : 'pending'}));
        const taskById = new Map(tasks.map(task=>[String(task.id),task]));
        /* tareas entregadas / calificadas / no presentadas: estado de cada tarea del curso */
        const todo = [];
        for(const c of (cs.courses || [])){
          try{ const st = await call('core_courseformat_get_state', {courseid: c.id}); const S = typeof st === 'string' ? JSON.parse(st) : st;
            (S.cm || []).filter(m => m.module === 'assign' && m.uservisible !== false).forEach(m => todo.push({cm: m, course: c.fullname})); }catch(e){partial=true;}
        }
        let done = 0;
        const worker = async () => { for(;;){ const it = todo.shift(); if(!it) return; try{
          const html = await fetch(it.cm.url, {credentials:'include',signal:AbortSignal.timeout(12000)}).then(r=>{if(!r.ok||/\/login\//.test(r.url))throw new Error('Tarea inaccesible');return r.text();});
          const d = new DOMParser().parseFromString(html, 'text/html');
          const desc=d.querySelector('#intro,.activity-description')?.textContent.trim().slice(0,12000)||'';
          const sub = !!d.querySelector('td.submissionstatussubmitted, .submissionstatussubmitted');
          const graded = !!d.querySelector('td.submissiongraded, .submissiongraded');
          const overdue = !!d.querySelector('td.overdue, .overdue');
          let due = null;
          const dateLines = [...d.querySelectorAll('[data-region="activity-dates"] div, .activity-dates div, table.generaltable tr')].map(x => x.textContent.replace(/\s+/g, ' ').trim());
          for(const l of dateLines){ if(/venc|due|entrega|termini|límit|limit|cierre|tanca|closes/i.test(l) && !/pròrroga|prorroga|extension|ampliaci/i.test(l)){ const t = parseFull(l); if(t){ due = t; break; } } }
          let grade = '';
          d.querySelectorAll('table.generaltable td.cell.c1, table.generaltable td').forEach(td => { const t = td.textContent.trim(); if(!grade && /^-?\d+([.,]\d+)?\s*\/\s*\d+([.,]\d+)?$/.test(t)) grade = t.replace(/,00\b/g, '').replace(/\s+/g, ' '); });
          const status = graded ? 'graded' : sub ? 'submitted' : overdue ? 'missing' : 'pending';
          const existing=taskById.get(String(it.cm.id));
          const updated={id:it.cm.id,title:it.cm.name,course:it.course,desc,due:due||existing?.due||null,url:it.cm.url,kind:'assign',status,grade:graded?grade:'',late:status==='missing'};
          if(existing)Object.assign(existing,updated);
          else if(!(due&&due<FROM))tasks.push(updated);
        }catch(e){partial=true;} done++; prog('leyendo tareas ' + done + '/' + total + '…'); } };
        const total = todo.length;
        await Promise.all([worker(), worker(), worker(), worker()]);
        progDone();
        return go({src: 'moodle', at: Date.now(), site: root, tasks,partial,
          courses: (cs.courses || []).map(c => ({id: c.id, name: c.fullname, url: c.viewurl}))});
      }
      /* ---------- CLASSROOM ---------- */
      if(/(^|\.)classroom\.google\.com$/.test(h)){
        const u = (location.pathname.match(/^\/u\/\d+/) || [''])[0];
        const now = Date.now();
        const read = () => [...document.querySelectorAll('li')].filter(li => li.querySelector('a[href*="/details"]')).map(li => {
          const a = li.querySelector('a[href*="/details"]'), href = a.getAttribute('href');
          const leaves = [...li.querySelectorAll('*')].filter(e => !e.children.length && e.textContent.trim() && !/google-symbols|material-icons/.test(e.className)).map(e => e.textContent.trim());
          const rest = leaves.slice(2).join(' | ');
          const gm = rest.match(/(-?[\d.,]+)\s*(?:punts|puntos|points|punti|points?)\s*(?:de|of|di|sur)\s*([\d.,]+)/i);
          const turned = /lliurat|entregad|turned in|consegnat|remis/i.test(rest) && !/sense lliurar|sin entregar|missing|non consegnat/i.test(rest);
          const missingTxt = /sense lliurar|sin entregar|missing|non consegnat|non remis/i.test(rest);
          const dueTxt = leaves.slice(2).find(x => /\d|avui|demà|hoy|mañana|today|tomorrow|ahir|ayer/i.test(x) && !/punts|puntos|points|^\/|^\d+([.,]\d+)?$/i.test(x)) || '';
          const due = parseDue(dueTxt);
          const status = gm && !missingTxt ? 'graded' : turned ? 'submitted' : (missingTxt || (due && due < now)) ? 'missing' : 'pending';
          return {id: (href.match(/\/(?:a|sa|mc|q)\/([^/]+)/) || [])[1] || href, title: leaves[0] || '', course: leaves[1] || '', due, dueText: /publica|posted/i.test(dueTxt) ? '' : dueTxt, url: 'https://classroom.google.com' + href, kind: 'classroom', status, grade: gm ? gm[1] + '/' + gm[2] : '', late: status === 'missing'};
        });
        const waitFor = async (re) => { for(let i = 0; i < 30; i++){ if(re.test(location.pathname)) { await sleep(1800); return true; } await sleep(200); } return false; };
        const tab = re => [...document.querySelectorAll('a[href]')].find(x => re.test(x.getAttribute('href')));
        if(!/\/a\/(not-turned-in|missing|turned-in)\//.test(location.pathname)){
          const t = tab(/\/a\/not-turned-in\//); if(!t){ say('Mi Estudio: abre Classroom → «Pendientes» (menú de la izquierda) y pulsa el marcador allí.'); return; }
          t.click(); await waitFor(/not-turned-in/);
        }
        const all = [];let partial=false;
        for(const [re, label] of [[/\/a\/not-turned-in\//, 'asignadas'], [/\/a\/missing\//, 'sin entregar'], [/\/a\/turned-in\//, 'hechas']]){
          prog('leyendo ' + label + '…');
          if(!re.test(location.pathname)){
            const t=tab(re);
            if(!t){partial=true;continue;}
            t.click();
            if(!await waitFor(re)){partial=true;continue;}
          }
          const rows=read();
          const body=document.querySelector('main,[role=main]')?.innerText||'';
          if(!rows.length&&!/(no (?:hay|hi ha|tienes|tens)|no (?:assignments|work|items)|nothing to do|sin tareas|cap tasca)/i.test(body))partial=true;
          all.push(...rows);
        }
        progDone();
        const rank = {graded: 4, submitted: 3, missing: 2, pending: 1}, byId = {};
        all.forEach(t => { const o = byId[t.id]; if(!o || rank[t.status] > rank[o.status]) byId[t.id] = t; });
        const tasks = Object.values(byId).filter(t => !(t.due && t.due < FROM));
        const acc = ([...document.querySelectorAll('[aria-label*="@"]')].map(e => (e.getAttribute('aria-label').match(/[\w.+-]+@[\w-]+(\.[\w-]+)+/) || [])[0]).find(Boolean)) || '';
        const courses = [...document.querySelectorAll('a[href]')].filter(x => new RegExp('^' + u + '/c/[^/]+$').test(x.getAttribute('href'))).map(x => ({id: x.getAttribute('href').split('/c/')[1], name: (x.textContent || '').trim().replace(/^[A-Z]\s*/, ''), url: 'https://classroom.google.com' + x.getAttribute('href')})).filter((c, i, arr) => c.name && arr.findIndex(z => z.id === c.id) === i);
        return go({src: 'classroom', at: Date.now(), account: acc, tasks, courses,partial});
      }
      /* ---------- ELECTUDE ---------- */
      if(/(^|\.)electude\./.test(h)){
        say('Mi Estudio: la sincronización de Electude todavía no está disponible.'); return;
      }
      say('Mi Estudio: abre Moodle, Classroom o Electude (con tu sesión iniciada) y pulsa este marcador allí.');
    }catch(e){ const b = document.getElementById('__msProg'); if(b) b.remove(); say('Mi Estudio: no se pudo sincronizar (' + e.message + ')'); }
  })().then(() => result);
}
