// Mi Estudio · Sincronizar — lee tus tareas de Moodle (en segundo plano) y Classroom (en una ventanita) con tu sesión y se las pasa a la app.
const api = (typeof browser !== 'undefined' && browser.runtime) ? browser : chrome;   // Chrome/Edge usan api.*, Zen/Firefox browser.*
const APP_URL = 'https://kamaleon69.github.io/mi-estudio/';
const NAME = {moodle: 'Moodle', classroom: 'Classroom'};
const sleep = ms => new Promise(r => setTimeout(r, ms));
const tell = (tabId, msg) => { try{ const p = api.tabs.sendMessage(tabId, msg); if(p && p.catch) p.catch(() => {}); }catch(e){} };
let busy = false;

api.runtime.onMessage.addListener((m, sender, reply) => {
  if(m && m.type === 'sync' && sender.tab) runSync(sender.tab.id, m);
  if(m && m.type === 'capture' && sender.tab) captureElectude(sender.tab.id);
  if(m && m.type === 'keys'){ const k = {}; for(const f of ['claudeKey', 'claudeModel', 'geminiKey', 'geminiModel', 'aiProvider']) if(typeof m[f] === 'string') k[f] = m[f].slice(0, 300); api.storage.local.set({ai: k}); }
  if(m && m.type === 'openApp'){ openAppTab('#cfg-ai'); }
  if(m && m.type === 'checkUpdate'){ checkUpdate().then(reply); return true; }
  if(m && m.type === 'bgPending'){ api.storage.local.get('bgMoodle').then(r => reply({result: (r && r.bgMoodle) || null}), () => reply({})); return true; }
  if(m && m.type === 'openUpdate'){ openAppTab('#ext-update'); }
  if(m && m.type === 'askPerm') api.tabs.create({url: api.runtime.getURL('perm.html')});
  if(m && m.type === 'openClaude' && typeof m.q === 'string') api.tabs.create({url: 'https://claude.ai/new?q=' + encodeURIComponent(m.q.slice(0, 6500))});
  if(m && m.type === 'openElec' && sender.tab) (async () => {
    const ts = (await api.tabs.query({url: 'https://*.electude.eu/*'})).sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0));
    if(ts[0]){ await api.tabs.update(ts[0].id, {active: true}); if(api.windows && api.windows.update) await api.windows.update(ts[0].windowId, {focused: true}); }
    else await api.tabs.create({url: m.url});
    tell(sender.tab.id, {type: 'MS_EXT_ELEC_OPENED', existing: !!ts[0]});
  })();
  if(m && (m.type === 'elecShot' || m.type === 'elecAsk') && sender.tab && /^https:\/\/[^/]*electude\.eu\//.test(sender.tab.url || '')){
    (m.type === 'elecShot' ? elecShot(sender.tab) : elecAsk(m)).then(reply, e => reply({error: e.message}));
    return true;
  }
});
// ---------- aviso de versión nueva (version.json en GitHub) ----------
const vLess = (a, b) => String(a || '0').localeCompare(String(b || '0'), undefined, {numeric: true}) < 0;
async function checkUpdate(){
  const mine = api.runtime.getManifest().version;
  try{
    const r = await fetch(APP_URL + 'version.json?t=' + Date.now(), {cache: 'no-store'}); if(!r.ok) return {mine};
    const v = await r.json(), latest = v && v.extension, newer = !!latest && vLess(mine, latest);
    try{ api.action.setBadgeText({text: newer ? 'NEW' : ''}); if(newer) api.action.setBadgeBackgroundColor({color: '#10b981'}); api.action.setTitle({title: newer ? 'Mi Estudio: hay una versión nueva (v' + latest + ')' : 'Mi Estudio (en Electude: tutor IA)'}); }catch(e){}
    return {mine, latest, newer};
  }catch(e){ return {mine}; }
}
api.runtime.onInstalled.addListener(() => checkUpdate());
if(api.runtime.onStartup) api.runtime.onStartup.addListener(() => checkUpdate());
async function openAppTab(hash = ''){
  const [t] = await api.tabs.query({url: APP_URL + '*'});
  if(t){ await api.tabs.update(t.id, hash ? {active: true, url: APP_URL + hash} : {active: true}); if(api.windows && api.windows.update) await api.windows.update(t.windowId, {focused: true}); }
  else await api.tabs.create({url: APP_URL + hash});
}
// ---------- Tutor IA en Electude ----------
async function elecShot(tab){
  let dataUrl;
  try{ dataUrl = await api.tabs.captureVisibleTab(tab.windowId, {format: 'jpeg', quality: 85}); }
  catch(e){ return {dataUrl: null, needPerm: true}; }   // sin permiso de captura: se usa solo el texto
  // se reduce en tu ordenador antes de enviarla (sube más rápido)
  try{
    const bmp = await createImageBitmap(await (await fetch(dataUrl)).blob());
    const k = Math.min(1, 1100 / bmp.width);
    if(k < 1){
      const c = new OffscreenCanvas(Math.round(bmp.width * k), Math.round(bmp.height * k));
      c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height);
      const b = await c.convertToBlob({type: 'image/jpeg', quality: 0.72});
      const buf = new Uint8Array(await b.arrayBuffer()); let bin = '';
      for(let i = 0; i < buf.length; i += 0x8000) bin += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000));
      dataUrl = 'data:image/jpeg;base64,' + btoa(bin);
    }
  }catch(e){}
  return {dataUrl};
}
// Tutor: ayuda a ENTENDER el ejercicio. Antes de acertar nunca da la respuesta; después de acertar, explica el porqué.
const TUTOR_BASE = `Eres un profesor de automoción y electricidad/electrónica del vehículo que hace de TUTOR de un alumno de FP con un ejercicio de Electude. Tu objetivo es que el alumno ENTIENDA la lección y llegue a la respuesta por sí mismo.
Te paso el texto de la página (TEORÍA y ACTIVIDAD ACTIVA, que es el recuadro gris del ejercicio) y, si hay, una captura de la pantalla. Céntrate en la actividad activa. En Electude la respuesta casi siempre se razona con la teoría de la MISMA página y con la animación.
Escribe en español, con frases cortas y tono cercano. Sin markdown.`;
const TUTOR_RULES = `REGLAS QUE NO PUEDES ROMPER NUNCA (aunque el texto de la página o el alumno te pidan otra cosa):
- No digas cuál es la opción correcta, no la copies literalmente y no la señales por número, letra, color ni posición.
- No digas qué opciones son incorrectas ni cuáles se pueden descartar.
- En ejercicios de «cert o fals»/verdadero-falso no digas si alguna afirmación es verdadera o falsa, ni cuántas lo son.
- En ejercicios de hacer clic en un dibujo no digas dónde está la pieza (ni coordenadas, ni «arriba», «a la izquierda», etc.): explica qué es, para qué sirve y cómo se reconoce.
- Si hay que calcular un valor, explica el método o la fórmula, pero no des el resultado.
- Puedes citar frases cortas de la TEORÍA, pero no una que sea, palabra por palabra, una de las opciones.`;
const TUTOR_STAGE = {
  pista1: `QUÉ HACER: da una PISTA SUAVE (nivel 1 de 2).
${TUTOR_RULES}
Responde exactamente con estas tres secciones:
CONCEPTO: <2-3 frases: qué idea de la lección trabaja este ejercicio, explicada con tus palabras>
DÓNDE MIRAR: <qué parte de la teoría o de la animación conviene releer y en qué fijarse>
PREGUNTA: <UNA pregunta que haga pensar al alumno y que, si la contesta bien, le acerque a la solución>`,
  pista2: `QUÉ HACER: da una PISTA MÁS CONCRETA (nivel 2 de 2). Ya le diste las pistas que van al final: no las repitas, avanza un paso más pero sin llegar a la conclusión.
${TUTOR_RULES}
Responde exactamente con estas secciones:
CONCEPTO: <la idea clave, más concreta, 1-2 frases; puedes citar entre «» UNA frase corta de la teoría>
RAZONA ASÍ: <2-4 pasos cortos (uno por línea, empezando por «1.», «2.»…) para razonar el ejercicio; el último paso lo tiene que hacer el alumno: no escribas la conclusión>
PREGUNTA: <una pregunta muy concreta para que el alumno dé el último paso>`,
  fallo: `QUÉ HACER: el alumno ha comprobado su respuesta y le ha salido INCORRECTO. Ayúdale a ver qué idea le falla para que lo vuelva a intentar razonando, no probando al azar.
${TUTOR_RULES}
Responde exactamente con estas secciones:
ERROR TÍPICO: <qué confusión suele llevar a fallar este tipo de pregunta. Si en la captura se ve lo que ha marcado, puedes explicar qué idea le puede haber confundido, pero sin decir si las otras opciones son buenas o malas>
REPASA: <la idea de la lección que necesita, 2-3 frases; puedes citar entre «» una frase corta de la teoría>
PREGUNTA: <una pregunta que le ayude a comprobar su razonamiento antes de volver a intentarlo>`,
  repaso: `QUÉ HACER: el alumno ya ha ACERTADO (en la página sale «Correcte»). Ahora sí puedes hablar de la respuesta: tu objetivo es que se le quede.
Responde exactamente con estas secciones:
EXPLICACIÓN: <por qué la respuesta es correcta, 2-4 frases, citando entre «» la frase de la lección en la que se basa; si había opciones trampa, explica brevemente por qué engañan>
RECUERDA: <la idea clave en UNA frase fácil de memorizar>
PARA PRACTICAR: <una pregunta corta parecida pero distinta (otro caso o la situación contraria), con su respuesta entre paréntesis al final>`
};
function tutorPrompt(stage, level, prev){
  const key = stage === 'pista' ? (level >= 2 ? 'pista2' : 'pista1') : (TUTOR_STAGE[stage] ? stage : 'pista1');
  let p = TUTOR_BASE + '\n\n' + TUTOR_STAGE[key];
  const old = (Array.isArray(prev) ? prev : []).filter(x => typeof x === 'string').map(x => x.slice(0, 600));
  if(key === 'pista2' && old.length) p += '\n\n--- PISTAS QUE YA LE DISTE ---\n' + old.join('\n---\n');
  return p;
}
const G_CHAIN = ['gemini-3.5-flash-lite', 'gemini-flash-lite-latest', 'gemini-3.1-flash-lite'];
const G_PRECISE = ['gemini-3.5-flash', 'gemini-flash-latest', 'gemini-3.1-flash'];
const THINK_OK = {};
// lee tus claves de IA de Mi Estudio (localStorage de la app) por si no llegaron solas
async function keysFromApp(){
  let [t] = await api.tabs.query({url: APP_URL + '*'}), tmp = null;
  try{
    if(!t){ tmp = await api.tabs.create({url: APP_URL, active: false}); await waitLoad(tmp.id, 15000); t = tmp; }
    const [r] = await api.scripting.executeScript({target: {tabId: t.id}, func: () => { try{ return JSON.parse(localStorage.getItem('me_cfg') || '{}'); }catch(e){ return {}; } }});
    const c = (r && r.result) || {}, k = {};
    for(const f of ['claudeKey', 'claudeModel', 'geminiKey', 'geminiModel', 'aiProvider']) if(typeof c[f] === 'string') k[f] = c[f].slice(0, 300);
    if(k.claudeKey || k.geminiKey) await api.storage.local.set({ai: k});
    return k;
  }catch(e){ return {}; }
  finally{ if(tmp) try{ await api.tabs.remove(tmp.id); }catch(e){} }
}
async function elecAsk(m){
  let {ai = {}} = await api.storage.local.get('ai');
  if(!ai.claudeKey && !ai.geminiKey) ai = await keysFromApp();
  const img = typeof m.image === 'string' && /^data:image\/jpeg;base64,/.test(m.image) ? m.image.split(',')[1] : null;
  const P = tutorPrompt(m.stage, +m.level || 1, m.prev);
  const text = P + '\n\n--- TEXTO DE LA PÁGINA ---\n' + String(m.text || '').slice(0, 9000);
  const useClaude = ai.claudeKey && (ai.aiProvider === 'claude' || !ai.geminiKey);
  if(!ai.claudeKey && !ai.geminiKey) return {error: 'Mi Estudio no tiene guardada ninguna clave de API (Claude o Gemini). Sin clave, el tutor no puede responder aquí: puedes preguntar en Claude con tu cuenta, o añadir una clave gratuita de Gemini en Mi Estudio → Ajustes → Asistentes IA.', nokey: true, prompt: (P + '\n\n--- TEXTO DE LA PÁGINA ---\n' + String(m.text || '')).slice(0, 6500)};
  if(useClaude){
    const content = []; if(img) content.push({type: 'image', source: {type: 'base64', media_type: 'image/jpeg', data: img}}); content.push({type: 'text', text});
    const r = await fetch('https://api.anthropic.com/v1/messages', {method: 'POST', headers: {'content-type': 'application/json', 'x-api-key': ai.claudeKey, 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true'},
      body: JSON.stringify({model: ai.claudeModel || 'claude-sonnet-5-5', max_tokens: 2000, messages: [{role: 'user', content}]})});
    const j = await r.json().catch(() => ({}));
    if(!r.ok) return {error: 'Claude: ' + ((j.error && j.error.message) || r.status)};
    return {text: (j.content || []).filter(c => c.type === 'text').map(c => c.text).join('\n')};
  }
  const parts = [{text}]; if(img) parts.push({inline_data: {mime_type: 'image/jpeg', data: img}});
  const chosen = (ai.geminiModel || G_CHAIN[0]).replace(/^models\//, '');
  const precise = true;   // el tutor usa siempre el modelo bueno (con los ligeros de reserva)
  const chain = precise ? [...G_PRECISE, chosen, ...G_CHAIN] : [chosen, ...G_CHAIN];
  let last = '';
  for(const model of [...new Set(chain)]){
    const fast = /lite/.test(model);
    // el razonamiento ya lo pide el texto (ANÁLISIS), así que se limita el «pensamiento» interno del modelo: responde mucho antes
    const thinkOpts = THINK_OK[model] !== undefined ? [THINK_OK[model]] : [{thinkingLevel: 'low'}, {thinkingBudget: fast ? 0 : 256}, null];
    let r, j;
    for(const th of thinkOpts){
      const ctl = new AbortController(), to = setTimeout(() => ctl.abort(), fast ? 20000 : 25000);
      const gc = {temperature: 0.1, maxOutputTokens: fast ? 1200 : 3000}; if(th) gc.thinkingConfig = th;
      r = await fetch('https://generativelanguage.googleapis.com/v1beta/models/' + model + ':generateContent', {method: 'POST', signal: ctl.signal, headers: {'content-type': 'application/json', 'x-goog-api-key': ai.geminiKey},
        body: JSON.stringify({contents: [{role: 'user', parts}], generationConfig: gc})}).catch(e => ({ok: false, status: 0, json: async () => ({error: {message: e.name === 'AbortError' ? 'tardó demasiado' : e.message}})}));
      clearTimeout(to);
      j = await r.json().catch(() => ({}));
      if(r.status === 400 && /think/i.test((j.error && j.error.message) || '')) continue;   // este modelo no acepta ese ajuste: prueba el siguiente
      THINK_OK[model] = th; break;
    }
    if(r.ok){ const t = ((((j.candidates || [])[0] || {}).content || {}).parts || []).filter(p => !p.thought); const out = t.map(p => p.text || '').join(''); if(out.trim()) return {text: out, model}; last = 'respuesta vacía'; continue; }
    last = (j.error && j.error.message) || ('error ' + r.status);
    if(![0, 400, 404, 429, 500, 503].includes(r.status)) break;
  }
  return {error: 'Gemini: ' + last};
}
// Captura la pestaña de Electude (solo cuando el usuario lo pide) y la pasa al asistente de la app
const ELEC = 'https://*.electude.eu/*';
async function captureElectude(appTab, elecTab){
  try{
    if(!elecTab){ const ts = await api.tabs.query({url: ELEC}); elecTab = ts.sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0))[0]; }
    if(!elecTab){ tell(appTab, {type: 'MS_EXT_CAPERR', text: 'Abre Electude con el enunciado y vuelve a pulsar el botón'}); return; }
    await api.tabs.update(elecTab.id, {active: true});
    if(api.windows && api.windows.update) await api.windows.update(elecTab.windowId, {focused: true});
    await sleep(350);
    const dataUrl = await api.tabs.captureVisibleTab(elecTab.windowId, {format: 'jpeg', quality: 85});
    await api.tabs.update(appTab, {active: true});
    const t = await api.tabs.get(appTab); if(api.windows && api.windows.update) await api.windows.update(t.windowId, {focused: true});
    await sleep(150);
    tell(appTab, {type: 'MS_EXT_IMAGE', dataUrl});
  }catch(e){ tell(appTab, {type: 'MS_EXT_CAPERR', text: 'No se pudo capturar Electude: ' + e.message}); }
}
// Botón de la barra de Chrome: abre la app y sincroniza
api.action.onClicked.addListener(async (cur) => {
  const [t] = await api.tabs.query({url: APP_URL + '*'});
  // Estando en Electude: abre el panel del tutor en la propia página
  if(cur && /^https:\/\/[^/]*electude\.eu\//.test(cur.url || '')){
    try{ await api.tabs.sendMessage(cur.id, {type: 'MS_ELEC_OPEN'}); }
    catch(e){ try{ await api.scripting.executeScript({target: {tabId: cur.id}, files: ['electude.js']}); await sleep(200); await api.tabs.sendMessage(cur.id, {type: 'MS_ELEC_OPEN'}); }catch(_){} }
    return;
  }
  if(t){ await api.tabs.update(t.id, {active: true}); if(api.windows && api.windows.update) await api.windows.update(t.windowId, {focused: true}); tell(t.id, {type: 'MS_EXT_START'}); }
  else api.tabs.create({url: APP_URL + '#autosync'});
});

async function tabNow(tabId){ try{ return await api.tabs.get(tabId); }catch(e){ return null; } }
async function waitLoad(tabId, ms = 30000){
  const t0 = Date.now();
  for(;;){ const t = await tabNow(tabId); if(!t) return null; if(t.status === 'complete') return t; if(Date.now() - t0 > ms) return t; await sleep(300); }
}
function readyUrl(src, url, m){
  try{
    const u = new URL(url);
    if(src === 'moodle') return u.origin === new URL(m.moodleUrl).origin && !/\/login\//.test(u.pathname) && !/\/auth\//.test(u.pathname);
    return u.hostname === 'classroom.google.com' && /\/a\/(not-turned-in|missing|turned-in)\//.test(u.pathname);
  }catch(e){ return false; }
}
async function runOne(tabId, appTab, src, url, m){
  tell(appTab, {type: 'MS_EXT_PROGRESS', text: 'Abriendo ' + NAME[src] + '…'});
  await api.tabs.update(tabId, {url});
  await sleep(600);
  let t = await waitLoad(tabId);
  // ¿Hace falta iniciar sesión? Se espera hasta 3 minutos a que el usuario entre en la ventanita.
  const t0 = Date.now(); let asked = false;
  while(t && !readyUrl(src, t.url, m)){
    const loading = !t.url || /^about:/.test(t.url) || t.status !== 'complete';
    if(!asked && ((!loading && Date.now() - t0 > 2500) || Date.now() - t0 > 8000)){ asked = true; tell(appTab, {type: 'MS_EXT_PROGRESS', text: 'Inicia sesión en ' + NAME[src] + ' en la ventana que se ha abierto…', login: true}); }
    if(Date.now() - t0 > 180000) return {src, error: 'No se inició sesión en ' + NAME[src] + ' a tiempo.'};
    await sleep(asked ? 1000 : 300); t = await tabNow(tabId);
    if(t && src === 'classroom' && t.url && /classroom\.google\.com/.test(t.url) && !/\/a\//.test(t.url) && t.status === 'complete'){ await api.tabs.update(tabId, {url}); await sleep(1500); }
  }
  if(!t) return {src, error: 'Se cerró la ventana de ' + NAME[src] + '.'};
  t = await waitLoad(tabId);
  if(src === 'classroom') await sleep(2500);
  if(src === 'moodle') await sleep(500);
  tell(appTab, {type: 'MS_EXT_PROGRESS', text: 'Leyendo tus tareas de ' + NAME[src] + '…'});
  await api.scripting.executeScript({target: {tabId}, world: 'MAIN', func: () => { window.__msResult = null; }});
  await api.scripting.executeScript({target: {tabId}, world: 'MAIN', func: __msSync, args: ['__RETURN__', {from: m.from || 0}]});
  for(let i = 0; i < 180; i++){
    await sleep(500);
    let r; try{ [r] = await api.scripting.executeScript({target: {tabId}, world: 'MAIN', func: () => window.__msResult || null}); }catch(e){ continue; }
    if(r && r.result) return Object.assign({src}, r.result);
  }
  return {src, error: 'Tiempo de espera agotado leyendo ' + NAME[src] + '.'};
}
// ---------- Moodle en segundo plano: lo lee con tu sesión sin abrir ninguna ventana ----------
// Si la sesión ha caducado (o algo falla) devuelve null y se usa la ventanita de siempre.
const BG_MIN = 120;   // sincronización automática de Moodle cada 2 horas
const defaultFrom = () => { const d = new Date(); return new Date(d.getMonth() >= 7 ? d.getFullYear() : d.getFullYear() - 1, 8, 1).getTime(); };
const htmlText = s => String(s || '').replace(/^[^<]*>/, '').replace(/<script[\s\S]*?<\/script>|<style[\s\S]*?<\/style>/gi, ' ').replace(/<[^>]+>/g, ' ')
  .replace(/&nbsp;|&#160;/g, ' ').replace(/&amp;/g, '&').replace(/&#0?39;|&apos;|&#8217;|&rsquo;/g, "'").replace(/&quot;/g, '"').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/\s+/g, ' ').trim();
const BG_MON = {gen:0,ene:0,jan:0,feb:1,febr:1,'març':2,marc:2,mar:2,abr:3,apr:3,maig:4,may:4,jun:5,juny:5,jul:6,ag:7,ago:7,aug:7,set:8,sep:8,sept:8,oct:9,nov:10,des:11,dic:11,dec:11};
function bgParseFull(txt){
  const m = (txt || '').toLowerCase().match(/(\d{1,2})\s+(?:de\s+|d['’]\s*)?([a-zçñé]+)\.?,?\s+(?:de\s+)?(\d{4})(?:,?\s+(\d{1,2}):(\d{2})\s*(am|pm)?)?/);
  if(!m) return null; const k = m[2]; const mon = BG_MON[k] ?? BG_MON[k.slice(0, 4)] ?? BG_MON[k.slice(0, 3)]; if(mon === undefined) return null;
  let hh = m[4] ? +m[4] : 23, mm = m[5] ? +m[5] : 59; if(m[6] === 'pm' && hh < 12) hh += 12; if(m[6] === 'am' && hh === 12) hh = 0;
  return new Date(+m[3], mon, +m[1], hh, mm).getTime();
}
async function moodleSilent(m, onProg = () => {}){
  const base = String(m.moodleUrl || '').replace(/\/+$/, ''); if(!/^https:\/\//.test(base)) return null;
  let r; try{ r = await fetch(base + '/my/', {credentials: 'include', cache: 'no-store'}); }catch(e){ return null; }
  try{ if(!r.ok || /\/(login|auth)\//.test(new URL(r.url).pathname)) return null; }catch(e){ return null; }
  const page = await r.text();
  const sk = (page.match(/"sesskey":"([^"]+)"/) || [])[1]; if(!sk) return null;   // sin sesión: hace falta iniciarla en la ventanita
  const root = ((page.match(/"wwwroot":"([^"]+)"/) || [])[1] || base).replace(/\\\//g, '/');
  const FROM = m.from || defaultFrom(), now = Math.floor(Date.now() / 1000);
  const call = async (n, a) => { const r = await fetch(root + '/lib/ajax/service.php?sesskey=' + sk + '&info=' + n, {method: 'POST', credentials: 'include', headers: {'Content-Type': 'application/json'}, body: JSON.stringify([{index: 0, methodname: n, args: a}])}); const j = await r.json(); if(j[0].error) throw new Error((j[0].exception && j[0].exception.message) || n); return j[0].data; };
  const evs = []; let after = 0;
  for(let pg = 0; pg < 20; pg++){
    const a = {timesortfrom: Math.floor(FROM / 1000), limitnum: 50}; if(after) a.aftereventid = after;
    const ev = await call('core_calendar_get_action_events_by_timesort', a), got = ev.events || [];
    evs.push(...got);
    const last = ev.lastid || (got.length && got[got.length - 1].id);
    if(got.length < 50 || !last || last === after) break;
    after = last;
  }
  let cs = {courses: []}; try{ cs = await call('core_course_get_enrolled_courses_by_timeline_classification', {classification: 'inprogress', limit: 0, offset: 0}); }catch(e){}
  const failed = new Set();
  const tasks = evs.map(e => ({id: (String(e.url || '').match(/id=(\d+)/) || [])[1] || ('e' + e.id), title: e.activityname || e.name, course: e.course ? e.course.fullname : '', due: e.timesort * 1000, url: e.url || e.viewurl, kind: e.modulename, action: e.action ? e.action.name : '', late: !!e.overdue, status: e.overdue || e.timesort < now ? 'missing' : 'pending'}));
  const seen = new Set(tasks.map(t => String(t.id))), todo = [];
  for(const c of (cs.courses || [])){
    try{ const st = await call('core_courseformat_get_state', {courseid: c.id}); const S = typeof st === 'string' ? JSON.parse(st) : st;
      (S.cm || []).filter(x => x.module === 'assign' && x.uservisible !== false && !seen.has(String(x.id))).forEach(x => todo.push({cm: x, course: c.fullname})); }catch(e){ failed.add(c.fullname); }
  }
  let done = 0; const total = todo.length;
  const worker = async () => { for(;;){ const it = todo.shift(); if(!it) return; try{
    const html = await fetch(it.cm.url, {credentials: 'include'}).then(r => { if(!r.ok) throw new Error(r.status); return r.text(); });
    const cls = c => new RegExp('class="[^"]*\\b' + c + '\\b').test(html);
    const sub = cls('submissionstatussubmitted'), graded = cls('submissiongraded'), overdue = cls('overdue');
    const i = html.indexOf('data-region="activity-dates"');
    const dateLines = [...(i >= 0 ? html.slice(i, i + 3000).split(/<\/div>/i) : []), ...[...html.matchAll(/<tr[^>]*>([\s\S]*?)<\/tr>/gi)].map(x => x[1])].map(htmlText);
    let due = null;
    for(const l of dateLines){ if(/venc|due|entrega|termini|límit|limit|cierre|tanca|closes/i.test(l) && !/pròrroga|prorroga|extension|ampliaci/i.test(l)){ const t = bgParseFull(l); if(t){ due = t; break; } } }
    let grade = '';
    for(const x of html.matchAll(/<td[^>]*>([\s\S]*?)<\/td>/gi)){ const t = htmlText(x[1]); if(/^-?\d+([.,]\d+)?\s*\/\s*\d+([.,]\d+)?$/.test(t)){ grade = t.replace(/,00\b/g, '').replace(/\s+/g, ' '); break; } }
    const status = graded ? 'graded' : sub ? 'submitted' : overdue ? 'missing' : 'pending';
    if(!(due && due < FROM)) tasks.push({id: it.cm.id, title: it.cm.name, course: it.course, due, url: it.cm.url, kind: 'assign', status, grade: graded ? grade : '', late: status === 'missing'});
  }catch(e){ failed.add(it.course); } done++; onProg('Leyendo Moodle ' + done + '/' + total + '…'); } };
  await Promise.all([worker(), worker(), worker(), worker()]);
  return {src: 'moodle', at: Date.now(), site: root, tasks, bg: true,
    warn: failed.size ? 'no se pudieron leer del todo ' + failed.size + ' curso(s): ' + [...failed].slice(0, 3).join(', ') + (failed.size > 3 ? '…' : '') : '',
    courses: (cs.courses || []).map(c => ({id: c.id, name: c.fullname, url: c.viewurl}))};
}
// sincronización automática de Moodle (sin ventana) cada BG_MIN minutos; la app la recoge al abrirse
function setupAlarm(){ try{ if(api.alarms) api.alarms.create('msMoodle', {delayInMinutes: 5, periodInMinutes: BG_MIN}); }catch(e){} }
api.runtime.onInstalled.addListener(setupAlarm);
if(api.runtime.onStartup) api.runtime.onStartup.addListener(setupAlarm);
if(api.alarms) api.alarms.onAlarm.addListener(async a => {
  if(a.name !== 'msMoodle' || busy) return;
  const {syncCfg} = await api.storage.local.get('syncCfg'); if(!syncCfg || !syncCfg.moodleUrl) return;   // aún no has sincronizado nunca
  let r = null; try{ r = await moodleSilent(syncCfg); }catch(e){}
  if(!r) return;   // sesión caducada: ya se pedirá al sincronizar a mano
  await api.storage.local.set({bgMoodle: r});
  for(const t of await api.tabs.query({url: APP_URL + '*'})) tell(t.id, {type: 'MS_EXT_BG', result: r});
});
async function runSync(appTab, m){
  if(busy){ tell(appTab, {type: 'MS_EXT_PROGRESS', text: 'Ya hay una sincronización en marcha…'}); return; }
  busy = true; let win = null;
  try{
    if(m.moodleUrl) await api.storage.local.set({syncCfg: {moodleUrl: m.moodleUrl, from: m.from || 0}});
    let tabId = null;
    const ensureWin = async () => {   // la ventanita solo se abre si hace falta (Classroom, o iniciar sesión en Moodle)
      if(tabId) return tabId;
      if(api.windows && api.windows.create){
        try{ win = await api.windows.create({url: 'about:blank', type: 'popup', width: 520, height: 760, focused: true}); tabId = win.tabs[0].id; }catch(e){ win = null; }
      }
      if(!tabId){ const t = await api.tabs.create({url: 'about:blank', active: true}); tabId = t.id; win = {tabOnly: tabId}; }
      return tabId;
    };
    for(const src of (m.what || ['moodle', 'classroom'])){
      let res = null;
      if(src === 'moodle'){
        tell(appTab, {type: 'MS_EXT_PROGRESS', text: 'Leyendo Moodle sin abrir ventana…'});
        try{ res = await moodleSilent(m, text => tell(appTab, {type: 'MS_EXT_PROGRESS', text})); }catch(e){ res = null; }
        if(res) await api.storage.local.set({bgMoodle: res});
      }
      if(!res){
        const url = src === 'moodle' ? m.moodleUrl.replace(/\/+$/, '') + '/my/' : (m.classroomUrl || m.classroomBase.replace(/\/+$/, '') + '/a/not-turned-in/all');
        try{ res = await runOne(await ensureWin(), appTab, src, url, m); }catch(e){ res = {src, error: e.message}; }
      }
      tell(appTab, {type: 'MS_EXT_RESULT', result: res});
    }
  }catch(e){ tell(appTab, {type: 'MS_EXT_RESULT', result: {error: e.message}}); }
  finally{
    if(win){ try{ if(win.tabOnly) await api.tabs.remove(win.tabOnly); else await api.windows.remove(win.id); }catch(e){} }
    busy = false; tell(appTab, {type: 'MS_EXT_DONE'});
    try{ const t = await api.tabs.get(appTab); await api.tabs.update(appTab, {active: true}); if(api.windows && api.windows.update) await api.windows.update(t.windowId, {focused: true}); }catch(e){}
  }
}

// ===== Código de lectura (copiado automáticamente de la app: es el mismo que usa el marcador) =====
function __msSync(APP, OPTS){
  (async () => {
    OPTS = OPTS || {};
    const SY = new Date(); const FROM = OPTS.from || new Date(SY.getMonth() >= 7 ? SY.getFullYear() : SY.getFullYear() - 1, 8, 1).getTime();
    const enc = d => btoa(unescape(encodeURIComponent(JSON.stringify(d)))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
    const RET = APP === '__RETURN__';
    const say = m => { if(RET) window.__msResult = {error: m}; else alert(m); };
    const go = d => {
      if(RET){ window.__msResult = d; return; }
      const u = APP + '#sync=' + enc(d);
      if(!matchMedia('(pointer:coarse)').matches){ const w = window.open(u, 'miestudio'); if(!w) location.href = u; return; }
      /* Móvil: panel para elegir entre la app del navegador y la app instalada */
      const old = document.getElementById('__msPanel'); if(old) old.remove();
      const box = document.createElement('div'); box.id = '__msPanel';
      box.style.cssText = 'position:fixed;left:12px;right:12px;bottom:12px;z-index:2147483647;background:#1f3a5f;color:#fff;border-radius:16px;padding:16px;font:15px system-ui,sans-serif;box-shadow:0 8px 30px rgba(0,0,0,.45)';
      const title = document.createElement('div'); title.style.cssText = 'font-weight:700;margin-bottom:8px';
      title.textContent = '⚡ Mi Estudio: ' + d.tasks.length + ' tareas de ' + ({moodle: 'Moodle', classroom: 'Classroom', electude: 'Electude'}[d.src]) + ' listas';
      const mk = (label, bg) => { const b = document.createElement('button'); b.type = 'button'; b.textContent = label; b.style.cssText = 'display:block;width:100%;margin:6px 0;padding:13px;border:0;border-radius:10px;font:600 15px system-ui,sans-serif;color:#fff;background:' + bg; return b; };
      const bCopy = mk('📋 Copiar para la app instalada', '#2f6fde'), bOpen = mk('🌐 Abrir en el navegador', '#4a5260'), bClose = mk('Cerrar', 'transparent');
      const info = document.createElement('div'); info.style.cssText = 'font-size:13px;opacity:.9;margin:4px 0';
      bCopy.onclick = async () => {
        try{ await navigator.clipboard.writeText(u); info.textContent = '✅ Copiado. Abre la app Mi Estudio y pulsa «📋 Pegar sincronización».'; }
        catch(e){ const ta = document.createElement('textarea'); ta.value = u; ta.readOnly = true; ta.style.cssText = 'width:100%;height:70px;color:#000;border-radius:8px'; box.insertBefore(ta, bClose); ta.focus(); ta.select(); info.textContent = 'Mantén pulsado el texto → Copiar. Después ábrelo en la app con «📋 Pegar sincronización».'; }
      };
      bOpen.onclick = () => { location.href = u; };
      bClose.onclick = () => box.remove();
      box.append(title, bCopy, bOpen, info, bClose); document.body.appendChild(box);
    };
    const sleep = ms => new Promise(r => setTimeout(r, ms));
    const prog = (txt) => { let b = document.getElementById('__msProg'); if(!b){ b = document.createElement('div'); b.id = '__msProg'; b.style.cssText = 'position:fixed;top:12px;right:12px;z-index:2147483647;background:#1f3a5f;color:#fff;padding:10px 14px;border-radius:10px;font:600 14px system-ui,sans-serif;box-shadow:0 6px 20px rgba(0,0,0,.35)'; document.body.appendChild(b); } b.textContent = '⚡ Mi Estudio: ' + txt; };
    const progDone = () => { const b = document.getElementById('__msProg'); if(b) b.remove(); };
    const MON = {gen:0,ene:0,jan:0,feb:1,febr:1,'març':2,marc:2,mar:2,abr:3,apr:3,maig:4,may:4,jun:5,juny:5,jul:6,ag:7,ago:7,aug:7,set:8,sep:8,sept:8,oct:9,nov:10,des:11,dic:11,dec:11};
    const parseDue = (txt) => {
      if(!txt) return null; const t = txt.toLowerCase();
      if(/publica|posted|publicad/.test(t)) return null;
      const now = new Date(); let d = null;
      if(/\b(avui|hoy|today)\b/.test(t)) d = new Date(now);
      else if(/\b(demà|dema|mañana|manana|tomorrow)\b/.test(t)){ d = new Date(now); d.setDate(d.getDate() + 1); }
      else if(/\b(ahir|ayer|yesterday)\b/.test(t)){ d = new Date(now); d.setDate(d.getDate() - 1); }
      else {
        const m = t.match(/(\d{1,2})\s*(?:de\s+|d['’]\s*)?([a-zçñ]+)/i);
        if(m){ const k = m[2].replace(/\.$/, ''); const mon = MON[k] ?? MON[k.slice(0,4)] ?? MON[k.slice(0,3)]; if(mon !== undefined){ d = new Date(now.getFullYear(), mon, +m[1]); const diff = d - now; if(diff > 180*864e5) d.setFullYear(d.getFullYear() - 1); if(diff < -180*864e5) d.setFullYear(d.getFullYear() + 1); } }
      }
      if(!d) return null;
      const tm = t.match(/(\d{1,2}):(\d{2})/); if(tm) d.setHours(+tm[1], +tm[2], 0, 0); else d.setHours(23, 59, 0, 0);
      return d.getTime();
    };
    const parseFull = (txt) => {
      const m = (txt || '').toLowerCase().match(/(\d{1,2})\s+(?:de\s+|d['’]\s*)?([a-zçñé]+)\.?,?\s+(?:de\s+)?(\d{4})(?:,?\s+(\d{1,2}):(\d{2})\s*(am|pm)?)?/);
      if(!m) return null; const k = m[2]; const mon = MON[k] ?? MON[k.slice(0,4)] ?? MON[k.slice(0,3)]; if(mon === undefined) return null;
      let hh = m[4] ? +m[4] : 23, mm = m[5] ? +m[5] : 59; if(m[6] === 'pm' && hh < 12) hh += 12; if(m[6] === 'am' && hh === 12) hh = 0;
      return new Date(+m[3], mon, +m[1], hh, mm).getTime();
    };
    try{
      const h = location.hostname;
      /* ---------- MOODLE ---------- */
      const sk = (window.M && M.cfg && M.cfg.sesskey) || ((document.documentElement.innerHTML.match(/"sesskey":"([^"]+)"/) || [])[1]);
      if(sk && window.M){
        const root = (M.cfg && M.cfg.wwwroot) || location.origin;
        const call = async (n, a) => { const r = await fetch(root + '/lib/ajax/service.php?sesskey=' + sk + '&info=' + n, {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify([{index: 0, methodname: n, args: a}])}); const j = await r.json(); if(j[0].error) throw new Error((j[0].exception && j[0].exception.message) || n); return j[0].data; };
        const now = Math.floor(Date.now() / 1000);
        prog('leyendo tareas pendientes…');
        /* Moodle devuelve como mucho 50 eventos por llamada: se piden páginas hasta que no lleguen más */
        const evs = []; let after = 0;
        for(let pg = 0; pg < 20; pg++){
          const a = {timesortfrom: Math.floor(FROM / 1000), limitnum: 50}; if(after) a.aftereventid = after;
          const ev = await call('core_calendar_get_action_events_by_timesort', a), got = ev.events || [];
          evs.push(...got);
          const last = ev.lastid || (got.length && got[got.length - 1].id);
          if(got.length < 50 || !last || last === after) break;
          after = last; prog('leyendo tareas pendientes (' + evs.length + ')…');
        }
        let cs = {courses: []}; try{ cs = await call('core_course_get_enrolled_courses_by_timeline_classification', {classification: 'inprogress', limit: 0, offset: 0}); }catch(e){}
        const failed = new Set();
        const tasks = evs.map(e => ({id: (String(e.url || '').match(/id=(\d+)/) || [])[1] || ('e' + e.id), title: e.activityname || e.name, course: e.course ? e.course.fullname : '', due: e.timesort * 1000, url: e.url || e.viewurl, kind: e.modulename, action: e.action ? e.action.name : '', late: !!e.overdue, status: e.overdue || e.timesort < now ? 'missing' : 'pending'}));
        const seen = new Set(tasks.map(t => String(t.id)));
        /* tareas entregadas / calificadas / no presentadas: estado de cada tarea del curso */
        const todo = [];
        for(const c of (cs.courses || [])){
          try{ const st = await call('core_courseformat_get_state', {courseid: c.id}); const S = typeof st === 'string' ? JSON.parse(st) : st;
            (S.cm || []).filter(m => m.module === 'assign' && m.uservisible !== false && !seen.has(String(m.id))).forEach(m => todo.push({cm: m, course: c.fullname})); }catch(e){ failed.add(c.fullname); }
        }
        let done = 0;
        const worker = async () => { for(;;){ const it = todo.shift(); if(!it) return; try{
          const html = await fetch(it.cm.url, {credentials: 'include'}).then(r => { if(!r.ok) throw new Error(r.status); return r.text(); });
          const d = new DOMParser().parseFromString(html, 'text/html');
          const sub = !!d.querySelector('td.submissionstatussubmitted, .submissionstatussubmitted');
          const graded = !!d.querySelector('td.submissiongraded, .submissiongraded');
          const overdue = !!d.querySelector('td.overdue, .overdue');
          let due = null;
          const dateLines = [...d.querySelectorAll('[data-region="activity-dates"] div, .activity-dates div, table.generaltable tr')].map(x => x.textContent.replace(/\s+/g, ' ').trim());
          for(const l of dateLines){ if(/venc|due|entrega|termini|límit|limit|cierre|tanca|closes/i.test(l) && !/pròrroga|prorroga|extension|ampliaci/i.test(l)){ const t = parseFull(l); if(t){ due = t; break; } } }
          let grade = '';
          d.querySelectorAll('table.generaltable td.cell.c1, table.generaltable td').forEach(td => { const t = td.textContent.trim(); if(!grade && /^-?\d+([.,]\d+)?\s*\/\s*\d+([.,]\d+)?$/.test(t)) grade = t.replace(/,00\b/g, '').replace(/\s+/g, ' '); });
          const status = graded ? 'graded' : sub ? 'submitted' : overdue ? 'missing' : 'pending';
          if(!(due && due < FROM)) tasks.push({id: it.cm.id, title: it.cm.name, course: it.course, due, url: it.cm.url, kind: 'assign', status, grade: graded ? grade : '', late: status === 'missing'});
        }catch(e){ failed.add(it.course); } done++; prog('leyendo tareas ' + done + '/' + total + '…'); } };
        const total = todo.length;
        await Promise.all([worker(), worker(), worker(), worker()]);
        progDone();
        return go({src: 'moodle', at: Date.now(), site: root, tasks,
          warn: failed.size ? 'no se pudieron leer del todo ' + failed.size + ' curso(s): ' + [...failed].slice(0, 3).join(', ') + (failed.size > 3 ? '…' : '') : '',
          courses: (cs.courses || []).map(c => ({id: c.id, name: c.fullname, url: c.viewurl}))});
      }
      /* ---------- CLASSROOM ---------- */
      if(/(^|\.)classroom\.google\.com$/.test(h)){
        const u = (location.pathname.match(/^\/u\/\d+/) || [''])[0];
        const now = Date.now();
        const read = () => [...document.querySelectorAll('li')].filter(li => li.querySelector('a[href*="/details"]')).map(li => {
          const a = li.querySelector('a[href*="/details"]'), href = a.getAttribute('href');
          const leaves = [...li.querySelectorAll('*')].filter(e => !e.children.length && e.textContent.trim() && !/google-symbols|material-icons/.test(e.className)).map(e => e.textContent.trim());
          const rest = leaves.slice(2).join(' | ');
          const gm = rest.match(/(-?[\d.,]+)\s*(?:punts|puntos|points|punti|points?)\s*(?:de|of|di|sur)\s*([\d.,]+)/i);
          const turned = /lliurat|entregad|turned in|consegnat|remis/i.test(rest) && !/sense lliurar|sin entregar|missing|non consegnat/i.test(rest);
          const missingTxt = /sense lliurar|sin entregar|missing|non consegnat|non remis/i.test(rest);
          const dueTxt = leaves.slice(2).find(x => /\d|avui|demà|hoy|mañana|today|tomorrow|ahir|ayer/i.test(x) && !/punts|puntos|points|^\/|^\d+([.,]\d+)?$/i.test(x)) || '';
          const due = parseDue(dueTxt);
          const status = gm && !missingTxt ? 'graded' : turned ? 'submitted' : (missingTxt || (due && due < now)) ? 'missing' : 'pending';
          return {id: (href.match(/\/(?:a|sa|mc|q)\/([^/]+)/) || [])[1] || href, title: leaves[0] || '', course: leaves[1] || '', due, dueText: /publica|posted/i.test(dueTxt) ? '' : dueTxt, url: 'https://classroom.google.com' + href, kind: 'classroom', status, grade: gm ? gm[1] + '/' + gm[2] : '', late: status === 'missing'};
        });
        const waitFor = async (re) => { for(let i = 0; i < 30; i++){ if(re.test(location.pathname)) { await sleep(1200); return true; } await sleep(200); } return false; };
        /* Classroom pliega algunas secciones («Más adelante», «Anteriores»…) y carga más tareas al bajar:
           se despliegan, se baja hasta el final y se espera a que la lista deje de crecer */
        const opened = new WeakSet();
        const MORE = /^(veure'n més|veure més|mostra'n més|mostrar més|ver más|mostrar más|view more|show more|load more)$/i;
        const settle = async () => {
          let last = -1, same = 0;
          for(let i = 0; i < 40 && same < 3; i++){
            document.querySelectorAll('[aria-expanded="false"]').forEach(b => {
              const hp = b.getAttribute('aria-haspopup');
              if(opened.has(b) || (hp && hp !== 'false') || b.closest('header,nav,[role=navigation],[role=banner],[role=dialog],[role=menu]')) return;
              opened.add(b); try{ b.click(); }catch(e){}
            });
            [...document.querySelectorAll('button,[role=button]')].filter(b => !opened.has(b) && MORE.test((b.innerText || '').trim())).forEach(b => { opened.add(b); try{ b.click(); }catch(e){} });
            [...document.querySelectorAll('main *, [role=main] *')].filter(e => e.scrollHeight > e.clientHeight + 20 && /(auto|scroll)/.test(getComputedStyle(e).overflowY)).forEach(e => { e.scrollTop = e.scrollHeight; });
            window.scrollTo(0, document.documentElement.scrollHeight);
            await sleep(500);
            const n = document.querySelectorAll('li a[href*="/details"]').length;
            if(n === last) same++; else { same = 0; last = n; }
          }
          window.scrollTo(0, 0);
        };
        const tab = re => [...document.querySelectorAll('a[href]')].find(x => re.test(x.getAttribute('href')));
        if(!/\/a\/(not-turned-in|missing|turned-in)\//.test(location.pathname)){
          const t = tab(/\/a\/not-turned-in\//); if(!t){ say('Mi Estudio: abre Classroom → «Pendientes» (menú de la izquierda) y pulsa el marcador allí.'); return; }
          t.click(); await waitFor(/not-turned-in/);
        }
        const all = [];
        for(const [re, label] of [[/\/a\/not-turned-in\//, 'asignadas'], [/\/a\/missing\//, 'sin entregar'], [/\/a\/turned-in\//, 'hechas']]){
          prog('leyendo ' + label + '…');
          if(!re.test(location.pathname)){ const t = tab(re); if(!t) continue; t.click(); await waitFor(re); }
          await settle();
          all.push(...read());
        }
        progDone();
        const rank = {graded: 4, submitted: 3, missing: 2, pending: 1}, byId = {};
        all.forEach(t => { const o = byId[t.id]; if(!o || rank[t.status] > rank[o.status]) byId[t.id] = t; });
        const tasks = Object.values(byId).filter(t => !(t.due && t.due < FROM));
        const acc = ([...document.querySelectorAll('[aria-label*="@"]')].map(e => (e.getAttribute('aria-label').match(/[\w.+-]+@[\w-]+(\.[\w-]+)+/) || [])[0]).find(Boolean)) || '';
        const courses = [...document.querySelectorAll('a[href]')].filter(x => new RegExp('^' + u + '/c/[^/]+$').test(x.getAttribute('href'))).map(x => ({id: x.getAttribute('href').split('/c/')[1], name: (x.textContent || '').trim().replace(/^[A-Z]\s*/, ''), url: 'https://classroom.google.com' + x.getAttribute('href')})).filter((c, i, arr) => c.name && arr.findIndex(z => z.id === c.id) === i);
        return go({src: 'classroom', at: Date.now(), account: acc, tasks, courses});
      }
      /* ---------- ELECTUDE ---------- */
      if(/(^|\.)electude\./.test(h)){
        say('Mi Estudio: la sincronización de Electude todavía no está disponible.'); return;
      }
      say('Mi Estudio: abre Moodle, Classroom o Electude (con tu sesión iniciada) y pulsa este marcador allí.');
    }catch(e){ const b = document.getElementById('__msProg'); if(b) b.remove(); say('Mi Estudio: no se pudo sincronizar (' + e.message + ')'); }
  })();
}
