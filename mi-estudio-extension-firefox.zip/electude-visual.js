// Geometría de las capturas y puntos reales. No estima la respuesta académica.
((scope) => {
  'use strict';
  const inside = (p, r) => p.x >= r.x && p.y >= r.y && p.x <= r.x + r.width && p.y <= r.y + r.height;
  function purpleDots(image){
    const {data, width, height} = image, seen = new Uint8Array(width * height), dots = [];
    const purple = i => { const o = i * 4, r = data[o], g = data[o + 1], b = data[o + 2]; return b > 130 && r > 50 && r < b * 1.12 && g < r * .72 && g < b * .65; };
    for(let i = 0; i < seen.length; i++){
      if(seen[i] || !purple(i)) continue;
      const queue = [i]; seen[i] = 1;
      let minX = width, maxX = 0, minY = height, maxY = 0, sumX = 0, sumY = 0;
      for(let q = 0; q < queue.length; q++){
        const v = queue[q], x = v % width, y = Math.floor(v / width);
        minX = Math.min(minX, x); maxX = Math.max(maxX, x); minY = Math.min(minY, y); maxY = Math.max(maxY, y); sumX += x; sumY += y;
        for(const next of [x > 0 ? v - 1 : -1, x + 1 < width ? v + 1 : -1, y > 0 ? v - width : -1, y + 1 < height ? v + width : -1]){
          if(next >= 0 && !seen[next] && purple(next)){ seen[next] = 1; queue.push(next); }
        }
      }
      const w = maxX - minX + 1, h = maxY - minY + 1, area = queue.length;
      if(w < 3 || h < 3 || w > 40 || h > 40 || w / h < .65 || w / h > 1.55 || area < 12 || area / (w * h) < .55) continue;
      dots.push({x: (sumX / area + .5) / width * 1000, y: (sumY / area + .5) / height * 1000});
    }
    return dots;
  }
  function inventory(domPoints, pixels, regions, viewport){
    const output = [];
    for(const point of [...domPoints, ...pixels]){
      if(!Number.isFinite(point.x) || !Number.isFinite(point.y) || !regions.some(region => inside(point, region))) continue;
      if(output.some(p => Math.hypot((p.x - point.x) * viewport.width / 1000, (p.y - point.y) * viewport.height / 1000) < 10)) continue;
      output.push({x: point.x, y: point.y, label: String(point.label || '').slice(0, 120)});
      if(output.length >= 60) break;
    }
    return output.sort((a, b) => a.y - b.y || a.x - b.x).map((p, i) => ({...p, id: 'H' + (i + 1)}));
  }
  function parsePoints(text){
    const points = [];
    for(const match of String(text || '').matchAll(/^\s*PUNTO\s*:\s*(.*?)\s*\|\s*(.+)$/gim)){
      const id = match[2].match(/\b(?:id\s*=\s*)?(H\d+)\b/i), xy = match[2].match(/\bx\s*=\s*(\d+(?:\.\d+)?)\s*[,;]?\s*y\s*=\s*(\d+(?:\.\d+)?)/i);
      points.push({label: match[1].trim(), ...(id ? {id: id[1].toUpperCase()} : xy ? {x: +xy[1], y: +xy[2]} : {})});
    }
    return points;
  }
  function choiceBox(text, viewport){
    const matches=[...String(text||'').matchAll(/^\s*CAJA\s*:\s*(\d{1,4})\s*,\s*(\d{1,4})\s*,\s*(\d{1,4})\s*,\s*(\d{1,4})\s*$/gim)];
    if(matches.length!==1)return null;
    const [x1,y1,x2,y2]=matches[0].slice(1).map(Number);
    const width=(x2-x1)*viewport.width/1000, height=(y2-y1)*viewport.height/1000;
    if(x2>1000||y2>1000||width<20||height<9||height>96||width<height)return null;
    return {left:x1*viewport.width/1000,top:y1*viewport.height/1000,width,height};
  }
  function bindPoints(points, hotspots, viewport){
    const used = new Set(), mapped = [], rejected = [];
    points.forEach((point, index) => {
      let target = point.id ? hotspots.find(h => h.id === point.id) : null;
      if(!point.id && Number.isFinite(point.x) && Number.isFinite(point.y)){
        const near = hotspots.map(h => ({h, d: Math.hypot((h.x - point.x) * viewport.width / 1000, (h.y - point.y) * viewport.height / 1000)})).filter(p => p.d <= 18).sort((a, b) => a.d - b.d);
        if(near.length === 1 || near.length > 1 && near[1].d - near[0].d >= 8) target = near[0].h;
      }
      if(!target || used.has(target.id)){ rejected.push(index + 1); return; }
      used.add(target.id); mapped.push({...point, target, number: index + 1});
    });
    return {mapped, rejected};
  }
  // Transformación de un rectángulo de iframe al viewport superior (incluye escala CSS).
  function frameRect(rect, frame, client){
    const sx = frame.width / client.width, sy = frame.height / client.height;
    return {left: frame.left + rect.left * sx, top: frame.top + rect.top * sy, width: rect.width * sx, height: rect.height * sy};
  }
  function anchor(point, region, viewport){
    const x = point.x / 1000 * viewport.width, y = point.y / 1000 * viewport.height;
    return {u: (x - region.left) / region.width, v: (y - region.top) / region.height};
  }
  const position = (a, rect) => ({x: rect.left + a.u * rect.width, y: rect.top + a.v * rect.height});
  const sameRect = (a, b, tolerance = 1) => !!(a && b) && ['left','top','width','height'].every(key => Number.isFinite(a[key]) && Number.isFinite(b[key]) && Math.abs(a[key] - b[key]) <= tolerance);
  function darkFill(image, rect){
    if(!rect || !['left','top','width','height'].every(k => Number.isFinite(rect[k])) || rect.width <= 0 || rect.height <= 0) return null;
    const x = (rect.left + rect.width / 2) / 1000 * image.width, y = (rect.top + rect.height / 2) / 1000 * image.height;
    const rx = rect.width / 2000 * image.width, ry = rect.height / 2000 * image.height;
    if(rx < 4 || ry < 4 || rx > image.width / 12 || ry > image.height / 8 || x-rx < 0 || y-ry < 0 || x+rx >= image.width || y+ry >= image.height) return null;
    let dark = 0, total = 0;
    for(let dy = -Math.ceil(ry); dy <= ry; dy++) for(let dx = -Math.ceil(rx); dx <= rx; dx++){
      const radius = Math.hypot(dx/rx,dy/ry); if(radius < .58 || radius > .78) continue;
      const i = (Math.floor(y+dy) * image.width + Math.floor(x+dx)) * 4;
      if(image.data[i+3] < 200) continue;
      total++; if(Math.max(image.data[i],image.data[i+1],image.data[i+2]) < 95) dark++;
    }
    return total >= 12 ? dark/total : null;
  }
  function readVFPairs(image, pairs){
    return pairs.map(pair => {
      const no = darkFill(image,pair.no), yes = darkFill(image,pair.yes);
      const value = no === null || yes === null ? null : yes > .65 && no < .35 ? true : no > .65 && yes < .35 ? false : null;
      return {id: pair.id, value};
    });
  }
  function readChoices(image,choices){return choices.map(choice=>{const fill=darkFill(image,choice.rect);return{id:choice.id,value:fill===null?null:fill>.65?true:fill<.35?false:null};});}
  const exported = {inside, purpleDots, inventory, parsePoints, choiceBox, bindPoints, frameRect, anchor, position, sameRect, darkFill, readVFPairs,readChoices};
  scope.MiEstudioVisual = exported;
  if(typeof module !== 'undefined' && module.exports) module.exports = exported;
})(globalThis);
