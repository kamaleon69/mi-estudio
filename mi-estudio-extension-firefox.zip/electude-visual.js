// Geometría de las capturas y puntos reales. No estima la respuesta académica.
((scope) => {
  'use strict';
  const inside = (p, r) => p.x >= r.x && p.y >= r.y && p.x <= r.x + r.width && p.y <= r.y + r.height;
  function purpleDots(image){
    const {data, width, height} = image, seen = new Uint8Array(width * height), dots = [];
    const purple = i => { const o = i * 4, r = data[o], g = data[o + 1], b = data[o + 2]; return b > 130 && r > 50 && r < b * 1.12 && g < r * .72 && g < b * .65; };
    for(let i = 0; i < seen.length; i++){
      if(seen[i] || !purple(i)) continue;
      const queue = [i]; seen[i] = 1;
      let minX = width, maxX = 0, minY = height, maxY = 0, sumX = 0, sumY = 0;
      for(let q = 0; q < queue.length; q++){
        const v = queue[q], x = v % width, y = Math.floor(v / width);
        minX = Math.min(minX, x); maxX = Math.max(maxX, x); minY = Math.min(minY, y); maxY = Math.max(maxY, y); sumX += x; sumY += y;
        for(const next of [x > 0 ? v - 1 : -1, x + 1 < width ? v + 1 : -1, y > 0 ? v - width : -1, y + 1 < height ? v + width : -1]){
          if(next >= 0 && !seen[next] && purple(next)){ seen[next] = 1; queue.push(next); }
        }
      }
      const w = maxX - minX + 1, h = maxY - minY + 1, area = queue.length;
      if(w < 3 || h < 3 || w > 40 || h > 40 || w / h < .65 || w / h > 1.55 || area < 12 || area / (w * h) < .55) continue;
      dots.push({x: (sumX / area + .5) / width * 1000, y: (sumY / area + .5) / height * 1000});
    }
    return dots;
  }
  function inventory(domPoints, pixels, regions, viewport){
    const output = [];
    for(const point of [...domPoints, ...pixels]){
      if(!Number.isFinite(point.x) || !Number.isFinite(point.y) || !regions.some(region => inside(point, region))) continue;
      if(output.some(p => Math.hypot((p.x - point.x) * viewport.width / 1000, (p.y - point.y) * viewport.height / 1000) < 10)) continue;
      output.push({x: point.x, y: point.y, label: String(point.label || '').slice(0, 120)});
      if(output.length >= 60) break;
    }
    return output.sort((a, b) => a.y - b.y || a.x - b.x).map((p, i) => ({...p, id: 'H' + (i + 1)}));
  }
  function parsePoints(text){
    const points = [];
    for(const match of String(text || '').matchAll(/^\s*PUNTO\s*:\s*(.*?)\s*\|\s*(.+)$/gim)){
      const id = match[2].match(/\b(?:id\s*=\s*)?(H\d+)\b/i), xy = match[2].match(/\bx\s*=\s*(\d+(?:\.\d+)?)\s*[,;]?\s*y\s*=\s*(\d+(?:\.\d+)?)/i);
      points.push({label: match[1].trim(), ...(id ? {id: id[1].toUpperCase()} : xy ? {x: +xy[1], y: +xy[2]} : {})});
    }
    return points;
  }
  function choiceBox(text, viewport){
    const matches=[...String(text||'').matchAll(/^\s*CAJA\s*:\s*(\d{1,4})\s*,\s*(\d{1,4})\s*,\s*(\d{1,4})\s*,\s*(\d{1,4})\s*$/gim)];
    if(matches.length!==1)return null;
    const [x1,y1,x2,y2]=matches[0].slice(1).map(Number);
    const width=(x2-x1)*viewport.width/1000, height=(y2-y1)*viewport.height/1000;
    if(x2>1000||y2>1000||width<20||height<9||height>96||width<height)return null;
    return {left:x1*viewport.width/1000,top:y1*viewport.height/1000,width,height};
  }
  // Controles oscuros sobre el fondo neutro del cuestionario, en coordenadas de la captura.
  function quizRows(image, viewport, activity){
    const {data,width,height}=image;
    const scale=width/viewport.width;
    if(!Number.isFinite(scale)||scale<=0)return [];
    const dark=new Uint8Array(width*height), rings=[];
    for(let i=0;i<dark.length;i++){
      const p=i*4;
      dark[i]=Math.max(data[p],data[p+1],data[p+2])<122?1:0;
    }
    const pixel=(x,y)=>Math.round(y)*width+Math.round(x);
    const gray=(x,y)=>{
      const p=pixel(x,y)*4, lo=Math.min(data[p],data[p+1],data[p+2]), hi=Math.max(data[p],data[p+1],data[p+2]);
      return lo>=178&&hi-lo<=12?lo:0;
    };
    const angles=Array.from({length:16},(_,i)=>[Math.cos(i*Math.PI/8),Math.sin(i*Math.PI/8)]);
    for(let i=0;i<dark.length;i++){
      if(dark[i]!==1)continue;
      const queue=[i];dark[i]=2;
      let left=i%width,right=left,top=Math.floor(i/width),bottom=top;
      for(let k=0;k<queue.length;k++){
        const index=queue[k], x=index%width,y=Math.floor(index/width);
        left=Math.min(left,x);right=Math.max(right,x);top=Math.min(top,y);bottom=Math.max(bottom,y);
        for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++){
          if(x+dx<0||x+dx>=width||y+dy<0||y+dy>=height)continue;
          const next=index+dy*width+dx;
          if(dark[next]===1){dark[next]=2;queue.push(next);}
        }
      }
      const w=right-left+1,h=bottom-top+1,x=(left+right)/2,y=(top+bottom)/2;
      if(w<13*scale||h<13*scale||w>32*scale||h>32*scale||Math.abs(w-h)>Math.min(w,h)*.22||left<4||right+4>=width||top<4||bottom+4>=height)continue;
      const border=angles.filter(([cx,cy])=>[.89,.96,1.03].some(f=>dark[pixel(x+cx*w*.5*f,y+cy*h*.5*f)]>0)).length;
      const corners=[[-1,-1],[-1,1],[1,-1],[1,1]].map(([dx,dy])=>gray(x+dx*w*.54,y+dy*h*.54));
      if(border<12||corners.filter(Boolean).length<3)continue;
      rings.push({x,y,w,h,left,top,shade:corners.filter(Boolean).sort((a,b)=>b-a)[0]});
    }
    const columns=[];
    for(const ring of rings.sort((a,b)=>a.y-b.y||a.x-b.x)){
      const column=columns.find(items=>Math.abs(items[0].x-ring.x)<=2.5*scale&&Math.abs(items[0].w-ring.w)<=3*scale&&ring.y-items.at(-1).y>=ring.h*1.15&&ring.y-items.at(-1).y<100*scale);
      if(column)column.push(ring);else columns.push([ring]);
    }
    const groups=columns.filter(column=>column.length>=2).map(column=>({
      column,
      twins:column.map(ring=>rings.find(other=>other.x-ring.x>=ring.w*.9&&other.x-ring.x<=ring.w*1.65&&
        Math.abs(other.y-ring.y)<=2*scale&&Math.abs(other.w-ring.w)<=3*scale))
    }));
    const candidates=groups.filter(group=>!groups.some(other=>other!==group&&group.column.every(ring=>other.twins.includes(ring))));
    const inActivity=activity?candidates.filter(({column})=>column.every(ring=>inside({x:ring.x/width*1000,y:ring.y/height*1000},activity))):[];
    const preferred=inActivity.length?inActivity:candidates;
    if(preferred.length!==1)return [];
    const {column,twins}=preferred[0];
    const paired=twins.every(Boolean);
    if(!paired&&twins.some(Boolean))return [];
    const normalized=(left,top,w,h)=>({x:left/width*1000,y:top/height*1000,width:w/width*1000,height:h/height*1000});
    return column.map((ring,index)=>{
      const control=normalized(ring.left,ring.top,ring.w,ring.h);
      if(paired){
        const twin=twins[index];
        return {id:'S'+(index+1),control,yes:normalized(twin.left,twin.top,twin.w,twin.h)};
      }
      // Encierra una sola línea. El borde derecho sigue el fondo de la fila.
      let right=ring.left;
      for(const offset of [2,3,4,5]){
        const scanY=ring.top-offset;
        let edge=Math.round(ring.x+ring.w);
        while(edge<width-2&&Math.abs(gray(edge,scanY)-ring.shade)<=16)edge++;
        right=Math.max(right,edge);
      }
      const rowWidth=Math.max(right-ring.left,Math.min(width-ring.left,220*scale));
      return {id:'S'+(index+1),control,row:normalized(ring.left,ring.top,rowWidth,ring.h)};
    });
  }
  function screenSelections(text, rows){
    const selections=new Map(), conflicts=new Set();
    for(const match of String(text||'').matchAll(/^\s*(MARCA|RESPUESTA|VF)\s*:\s*\[?(S\d+)\]?(?:\s*(?:=>?|→|:)\s*(VERDADERO|FALSO|CERT|FALS|V|F)\b)?(?=\s|[|.,;]|$)/gim)){
      const row=rows.find(item=>item.id===match[2].toUpperCase());
      const truth=match[3]?/^(V|CERT)/i.test(match[3]):null;
      if(!row||Boolean(row.yes)!==(truth!==null))continue;
      if(selections.has(row.id)&&selections.get(row.id).truth!==truth)conflicts.add(row.id);
      selections.set(row.id,{row,truth});
    }
    return [...selections.values()].filter(({row})=>!conflicts.has(row.id));
  }
  function bindPoints(points, hotspots, viewport){
    const used = new Set(), mapped = [], rejected = [];
    points.forEach((point, index) => {
      let target = point.id ? hotspots.find(h => h.id === point.id) : null;
      if(!point.id && Number.isFinite(point.x) && Number.isFinite(point.y)){
        const near = hotspots.map(h => ({h, d: Math.hypot((h.x - point.x) * viewport.width / 1000, (h.y - point.y) * viewport.height / 1000)})).filter(p => p.d <= 18).sort((a, b) => a.d - b.d);
        if(near.length === 1 || near.length > 1 && near[1].d - near[0].d >= 8) target = near[0].h;
      }
      if(!target || used.has(target.id)){ rejected.push(index + 1); return; }
      used.add(target.id); mapped.push({...point, target, number: index + 1});
    });
    return {mapped, rejected};
  }
  // Transformación de un rectángulo de iframe al viewport superior (incluye escala CSS).
  function frameRect(rect, frame, client){
    const sx = frame.width / client.width, sy = frame.height / client.height;
    return {left: frame.left + rect.left * sx, top: frame.top + rect.top * sy, width: rect.width * sx, height: rect.height * sy};
  }
  function anchor(point, region, viewport){
    const x = point.x / 1000 * viewport.width, y = point.y / 1000 * viewport.height;
    return {u: (x - region.left) / region.width, v: (y - region.top) / region.height};
  }
  const position = (a, rect) => ({x: rect.left + a.u * rect.width, y: rect.top + a.v * rect.height});
  const sameRect = (a, b, tolerance = 1) => !!(a && b) && ['left','top','width','height'].every(key => Number.isFinite(a[key]) && Number.isFinite(b[key]) && Math.abs(a[key] - b[key]) <= tolerance);
  function darkFill(image, rect){
    if(!rect || !['left','top','width','height'].every(k => Number.isFinite(rect[k])) || rect.width <= 0 || rect.height <= 0) return null;
    const x = (rect.left + rect.width / 2) / 1000 * image.width, y = (rect.top + rect.height / 2) / 1000 * image.height;
    const rx = rect.width / 2000 * image.width, ry = rect.height / 2000 * image.height;
    if(rx < 4 || ry < 4 || rx > image.width / 12 || ry > image.height / 8 || x-rx < 0 || y-ry < 0 || x+rx >= image.width || y+ry >= image.height) return null;
    let dark = 0, total = 0;
    for(let dy = -Math.ceil(ry); dy <= ry; dy++) for(let dx = -Math.ceil(rx); dx <= rx; dx++){
      const radius = Math.hypot(dx/rx,dy/ry); if(radius < .58 || radius > .78) continue;
      const i = (Math.floor(y+dy) * image.width + Math.floor(x+dx)) * 4;
      if(image.data[i+3] < 200) continue;
      total++; if(Math.max(image.data[i],image.data[i+1],image.data[i+2]) < 95) dark++;
    }
    return total >= 12 ? dark/total : null;
  }
  function readVFPairs(image, pairs){
    return pairs.map(pair => {
      const no = darkFill(image,pair.no), yes = darkFill(image,pair.yes);
      const value = no === null || yes === null ? null : yes > .65 && no < .35 ? true : no > .65 && yes < .35 ? false : null;
      return {id: pair.id, value};
    });
  }
  function readChoices(image,choices){return choices.map(choice=>{const fill=darkFill(image,choice.rect);return{id:choice.id,value:fill===null?null:fill>.65?true:fill<.35?false:null};});}
  const exported = {inside, purpleDots, inventory, parsePoints, choiceBox, quizRows, screenSelections, bindPoints, frameRect, anchor, position, sameRect, darkFill, readVFPairs,readChoices};
  scope.MiEstudioVisual = exported;
  if(typeof module !== 'undefined' && module.exports) module.exports = exported;
})(globalThis);
