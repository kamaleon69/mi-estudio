// Protocolo y validación del autocompletado. También se prueba con node:test.
((scope) => {
  'use strict';
  const DEFAULTS = Object.freeze({enabled: false, min: 7, max: 15});
  const normalize = value => String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[«»"“”.,;:¿?¡!()]/g, '').replace(/\s+/g, ' ').trim();
  function range(min, max){
    if(String(min).trim() === '' || String(max).trim() === '') return {error: 'Indica el tiempo mínimo y el máximo.'};
    const lo = Number(min), hi = Number(max);
    if(!Number.isFinite(lo) || !Number.isFinite(hi) || lo < 0 || hi > 3600 || lo > hi) return {error: 'Usa tiempos de 0 a 3600 segundos y un mínimo que no supere el máximo.'};
    return {min: lo, max: hi};
  }
  function settings(value){
    const v = value && typeof value === 'object' ? value : {};
    const r = range(v.min ?? DEFAULTS.min, v.max ?? DEFAULTS.max);
    return {enabled: v.enabled === true, min: r.error ? DEFAULTS.min : r.min, max: r.error ? DEFAULTS.max : r.max};
  }
  const delay = (value, random = Math.random) => {
    const s = settings(value), n = Math.max(0, Math.min(1, random()));
    return Math.round((s.min + (s.max - s.min) * n) * 1000);
  };
  function reference(value){
    const text = String(value).trim();
    const m = text.match(/^\[?([OVC]\d+)\]?(?:\s*[|:]\s*|\s+)?(.*)$/i);
    return m ? {id: m[1].toUpperCase(), text: m[2].trim()} : {id: '', text};
  }
  function parse(value){
    const text = String(value || '').replace(/\*\*/g, '');
    const result = {answers: [], vfs: [], fields: [], evidence: [], confidence: [], visual: false, lowConfidence: /^\s*FIABILIDAD\s*:\s*BAJA\b/im.test(text),mediumConfidence:/^\s*FIABILIDAD\s*:\s*MEDIA\b/im.test(text)};
    for(const raw of text.split('\n')){
      const line = raw.trim().replace(/^(?:[-*•]|\d+[.)])\s+/, '').replace(/^`([^`]+)`$/, '$1');
      let m;
      if((m = line.match(/^RESPUESTA\s*:\s*(.+)$/i))){
        const content=m[1].trim();
        if(/^(?:\[?O\d+\]?\s*(?:(?:[,;|+/]|\b(?:y|i|and)\b)\s*)?)+$/i.test(content)) result.answers.push(...[...content.matchAll(/O\d+/gi)].map(a=>({id:a[0].toUpperCase(),text:''})));
        else result.answers.push(reference(content));
      }
      else if((m = line.match(/^VF\s*:\s*(.+?)\s*(?:=>?|→|:)\s*(VERDADERO|FALSO|VERDADER|VERTADER|CIERTO|CERT|FALS|TRUE|FALSE|V|F)\b(?:\s*[|–-]\s*(.*))?$/i))) result.vfs.push({...reference(m[1]), value: /^(V|TRUE|CERT|CIERTO)/i.test(m[2]), why: m[3] || ''});
      else if((m = line.match(/^CAMPO\s*:\s*\[?(C\d+)\]?\s*(?:=>|→)\s*(.+)$/i))){let value=m[2].trim();if(/^(["'`]).*\1$/.test(value))value=value.slice(1,-1);result.fields.push({id:m[1].toUpperCase(),value});}
      else if((m = line.match(/^APOYO\s*:\s*\[?(V\d+)\]?\s*=>\s*(.*)$/i))) result.evidence.push({id: m[1].toUpperCase(), text: m[2].trim().replace(/^[«“"]|[»”"]$/g, '')});
      else if((m = line.match(/^CONFIANZA\s*:\s*\[?(V\d+)\]?\s*=>\s*(ALTA|MEDIA|BAJA)\s*$/i))) result.confidence.push({id: m[1].toUpperCase(), value: m[2].toUpperCase()});
      else if(/^PUNTO\s*:|^ACCI[OÓ]N\s*:/i.test(line)) result.visual = true;
    }
    return result;
  }
  function resolve(ref, targets){
    if(ref.id) return targets.find(t => t.id === ref.id) || null;
    const matches = targets.filter(t => normalize(t.text) === normalize(ref.text));
    return matches.length === 1 ? matches[0] : null;
  }
  function needsVision(question){
    const text = normalize(question);
    return /\b(?:quin|que|qual|cual|which|what)\s+(?:numero|number)\b.{0,100}\b(?:indica|identifica|assenyala|senala|correspon|shows|indicates|identifies)/.test(text)
      || /\b(?:localitza|localiza|localice|locate|fes clic|haz clic|clica)\b/.test(text)
      || /\b(?:dibuix|dibujo|diagrama|diagram|imatge|imagen|image|figura|figure|fotografia|illustration|esquema)\b/.test(text);
  }
  function pointQuestion(question){
    const text=normalize(question);
    const surface='(?:dibuix|dibujo|imatge|imagen|figura|esquema|diagrama|image|drawing|diagram)';
    return /\b(?:localitza|localiza|localice|locate)\s+(?:(?:els|les|los|las|the)\s+)?(?:(?:seguents|siguientes|following)\s+)?(?:components?|componentes?|parts?|peces|piezas|punts|puntos|points)\b/.test(text)
      || new RegExp('\\b(?:fes clic|haz clic|clica|click|assenyala|senala|localitza|localiza|locate)\\b.{0,80}\\b(?:en|sobre|al|a la|del|in|on)\\s+(?:el |la |l[’\']|the )?'+surface+'\\b').test(text)
      || new RegExp('\\bmarca\\s+(?:els? |los? |las? )?(?:punts?|puntos?|components?|componentes?|peces|piezas)\\b.{0,65}\\b'+surface+'\\b').test(text);
  }
  function visibleQuiz(text) {
    const lines = String(text || '').split(/\n+/).map(line => line.trim()).filter(Boolean);
    const question = lines.findIndex(line => line.includes('?'));
    if (question < 0) return '';
    return lines.slice(question)
      .filter(line => !/^(?:ok|d['’]acord|comprovar|comprobar|check)\.?$/i.test(line))
      .join('\n');
  }
  function feedback(value){
    const text = normalize(value);
    const summary = text.match(/(?:has? (?:avaluat|evaluado) correct(?:ament|amente)|you (?:have )?correctly (?:evaluated|answered))\s+(\d+)\s+(?:de(?: les| las| los| els)?|of(?: the)?)\s+(\d+)\b/);
    if(summary && +summary[2] > 0 && +summary[1] <= +summary[2]) return +summary[1] === +summary[2] ? 'correct' : 'incorrect';
    if(/^\s*(incorrecte|incorrecto|incorrect|wrong)\b/im.test(String(value || ''))) return 'incorrect';
    if(/^\s*(correcte|correcto|correct|ben fet|muy bien)\b/im.test(String(value || ''))) return 'correct';
    return '';
  }
  function adaptFields(value, registry){
    const parsed = parse(value);
    if((registry.choices || []).length || (registry.vfs || []).length || (registry.fields || []).length !== 1 || parsed.answers.length !== 1 || parsed.fields.length || parsed.vfs.length || parsed.visual) return String(value || '');
    const answer = parsed.answers[0], field = registry.fields[0];
    if(answer.id || !answer.text || answer.text.length > 100) return String(value || '');
    if((field.type === 'number' || field.numericReference) && !/^[+-]?\d+(?:[.,]\d+)?$/.test(answer.text)) return String(value || '');
    return String(value || '').replace(/^\s*RESPUESTA\s*:\s*.+$/im, 'CAMPO: ' + field.id + ' => ' + answer.text);
  }
  function repeatsRejected(value, rejected){
    if(!rejected || !rejected.length) return false;
    const fields = parse(value).fields;
    const equal = (a, b) => {
      const x = String(a).trim().replace(',', '.'), y = String(b).trim().replace(',', '.');
      return /^[+-]?\d+(?:\.\d+)?$/.test(x) && /^[+-]?\d+(?:\.\d+)?$/.test(y) ? Number(x) === Number(y) : normalize(a) === normalize(b);
    };
    return rejected.every(old => fields.some(field => field.id === old.id && equal(field.value, old.value)));
  }
  function completed(state){
    if(state.feedback || state.locked) return true;
    const {choices = [], vfs = [], fields = []} = state;
    if(!choices.length && !vfs.length && !fields.length) return false;
    const groups = new Map();
    for(const choice of choices){ if(!groups.has(choice.group)) groups.set(choice.group, false); if(choice.selected) groups.set(choice.group, true); }
    return [...groups.values()].every(Boolean) && vfs.every(row => row.answered) && fields.every(field => String(field.value ?? '').trim() !== '');
  }
  function plan(answer, registry){
    const fail = reason => ({ok: false, reason, actions: []});
    if(answer.lowConfidence) return fail('La IA indica poca fiabilidad. Revisa la sugerencia antes de responder.');
    if(answer.mediumConfidence)return fail('La IA declara fiabilidad media. Se conserva la sugerencia para revisión; no se hará el clic automático.');
    if(answer.visual) return fail('Esta actividad requiere una acción en el dibujo o una acción manual. Sigue las indicaciones del panel.');
    const {choices = [], vfs = [], fields = []} = registry;
    if(!choices.length && !vfs.length && !fields.length) return fail('No he identificado controles de respuesta que pueda rellenar. Sigue la sugerencia del panel.');
    const actions = [], selected = new Set();
    for(const ref of answer.answers){
      const target = resolve(ref, choices);
      if(!target || selected.has(target.id)) return fail('La respuesta no coincide de forma única con las opciones del ejercicio.');
      selected.add(target.id);
    }
    const groups = new Map();
    for(const target of choices){
      if(!groups.has(target.group)) groups.set(target.group, []);
      groups.get(target.group).push(target);
    }
    for(const targets of groups.values()){
      const picked = targets.filter(t => selected.has(t.id));
      const multiple = targets.every(t => t.kind === 'checkbox');
      if(!picked.length || (!multiple && picked.length !== 1)) return fail('Falta una elección o hay varias respuestas para una pregunta de opción única.');
      for(const target of targets) if(multiple || selected.has(target.id)) actions.push({type: 'choice', id: target.id, value: selected.has(target.id)});
    }
    if(answer.vfs.length !== vfs.length) return fail('La respuesta de verdadero/falso está incompleta. Vuelve a analizarla.');
    const seenVF = new Set();
    for(const ref of answer.vfs){
      const target = resolve(ref, vfs);
      if(!target || seenVF.has(target.id)) return fail('Hay una afirmación repetida o que no pertenece a este ejercicio.');
      seenVF.add(target.id); actions.push({type: 'vf', id: target.id, value: ref.value});
    }
    if(answer.fields.length !== fields.length) return fail('La IA no ha dado un valor para cada campo. Revisa los campos pendientes.');
    const seenFields = new Set();
    for(const ref of answer.fields){
      const target = fields.find(t => t.id === ref.id);
      if(!target || seenFields.has(target.id)) return fail('Hay un campo repetido o desconocido en la respuesta.');
      seenFields.add(target.id); actions.push({type: 'field', id: target.id, value: ref.value});
    }
    return actions.length ? {ok: true, actions} : fail('No hay una respuesta completa para rellenar.');
  }
  // Mantiene el formato del panel anterior, sustituyendo referencias por el texto real.
  function display(value, registry){
    return String(value || '').replace(/^(\s*RESPUESTA\s*:\s*)(.+)$/gim, (line, prefix, content) => {
      const t = resolve(reference(content), registry.choices || []); return t ? prefix + t.text : line;
    }).replace(/^(\s*VF\s*:\s*)(.+?)(\s*=>?\s*(?:VERDADERO|FALSO|V|F)\b.*)$/gim, (line, prefix, content, tail) => {
      const t = resolve(reference(content), registry.vfs || []); return t ? prefix + t.text + tail : line;
    });
  }
  const truthLabel = value => {
    const text = normalize(value).replace(/[✗✕✖×]/g, 'x').replace(/[✓✔]/g, 'v').trim();
    if(/^(false|falso|fals|incorrect|incorrecte|incorrecto|no|x|f)$/.test(text)) return false;
    if(/^(true|verdadero|vertader|verdader|cert|correct|correcte|correcto|yes|si|v)$/.test(text)) return true;
    return null;
  };
  function truthPair(items){
    if(items.length !== 2 || items[0].el === items[1].el) return {no: null, yes: null, binding: 'ambiguous'};
    const no = items.filter(i => i.value === false), yes = items.filter(i => i.value === true);
    if(no.length > 1 || yes.length > 1) return {no: null, yes: null, binding: 'ambiguous'};
    if(no.length || yes.length){
      const n = no[0] || items.find(i => i !== yes[0]), y = yes[0] || items.find(i => i !== no[0]);
      return {no: n.el, yes: y.el, binding: 'labels'};
    }
    return {no: items[0].el, yes: items[1].el, binding: 'electude-order'};
  }
  const quoteText = value => String(value || '').normalize('NFC').replace(/[“”«»]/g, '"').replace(/[’‘]/g, "'").replace(/\s+/g, ' ').trim().toLowerCase();
  function assessVF(value, context){
    if(!context || !(context.rows || []).length) return {ok: true, rows: []};
    const parsed = parse(value), theory = quoteText(context.theory), known = new Set(context.rows.map(r => r.id));
    const metadata = [...parsed.evidence, ...parsed.confidence];
    const extra = metadata.some(m => !known.has(m.id));
    const rows = context.rows.map(row => {
      const answers = parsed.vfs.filter(a => resolve(a, context.rows)?.id === row.id);
      const evidence = parsed.evidence.filter(a => a.id === row.id), confidence = parsed.confidence.filter(a => a.id === row.id);
      const quote = evidence[0]?.text || '', clean = quoteText(quote);
      const supported = evidence.length === 1 && clean.length >= 12 && clean.split(' ').length >= 3 && theory.includes(clean);
      const certain = confidence.length === 1 && confidence[0].value === 'ALTA';
      const reason = answers.length !== 1 ? 'Falta una respuesta única para esta fila.' : !supported ? 'No hay una cita verificable en la teoría recibida.' : !certain ? 'La confianza de esta fila no es alta.' : !answers[0].why.trim() ? 'Falta explicar cómo se relaciona la evidencia con esta frase.' : '';
      return {id: row.id, supported, confidence: confidence[0]?.value || 'SIN INDICAR', quote, reason, ok: !reason};
    });
    const uncertain = parsed.lowConfidence || /^\s*FIABILIDAD\s*:\s*MEDIA\b/im.test(String(value));
    const ok = !extra && !uncertain && rows.every(r => r.ok);
    return {ok, rows, reason: ok ? '' : 'No se autocompleta cierto/falso: ' + (extra ? 'hay referencias de otra actividad.' : uncertain ? 'la IA declara fiabilidad insuficiente.' : rows.filter(r => !r.ok).map(r => r.id + ': ' + r.reason).join(' '))};
  }
  function lessonContext(text, query, limit = 7000){
    const parts = String(text || '').split(/\n+/).map(t => t.trim()).filter(Boolean);
    const tokens = new Set(normalize(query).match(/[a-z\u00c0-\u024f]{4,}/g) || []);
    const scored = parts.map((part, index) => ({part, index, score: (normalize(part).match(/[a-z\u00c0-\u024f]{4,}/g) || []).reduce((n, word) => n + (tokens.has(word) ? 1 : 0), 0)}));
    const selected = new Set(); let size = 0;
    const add = index => { const item = scored[index]; if(!item || selected.has(index) || size + item.part.length + 1 > limit) return; selected.add(index); size += item.part.length + 1; };
    // Se conserva el contexto introductorio y las frases completas cercanas a los temas de la pregunta.
    add(0); add(1);
    for(const item of [...scored].sort((a,b) => b.score - a.score || a.index - b.index)){
      if(!item.score) continue;
      add(item.index - 1); add(item.index); add(item.index + 1);
    }
    for(const item of scored) add(item.index);
    return {text: [...selected].sort((a,b) => a-b).map(i => parts[i]).join('\n'), truncated: selected.size !== parts.length};
  }
  function vfPacket(context, limit = 12000){
    const rows = (context.rows || []).map(({id,text}) => ({id,text: String(text || '').slice(0, 600)}));
    const header = '--- ACTIVIDAD CIERTO/FALSO ---\n' + JSON.stringify({pregunta: String(context.question || '').slice(0, 1800), afirmaciones: rows}) + '\n--- TEORÍA DE ESTA LECCIÓN (evidencia, no opciones) ---\n';
    const available = Math.max(0, limit - header.length - 130);
    const lesson = lessonContext(context.theory, [context.question, ...rows.map(r => r.text)].join(' '), available);
    return {text: header + lesson.text + (lesson.truncated ? '\n[Teoría recortada: si falta la evidencia necesaria, indica confianza BAJA.]' : ''), theory: lesson.text, truncated: lesson.truncated};
  }
  const isPrecise = result => !!(result && result.precise === true && result.model && !/lite|haiku|nano/i.test(result.model));
  class Countdown {
    // Las funciones nativas de Window necesitan conservar su receptor.
    constructor({now = Date.now, every = (...args) => scope.setInterval(...args), clear = id => scope.clearInterval(id)} = {}){
      Object.assign(this, {now, every, clear, timer: null, job: null});
    }
    cancel(reason){
      if(this.timer !== null) this.clear(this.timer);
      const job = this.job; this.timer = null; this.job = null;
      if(job && job.onCancel) job.onCancel(reason);
    }
    start(job){
      this.cancel('replaced'); this.job = job;
      const end = this.now() + job.delay;
      const tick = () => {
        if(this.job !== job) return;
        if(!job.valid()){ this.cancel('stale'); return; }
        const left = Math.max(0, end - this.now());
        job.onTick(Math.ceil(left / 1000));
        if(left > 0) return;
        this.clear(this.timer); this.timer = null; this.job = null; job.run();
      };
      try{ this.timer = this.every(tick, 250); tick(); }
      catch(error){ this.cancel('error'); throw error; }
    }
  }
  // Conserva la primera fecha pendiente; una animación no pospone el trabajo sin fin.
  class Scheduler {
    constructor(run, options = {}){ this.run = run; this.now = options.now || (() => Date.now()); this.set = options.set || ((fn, ms) => setTimeout(fn, ms)); this.clear = options.clear || (id => clearTimeout(id)); this.timer = null; this.due = Infinity; }
    schedule(delay = 500){
      const due = this.now() + Math.max(0, delay);
      if(this.timer !== null && due >= this.due) return;
      this.cancel(); this.due = due;
      this.timer = this.set(() => { this.timer = null; this.due = Infinity; this.run(); }, Math.max(0, due - this.now()));
    }
    cancel(){ if(this.timer !== null) this.clear(this.timer); this.timer = null; this.due = Infinity; }
  }
  const questionText = value => String(value || '').replace(/^\s*(?:comprovar|comprobar|check|corregir|validar|submit)\s*$/gim,'').replace(/^\s*(?:has? (?:avaluat|evaluado) correct(?:ament|amente)|you (?:have )?correctly (?:evaluated|answered)).*$/gim, '').replace(/^\s*(?:correcte|incorrecte|correcto|incorrecto|correct|incorrect|torna-ho a provar|vuelve a intentarlo|ben fet|molt bé|muy bien|resposta correcta|respuesta correcta|has marcat aquesta part|abans marca aquesta|has marcado esta parte)\b.*$/gim, '').replace(/✓ Respuesta IA|✓ Verdadero|✗ Falso/g, '').replace(/\s+/g, ' ').trim();
  const matchesMode = (result, mode) => mode === 'precise' ? isPrecise(result) : !!(mode === 'fast' && result && result.model && result.precise === false);
  // La identidad describe la pregunta, sin valores seleccionados, bloqueo ni nodos del DOM.
  const structureKey = registry => JSON.stringify({choices:(registry.choices||[]).map(({id,text,kind,group})=>({id,text:normalize(text),kind,group})),vfs:(registry.vfs||[]).map(({id,text})=>({id,text:normalize(text)})),fields:(registry.fields||[]).map(({id,text,type,options})=>({id,text:normalize(text),type,options})),drawing:!!registry.drawing});
  function editsAnswer(event){
    if(['input','change','pointerdown'].includes(event.type))return event.type!=='pointerdown'||event.button===undefined||event.button===0;
    return event.type==='keydown'&&!event.ctrlKey&&!event.metaKey&&!event.altKey&&!['Tab','Escape','Shift','Control','Alt','Meta','CapsLock','PageUp','PageDown','Home','End'].includes(event.key);
  }
  const exported = {DEFAULTS, normalize, range, settings, delay, reference, parse, resolve, plan, display, needsVision, pointQuestion, visibleQuiz, feedback, adaptFields, repeatsRejected, completed, truthLabel, truthPair, assessVF, lessonContext, vfPacket, isPrecise, matchesMode, Countdown, Scheduler, questionText,structureKey,editsAnswer};
  scope.MiEstudioElectude = exported;
  if(typeof module !== 'undefined' && module.exports) module.exports = exported;
})(globalThis);
