// Mi Estudio · Ayuda IA en Electude: panel lateral que analiza el enunciado visible y señala la opción que la IA cree correcta.
// Autocompletado opcional con intervalo configurable. La comprobación la hace el alumno.
(() => {
  if(window.__msElec) return;
  const api = (typeof browser !== 'undefined' && browser.runtime) ? browser : chrome;
  const Core = globalThis.MiEstudioElectude;
  const Providers = globalThis.MiEstudioAI;
  const Visual = globalThis.MiEstudioVisual;
  const Diagnostics=globalThis.MiEstudioDiagnostics;
  const reportTrace=Diagnostics?new Diagnostics.Trace():{add(){},list(){return[];}};
  let permissionReady=false,pendingPermissionIntent=null,lastAttempt=null,reportPausedSig='';
  const extensionVersion = api.runtime.getManifest().version;
  let lastError = null;
  function recordError(stage, error){ lastError = {stage, message: String(error && error.message || error), stack: String(error && error.stack || '').slice(0, 1800)};reportTrace.add('error',lastError); }
  if(!Core || !Providers || !Visual || !Diagnostics) return;
  window.__msElec = true;
  const host = document.createElement('div'); host.id = '__msElecHost';
  host.style.cssText = 'all:initial;position:fixed;z-index:2147483647;top:0;right:0;';
  const root = host.attachShadow({mode: 'open'});
  root.innerHTML = `<style>
    *{box-sizing:border-box;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif}
    .fab{position:fixed;right:16px;bottom:16px;touch-action:none;width:52px;height:52px;border-radius:50%;border:0;background:#2563eb;color:#fff;font-size:24px;cursor:pointer;box-shadow:0 4px 14px rgba(0,0,0,.3)}
    .fab:hover{background:#1d4ed8}
    .panel{position:fixed;top:0;right:0;width:min(380px,100vw);height:100vh;background:#fff;color:#111827;border-left:1px solid #d1d5db;box-shadow:-6px 0 24px rgba(0,0,0,.18);display:none;flex-direction:column}
    .answerOverlay{position:fixed;pointer-events:none;box-sizing:border-box;border:2px solid #047857;border-radius:7px;background:#10b98126}
    .answerOverlay[data-truth]{border-radius:50%;background:#10b98138}
    .answerOverlay[data-truth="false"]{border-color:#be123c;background:#ef444438}
    .answerOverlay[hidden]{display:none}
    .panel.on{display:flex}
    .h{display:flex;align-items:center;justify-content:space-between;padding:12px 14px;border-bottom:1px solid #e5e7eb;font-weight:700;font-size:15px}
    .x{border:1px solid #d1d5db;background:#fff;border-radius:8px;width:30px;height:30px;cursor:pointer;font-size:14px}
    .b{padding:14px;overflow:auto;flex:1;font-size:14px;line-height:1.5}
    .go{width:100%;padding:12px;border:0;border-radius:10px;background:#2563eb;color:#fff;font-size:15px;font-weight:600;cursor:pointer}
    .providerRow{margin-bottom:12px}.providerRow label{display:block;font-size:12px;font-weight:650;color:#475569}.providerRow select{width:100%;padding:8px;margin:4px 0;border:1px solid #94a3b8;border-radius:8px;background:white;color:#0f172a}.providerRow a{font-size:12px;color:#1d4ed8}
    .go:disabled{opacity:.6;cursor:wait}
    .ans{margin-top:14px;border-radius:16px;overflow:hidden;background:#fff;box-shadow:0 6px 20px rgba(16,185,129,.18),0 0 0 1px rgba(16,185,129,.35)}
    .ans .top{display:flex;align-items:center;gap:8px;padding:9px 14px;background:linear-gradient(135deg,#10b981,#059669);color:#fff;font-size:12px;font-weight:700;letter-spacing:.06em;text-transform:uppercase}
    .ans .pick{display:flex;align-items:flex-start;gap:12px;padding:14px;background:linear-gradient(180deg,#ecfdf5,#fff);font-size:18px;font-weight:800;line-height:1.3;color:#064e3b}
    .ans .ck{flex:none;width:30px;height:30px;border-radius:50%;background:#10b981;color:#fff;display:flex;align-items:center;justify-content:center;font-size:17px;box-shadow:0 2px 6px rgba(16,185,129,.4)}
    .ans .why{margin:0 14px 14px;padding:10px 12px;border-radius:10px;background:#f8fafc;border:1px solid #e2e8f0;color:#334155;font-size:13.5px;line-height:1.55;white-space:pre-wrap}
    .ans .why i{display:block;font-style:normal;font-weight:700;font-size:11.5px;color:#64748b;text-transform:uppercase;letter-spacing:.05em;margin-bottom:4px}
    .why{white-space:pre-wrap;color:#374151;margin-top:10px}
    .upd .warn{margin:0 0 10px}
    .reading{margin:10px 0;padding:10px;border:1px solid #cbd5e1;border-radius:10px;background:#f8fafc;font-size:12.5px}.reading summary{cursor:pointer;font-weight:700}.readingText{white-space:pre-wrap;max-height:230px;overflow:auto;line-height:1.5;margin-top:8px}.readingStatus{color:#475569;margin-top:6px}.loc{margin-top:8px;font-size:12.5px;color:#475569}
    .auto{display:flex;align-items:center;gap:10px;margin-top:10px;font-size:13.5px;color:#334155;cursor:pointer;user-select:none}
    .auto input{display:none}
    .sw{position:relative;flex:none;width:40px;height:22px;border-radius:11px;background:#cbd5e1;transition:background .2s}
    .sw::after{content:'';position:absolute;left:3px;top:3px;width:16px;height:16px;border-radius:50%;background:#fff;box-shadow:0 1px 3px rgba(0,0,0,.3);transition:left .2s}
    .auto input:checked + .sw{background:#10b981} .auto input:checked + .sw::after{left:21px}
    .cd{position:fixed;left:50%;bottom:24px;transform:translateX(-50%);display:none;align-items:center;gap:12px;padding:10px 14px;border-radius:12px;background:#0f172a;color:#fff;font-size:14px;box-shadow:0 8px 24px rgba(0,0,0,.3)}
    .cd.on{display:flex} .cd button{border:0;border-radius:8px;padding:6px 12px;background:#fff;color:#0f172a;font-weight:700;cursor:pointer}
    .fab.auto::after{content:'A';position:absolute;right:-2px;top:-2px;width:18px;height:18px;border-radius:50%;background:#10b981;color:#fff;font:700 11px/18px system-ui,sans-serif;text-align:center;box-shadow:0 0 0 2px #fff}
    .chip{display:inline-flex;align-items:center;gap:6px;padding:4px 10px;border-radius:999px;border:1px solid #cbd5e1;background:#f8fafc;cursor:pointer;font-size:12.5px}
    .chip.on{background:#ecfdf5;border-color:#10b981;color:#065f46;font-weight:700}
    .ask{margin-top:8px;padding:10px 12px;border-radius:10px;background:#eff6ff;border:1px solid #93c5fd;color:#1e3a8a;line-height:1.45}
    .ask .row .sm:first-child{background:#2563eb;color:#fff;border:0;font-weight:700}
    .vf{padding:10px 14px;display:flex;flex-direction:column;gap:8px}
    .an{margin-top:12px;border:1px solid #e2e8f0;border-radius:10px;padding:8px 12px;background:#f8fafc;font-size:13px;color:#334155} .an summary{cursor:pointer;font-weight:700;color:#475569} .an div{margin-top:6px;white-space:pre-wrap;line-height:1.5}
    .vw{display:block;margin-top:2px;font-weight:400;font-size:12.5px;color:#475569}
    .mode{display:flex;gap:6px;margin-top:10px} .mode button{flex:1;padding:7px;border:1px solid #cbd5e1;background:#fff;border-radius:8px;cursor:pointer;font-size:12.5px} .mode button.on{background:#0f172a;color:#fff;border-color:#0f172a;font-weight:700}
    .mode button:disabled{opacity:.5;cursor:not-allowed}
    .fill{margin-top:14px;padding:12px;border:1px solid #cbd5e1;border-radius:12px;background:#f8fafc}
    .fillToggle{width:100%;padding:10px;border:1px solid #94a3b8;border-radius:8px;background:#fff;color:#334155;font-size:14px;font-weight:750;cursor:pointer}
    .fillToggle[aria-pressed=true]{background:#047857;color:#fff;border-color:#047857}
    .times{display:flex;gap:10px;margin-top:10px}.times label{flex:1;min-width:0;font-size:12px;color:#475569}.times input{display:block;width:100%;margin-top:4px;padding:8px;border:1px solid #94a3b8;border-radius:7px;font-size:14px;background:#fff;color:#111827}
    .fillStatus{margin-top:8px;font-size:12.5px;color:#475569;line-height:1.45}.fillStatus.error{color:#b91c1c}
    .fillCancel{margin-top:8px;padding:6px 10px;background:#fff;border:1px solid #94a3b8;border-radius:7px;color:#334155;cursor:pointer}
    .auto input{display:block;position:absolute;opacity:0;width:1px;height:1px}.auto:focus-within .sw{outline:2px solid #2563eb;outline-offset:3px}
    .vfr{display:flex;align-items:flex-start;gap:10px;font-size:14.5px;font-weight:600;color:#0f172a;line-height:1.35}
    .pill{flex:none;min-width:44px;text-align:center;padding:3px 8px;border-radius:999px;color:#fff;font-size:12.5px;font-weight:800}
    .pill.v{background:linear-gradient(135deg,#22c55e,#059669)} .pill.f{background:linear-gradient(135deg,#f87171,#dc2626)}
    .ans + .ans{margin-top:12px}
    .warn{margin-top:12px;padding:10px 12px;border-radius:10px;background:#fffbeb;border:1px solid #fcd34d;color:#78350f;font-size:13px;line-height:1.45;display:flex;flex-direction:column;gap:8px}
    .warn .sm{background:#f59e0b;color:#fff;border:0;font-weight:700}
    .note{margin-top:12px;font-size:12.5px;color:#6b7280}
    .err{margin-top:14px;border:1px solid #fca5a5;background:#fef2f2;border-radius:10px;padding:10px 12px;color:#991b1b}
    .row{display:flex;gap:8px;margin-top:10px}
    .sm{flex:1;padding:8px;border:1px solid #d1d5db;background:#fff;border-radius:8px;cursor:pointer;font-size:13px}
    .spin{display:inline-block;width:14px;height:14px;border:2px solid #fff;border-top-color:transparent;border-radius:50%;animation:s .8s linear infinite;vertical-align:-2px;margin-right:6px}
    @keyframes s{to{transform:rotate(360deg)}}
  </style>
  <button class="fab" title="Ayuda IA (Mi Estudio) · arrástrame si tapo algo">💡</button>
  <div class="cd"><span class="cdt"></span><button class="cdx">Cancelar</button></div>
  <div class="panel"><div class="h"><span>💡 Ayuda IA · Mi Estudio · v${extensionVersion}</span><button class="x" title="Cerrar">✕</button></div>
  <div class="b"><div class="upd"></div><div class="setupNotice" hidden><div class="warn"><span>Completa los permisos iniciales antes de comenzar.</span><button class="sm" data-setup>Preparar permisos</button></div></div><div class="providerRow"><label>API seleccionada<select class="providerSelect" aria-label="Proveedor de IA"></select></label><label class="geminiSlotRow" hidden>Clave de Gemini<select class="geminiSlot"><option value="primary">Principal</option><option value="secondary">Alternativa</option></select></label><a href="#" class="apiConfig">Configurar tokens y modelos</a><div class="providerStatus" role="status"></div></div><button class="go">🔍 Analizar la pregunta</button><div class="out"></div><details class="reading"><summary>Lectura del ejercicio</summary><div class="readingStatus" role="status">Pulsa Leer para comprobar el enunciado antes de consultar.</div><div class="readingText"></div><button type="button" class="sm" data-read>↻ Leer de nuevo · sin gastar API</button></details><div class="mode"><button data-m="precise" title="Usa un modelo más potente: tarda unos segundos más">🎯 Preciso</button><button data-m="fast" title="Modelo ligero: más rápido, se equivoca más">⚡ Rápido</button></div><label class="auto"><input type="checkbox" class="autoChk"><span class="sw"></span><span><b>Automático:</b> analizar cada vez que cambie el ejercicio</span></label>
  <div class="fill"><button type="button" class="fillToggle" aria-pressed="false">Autocompletar: OFF</button><div class="times"><label>Mínimo (segundos)<input class="fillMin" type="number" min="0" max="3600" step="0.1" value="7"></label><label>Máximo (segundos)<input class="fillMax" type="number" min="0" max="3600" step="0.1" value="15"></label></div><div class="fillStatus" role="status" aria-live="polite">Desactivado. Por defecto: entre 7 y 15 segundos.</div><button class="fillCancel" type="button" hidden>Cancelar esta respuesta</button></div>
  <label class="auto"><input type="checkbox" class="nextChk"><span class="sw"></span><span><b>Pasar solo:</b> cuando compruebes tu respuesta y salga «Correcte», ir a la siguiente</span></label><div class="loc"></div>
  <div class="note">Autocompletar usa el modo elegido, Preciso o Rápido, y hace clic en la opción de Electude; también rellena campos compatibles. El intervalo empieza al recibir esa respuesta; después pulsa tú «Comprovar». Los dibujos se señalan para que hagas clic tú. La IA puede equivocarse.</div><div class="fill"><button class="sm reportError" type="button" style="width:100%">🐞 La respuesta es errónea / Informar de un fallo</button><div class="reportStatus" role="status"></div></div><div class="note"><a href="#" class="diag">🛠 Copiar diagnóstico</a> (si algo no se marca bien, pégamelo)</div></div></div>`;
  const $ = s => root.querySelector(s);
  const panel = $('.panel'), fab = $('.fab'), go = $('.go'), out = $('.out');
  const open = v => {
    panel.classList.toggle('on',v);fab.style.display=v?'none':'';
    if(v&&lastFinal?.ctx.unmarked&&current(lastFinal.ctx)){
      lastFinal.ctx.unmarked=false;
      render(lastFinal.r,{...lastFinal.ctx,provisional:true});
    }
  };
  // botón movible (arrástralo si tapa algo de Electude); recuerda dónde lo dejas
  let drag = null, moved = false;
  const place = (x, y) => { x = Math.max(4, Math.min(innerWidth - 56, x)); y = Math.max(4, Math.min(innerHeight - 56, y)); fab.style.left = x + 'px'; fab.style.top = y + 'px'; fab.style.right = 'auto'; fab.style.bottom = 'auto'; return [x, y]; };
  try{ const p = JSON.parse(localStorage.getItem('__msElecFab') || 'null'); if(p) place(p[0], p[1]); else { fab.style.bottom = '90px'; } }catch(e){ fab.style.bottom = '90px'; }
  fab.addEventListener('pointerdown', e => { const r = fab.getBoundingClientRect(); drag = [e.clientX - r.left, e.clientY - r.top, e.clientX, e.clientY]; moved = false; fab.setPointerCapture(e.pointerId); });
  fab.addEventListener('pointermove', e => { if(!drag) return; if(Math.abs(e.clientX - drag[2]) + Math.abs(e.clientY - drag[3]) > 6) moved = true; if(moved) place(e.clientX - drag[0], e.clientY - drag[1]); });
  fab.addEventListener('pointerup', e => { if(drag && moved){ const r = fab.getBoundingClientRect(); try{ localStorage.setItem('__msElecFab', JSON.stringify([r.left, r.top])); }catch(_){} } drag = null; });
  fab.onclick = () => { if(moved){ moved = false; return; } open(true); };
  $('.x').onclick = () => { open(false); };
  const esc = s => String(s).replace(/[&<>"]/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;'}[c]));

  // documentos accesibles (la página y sus iframes del mismo origen)
  // documentos y zonas accesibles: la página, sus iframes del mismo origen y los «shadow DOM» abiertos
  let documentSnapshot=null;
  function docs(d = document, acc = []){
    const top=d===document&&acc.length===0;
    if(top&&documentSnapshot)return documentSnapshot;
    if(acc.includes(d))return acc;
    acc.push(d);
    const root = d.body || d;
    for(const el of root.querySelectorAll('*')){
      if(el.id === '__msElecHost' || el.id === '__msElecPins') continue;
      if(el.shadowRoot&&readable(el)) docs(el.shadowRoot, acc);
      if(el.tagName === 'IFRAME' || el.tagName === 'FRAME'){ try{ if(readable(el)&&el.contentDocument && el.contentDocument.body) docs(el.contentDocument, acc); }catch(e){} }
    }
    if(top){documentSnapshot=acc;queueMicrotask(()=>documentSnapshot=null);}
    return acc;
  }
  const rootOf = d => d.body || d;
  // ¿se ve de verdad en pantalla? (descarta los ejercicios anteriores que Electude deja escondidos o fuera del carrusel)
  function shown(el){
    if(!el || !el.getBoundingClientRect || !readable(el)) return false;
    const w = (el.ownerDocument && el.ownerDocument.defaultView) || window, r = el.getBoundingClientRect();
    if(r.width < 2 || r.height < 2 || r.bottom < 0 || r.right < 0 || r.top > w.innerHeight || r.left > w.innerWidth) return false;
    try{ if(el.checkVisibility && !el.checkVisibility({opacityProperty: true, visibilityProperty: true})) return false; }catch(e){}
    for(let n = el.parentElement, k = 0; n && k < 15; n = n.parentElement, k++){
      const cs = w.getComputedStyle(n);
      if(cs.overflow !== 'visible' || cs.overflowX !== 'visible' || cs.overflowY !== 'visible'){
        const p = n.getBoundingClientRect();
        if(r.right <= p.left + 1 || r.left >= p.right - 1 || r.bottom <= p.top + 1 || r.top >= p.bottom - 1) return false;
      }
    }
    return true;
  }
  // Incluye texto desplazado verticalmente, pero no paneles ocultos ni diapositivas laterales.
  function readable(el){
    if(!el || !el.getBoundingClientRect) return false;
    const win = el.ownerDocument.defaultView || window, r = el.getBoundingClientRect();
    if(r.width < 1 || r.height < 1 || r.right <= 0 || r.left >= win.innerWidth) return false;
    try{if(win.frameElement&&!readable(win.frameElement))return false;}catch{return false;}
    for(let n = el; n; n = n.parentElement || n.getRootNode?.().host){
      const css = win.getComputedStyle(n);
      if(n.hidden || n.getAttribute('aria-hidden') === 'true' || css.display === 'none' || css.visibility === 'hidden' || css.opacity !== '' && css.opacity !== undefined && Number(css.opacity) === 0) return false;
      if(n !== el && /hidden|clip|scroll|auto/.test(css.overflowX)){
        const clip = n.getBoundingClientRect(); if(r.right <= clip.left || r.left >= clip.right) return false;
      }
      if(n!==el&&/hidden|clip/.test(css.overflowY)){const clip=n.getBoundingClientRect();if(r.bottom<=clip.top||r.top>=clip.bottom)return false;}
    }
    return true;
  }
  function visibleText(scope, exclude, read = readable){
    const out = [], cache = new Map();
    const ok = el => { if(cache.has(el)) return cache.get(el); const v = read(el); cache.set(el, v); return v; };
    for(const d of scope ? [scope] : docs()){
      const root = scope || rootOf(d), doc = d.ownerDocument || d;
      const tw = doc.createTreeWalker(root, NodeFilter.SHOW_TEXT);
      let lastBlock = null, line = '';
      for(let n = tw.nextNode(); n; n = tw.nextNode()){
        const t = n.textContent.replace(/\s+/g, ' '); if(!t.trim()) continue;
        const p = n.parentElement; if(!p || (exclude && exclude.contains(p)) || /^(SCRIPT|STYLE|NOSCRIPT)$/.test(p.tagName) || (p.closest && p.closest('#__msElecHost,#__msElecPins,[data-ms-elec-mark]'))) continue;
        if(!ok(p)) continue;
        let b = p; while(b && b !== root && /^(inline|inline-block|contents)$/.test((doc.defaultView || window).getComputedStyle(b).display)) b = b.parentElement;
        if(b !== lastBlock){ if(line.trim()) out.push(line.trim()); line = ''; lastBlock = b; }
        line += t;
      }
      if(line.trim()) out.push(line.trim());
    }
    return out.join('\n');
  }
  function pageText(){
    let box = null; try{ box = activityBox(); }catch(e){}
    let t = ''; try{ t = visibleText(null, box); }catch(e){}
    if(!t && !box) t = docs().map(d => { try{ return d.body ? d.body.innerText : [...d.children].map(c => c.innerText || '').join('\n'); }catch(e){ return ''; } }).join('\n');
    t = t.replace(/✓ (Respuesta IA|Verdadero)|✗ Falso/g, '').replace(/\n{3,}/g, '\n\n').trim();
    const act = box ? visibleText(box) : '';
    if(act && act.length > 10){
      const theory = Core.lessonContext(t.trim(), act,6000).text;
      return ('--- ACTIVIDAD ACTIVA (opciones solo de este recuadro) ---\n' + act.slice(0, 4500) + '\n\n--- TEORÍA (evidencia; NO opciones de respuesta) ---\n' + theory.slice(0, 6000));
    }
    return t.slice(0, 9000);
  }
  const lessonMemory = new Map();
  function theoryContext(box){
    const heading = [...document.querySelectorAll('header,[role=banner],h1,[class*=module-title],[class*=lesson-title]')].find(el=>shown(el)&&!own(el)&&(!box||!box.contains(el)));
    const frameURLs=docs().map(d=>{try{return (d.location||d.ownerDocument?.location)?.href||'';}catch{return'';}}).join('|');
    const memoryKey = location.href + '|' + frameURLs + '|' + document.title + '|' + (heading?.textContent||'').trim().slice(0,200);
    let text = visibleText(null, box, el => readable(el) && !el.closest('nav,header,footer,button,[role=navigation],[role=status],[role=alert]'));
    // No se guardan las respuestas ni el feedback del recuadro activo.
    text = text.split('\n').filter(line => !Core.feedback(line) && !/^©|última modificaci|ultima modificaci/i.test(line)).join('\n');
    const old = lessonMemory.get(memoryKey) || [];
    for(const part of text.split('\n').map(t => t.trim()).filter(t => t.length > 25)) if(!old.includes(part)) old.push(part);
    while(old.join('\n').length > 35000) old.shift();
    lessonMemory.set(memoryKey, old);
    while(lessonMemory.size > 5) lessonMemory.delete(lessonMemory.keys().next().value);
    return old.join('\n');
  }
  function vfQuestion(box, rows){
    return Core.questionText(visibleText(box,null,el=>readable(el)&&!rows.some(row=>row.row===el||row.row.contains(el))&&!el.closest('button,input,select,textarea,[data-ms-elec-mark]'))).replace(/^(?:\d+\s+)+/, '').trim();
  }
  function renderReading(box=activityBox(),registry=registryFor(box),text=box?visibleText(box):''){
    const count=registry.choices.length+registry.vfs.length+registry.fields.length;
    $('.readingStatus').textContent=!box?'No se ha localizado un ejercicio activo. Abre la pregunta y pulsa Leer de nuevo.':registry.drawing?'Ejercicio de dibujo: necesita captura y clic manual.':count?registry.choices.length+' opciones · '+registry.vfs.length+' afirmaciones · '+registry.fields.length+' campos. Comprueba que están todos.':'El texto se ha leído, pero no se han identificado controles compatibles. La ayuda será manual.';
    $('.readingText').textContent=text.slice(0,14000);
    return {box,registry};
  }
  $('[data-read]').onclick=()=>{documentSnapshot=null;lessonMemory.clear();renderReading();};
  // marcas en la página
  function clearMarks(){clearAnswerOverlays();clearPins();}
  const norm = s => String(s).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/^[\s(]*([a-h]|\d{1,2})[).:\-]\s+/, '').replace(/[«»"'.,;:¿?¡!()]/g, '').replace(/\s+/g, ' ').trim();
  // fila de opción: un bloque con hermanos parecidos (lista de respuestas), mejor si tiene casilla/tick
  function optionRow(el){
    let n = el;
    for(let k = 0; k < 5 && n && n.parentElement && n.tagName !== 'BODY'; k++, n = n.parentElement){
      const p = n.parentElement, sib = [...p.children].filter(c => c !== n && c.tagName === n.tagName && (c.className || '') === (n.className || '') && (c.innerText || '').trim());
      if(sib.length >= 1 && (n.innerText || '').trim().length < 300) return n;
    }
    return null;
  }
  function mark(answer, registry){
    const match = Core.resolve(Core.reference(answer), registry.choices || []), target = match && match.row;
    if(!target || !target.isConnected || !curBox || !curBox.contains(target)) return false;
    return overlayAnswer(target);
  }
  function optionText(value){
    return String(value||'').normalize('NFKD').toLowerCase()
      .replace(/^[\s✓✔✗✕•☑☐○]+/u,'')
      .replace(/^(?:opci[oó]n?\s+)?(?:[a-h]|\d{1,2})[).:]\s+/i,'')
      .replace(/[\p{M}\p{P}\p{Cf}]/gu,'')
      .replace(/\s+/g,' ').trim();
  }
  function visibleChoiceRows(scope, answer, needsControl=false){
    const rows=new Map();
    const couldMatch=text=>text===answer||text.startsWith(answer+' ');
    for(const element of scope.querySelectorAll('label,li,td,button,span,div,p,a,option,text,tspan,[role=option],[role=radio],[role=checkbox]')){
      if(!couldMatch(optionText(element.textContent)))continue;
      if(!readable(element)||own(element)||element.closest('header,nav,footer,h1,h2,h3,h4,h5,h6,[role=heading]'))continue;
      const text=optionText(element.innerText||element.textContent);
      if(!text||text.length>350)continue;
      const row=optionRow(element);
      const rowText=row&&optionText(row.innerText||row.textContent);
      const target=row&&scope.contains(row)&&(rowText===text||rowText.endsWith(' '+text))?row:element;
      if(needsControl&&(!row||!scope.contains(row)||!shown(row)||rowIcons(row).length!==1))continue;
      const targetText=target===row?rowText:text;
      if(couldMatch(targetText))rows.set(target,targetText);
    }
    const candidates=[...rows].map(([element,text])=>({element,text}));
    return candidates.filter(({element,text})=>!candidates.some(other=>other.element!==element&&other.text===text&&other.element.contains(element)));
  }
  function chooseVisibleRow(rows, text){
    const exact=rows.filter(row=>row.text===text);
    if(exact.length)return exact.length===1?exact[0].element:false;
    // Una transcripción truncada puede conservar el inicio de una opción larga.
    if(text.split(' ').length<5)return null;
    const partial=rows.filter(row=>row.text.startsWith(text+' ')&&text.length>=row.text.length*.6);
    return partial.length===1?partial[0].element:partial.length?false:null;
  }
  // Use text ranges when a renderer splits an option into several independent nodes.
  function findChoiceRange(box, answer, requireQuestion=false){
    const doc=box.ownerDocument;
    if(!doc?.createTreeWalker||!doc.createRange)return null;
    const walker=doc.createTreeWalker(box,NodeFilter.SHOW_TEXT);
    const words=[],locations=[];
    let afterQuestion=false;
    for(let node=walker.nextNode();node;node=walker.nextNode()){
      const parent=node.parentElement;
      if(!parent||own(parent)||parent.closest('script,style,noscript')||!readable(parent))continue;
      for(const match of node.textContent.matchAll(/\S+/g)){
        const word=optionText(match[0]);
        if(word){
          words.push(word);
          locations.push({node,start:match.index,end:match.index+match[0].length,afterQuestion});
        }
        if(match[0].includes('?'))afterQuestion=true;
      }
    }
    const wanted=answer.split(' ');
    let found=-1;
    for(let i=0;i<=words.length-wanted.length;i++){
      if((requireQuestion&&!locations[i].afterQuestion)||!wanted.every((word,index)=>words[i+index]===word))continue;
      if(found>=0)return null;
      found=i;
    }
    if(found<0)return null;
    const first=locations[found],last=locations[found+wanted.length-1];
    const range=doc.createRange();
    range.setStart(first.node,first.start);
    range.setEnd(last.node,last.end);
    const rects=[...range.getClientRects()].filter(rect=>rect.width>0&&rect.height>0);
    const top=rects[0]?.top,bottom=rects.at(-1)?.bottom;
    // Reject joins across separate options or distant columns.
    if(!rects.length||bottom-top>150||rects.some(rect=>Math.abs(rect.left-rects[0].left)>900))return null;
    return {ownerDocument:doc,get isConnected(){return first.node.isConnected&&last.node.isConnected;},getBoundingClientRect:()=>range.getBoundingClientRect()};
  }
  function markVisibleChoice(answer, box, manualQuiz){
    const text=optionText(answer);
    if(!text)return false;
    if(box){
      const target=chooseVisibleRow(visibleChoiceRows(box,text),text);
      if(target===false)return false;
      const match=target||findChoiceRange(box,text);
      if(match&&overlayAnswer(match))return true;
    }
    if(!manualQuiz||text.length<8)return false;
    // El recuadro detectado puede contener solo el botón de comprobación.
    // Fuera de él, preferimos las filas repetidas con un control visible.
    const scopes=docs().map(rootOf);
    const row=chooseVisibleRow(scopes.flatMap(scope=>visibleChoiceRows(scope,text,true)),text);
    if(row!==null)return Boolean(row)&&overlayAnswer(row);
    const targets=scopes.map(scope=>findChoiceRange(scope,text,true)).filter(Boolean);
    return targets.length===1&&overlayAnswer(targets[0]);
  }
  const answerOverlays=[];
  function clearAnswerOverlays(){
    for(const {node,refresh,source} of answerOverlays){
      node.remove();window.removeEventListener('resize',refresh);window.removeEventListener('scroll',refresh,true);
      if(source&&source!==window)source.removeEventListener('scroll',refresh,true);
    }
    answerOverlays.length=0;
  }
  function overlayAnswer(target, truth){
    const rect=topRect(target);
    if(!rect||rect.width<=0||rect.height<=0)return false;
    const node=document.createElement('div');
    node.className='answerOverlay';node.setAttribute('aria-hidden','true');
    if(typeof truth==='boolean')node.setAttribute('data-truth',String(truth));
    root.prepend(node);
    const source=target.ownerDocument.defaultView;
    function refresh(){
      const r=target.isConnected?topRect(target):null;
      node.hidden=!r||r.width<=0||r.height<=0||r.left+r.width<=0||r.top+r.height<=0||r.left>=innerWidth||r.top>=innerHeight;
      if(node.hidden)return;
      const padX=typeof truth==='boolean'?2:4, padY=typeof truth==='boolean'?2:3;
      const left=Math.max(2,r.left-padX),right=Math.min(innerWidth-2,r.left+r.width+padX);
      const top=Math.max(2,r.top-padY),bottom=Math.min(innerHeight-2,r.top+r.height+padY);
      Object.assign(node.style,{left:left+'px',top:top+'px',width:Math.max(0,right-left)+'px',height:Math.max(0,bottom-top)+'px'});
    }
    answerOverlays.push({node,refresh,source});
    window.addEventListener('resize',refresh);window.addEventListener('scroll',refresh,true);
    if(source&&source!==window)source.addEventListener('scroll',refresh,true);
    refresh();
    return true;
  }
  function markVF(answer, isTrue, registry){
    const match=Core.resolve(Core.reference(answer),registry.vfs || []);
    if(!match?.row.isConnected||!curBox?.contains(match.row))return false;
    const control=isTrue?match.yes:match.no;
    if(!control)return false;
    const label=[...(control.labels || [])].find(el=>match.row.contains(el)&&readable(el));
    const target=readable(control)?control:label;
    return Boolean(target)&&overlayAnswer(target,isTrue);
  }
  // La posición de una sugerencia leída de la captura solo sirve para esa vista.
  let capturedViewVersion=0;
  function invalidateCapturedView(){
    capturedViewVersion++;
    for(const {refresh} of answerOverlays)refresh();
  }
  window.addEventListener('resize',invalidateCapturedView);
  window.addEventListener('scroll',invalidateCapturedView,true);
  function screenshotChoice(text, ctx){
    const view=ctx.choiceView;
    if(!ctx.shot?.dataUrl||!view||view.version!==capturedViewVersion)return false;
    const rect=Visual.choiceBox(text,ctx.viewport);
    if(!rect)return false;
    const surface=view.surfaces.find(({el,rect:bounds})=>el.isConnected&&Visual.sameRect(bounds,topRect(el))&&
      rect.left>=bounds.left-5&&rect.top>=bounds.top-5&&rect.left+rect.width<=bounds.left+bounds.width+5&&rect.top+rect.height<=bounds.top+bounds.height+5);
    if(!surface)return false;
    return overlayAnswer({ownerDocument:document,get isConnected(){return view.version===capturedViewVersion&&surface.el.isConnected&&Visual.sameRect(surface.rect,topRect(surface.el));},getBoundingClientRect:()=>rect});
  }
  // Puntos detectados en la captura; el modelo elige IDs, nunca destinos arbitrarios.
  let pinHost = null, pinRefresh = null;
  function clearPins(){
    if(pinHost) pinHost.remove(); pinHost = null;
    if(pinRefresh){ window.removeEventListener('resize', pinRefresh); window.removeEventListener('scroll', pinRefresh, true); pinRefresh = null; }
  }
  function topRect(el){
    let rect = el.getBoundingClientRect(), win = el.ownerDocument.defaultView;
    rect = {left: rect.left, top: rect.top, width: rect.width, height: rect.height};
    while(win && win !== window){
      const frame = win.frameElement; if(!frame) return null;
      const f = frame.getBoundingClientRect(), sx = f.width / frame.offsetWidth, sy = f.height / frame.offsetHeight;
      rect = Visual.frameRect(rect, {left: f.left + frame.clientLeft * sx, top: f.top + frame.clientTop * sy, width: frame.clientWidth * sx, height: frame.clientHeight * sy}, {width: win.innerWidth, height: win.innerHeight});
      win = frame.ownerDocument.defaultView;
    }
    return rect;
  }
  function collectDrawing(){
    const regions = [], hotspots = [], viewport = {width: innerWidth, height: innerHeight};
    const box = activityBox();
    for(const d of docs()) for(const el of rootOf(d).querySelectorAll('img,svg,canvas,[role=img],[class*=illustration],[class*=drawing],[class*=diagram]')){
      if(own(el) || !shown(el) || box && box.contains(el)) continue;
      const rect = topRect(el); if(!rect || rect.width < 120 || rect.height < 100) continue;
      if(rect.left >= innerWidth || rect.top >= innerHeight || rect.left + rect.width <= 0 || rect.top + rect.height <= 0) continue;
      regions.push({el, rect, x: rect.left / innerWidth * 1000, y: rect.top / innerHeight * 1000, width: rect.width / innerWidth * 1000, height: rect.height / innerHeight * 1000});
    }
    for(const d of docs()) for(const el of rootOf(d).querySelectorAll('circle,[class*=hotspot],[class*=point],[class*=dot],[class*=marker],[data-hotspot],[role=button]')){
      if(own(el) || !shown(el) || box && box.contains(el)) continue;
      const rect = topRect(el); if(!rect || rect.width < 3 || rect.height < 3 || rect.width > 60 || rect.height > 60) continue;
      const css = el.ownerDocument.defaultView.getComputedStyle(el);
      const hint = String(el.className && el.className.baseVal || el.className || '');
      if(!/hotspot|clicktarget|clickpoint/i.test(hint) && !el.hasAttribute('data-hotspot') && !el.hasAttribute('onclick') && el.getAttribute('role') !== 'button' && el.tabIndex < 0) continue;
      const point = {x: (rect.left + rect.width / 2) / innerWidth * 1000, y: (rect.top + rect.height / 2) / innerHeight * 1000};
      if(!regions.some(r => Visual.inside(point, r))) continue;
      hotspots.push({...point, el, label: el.getAttribute('aria-label') || el.getAttribute('title') || el.getAttribute('data-label') || ''});
    }
    return {regions, hotspots, viewport};
  }
  function bindHotspotAnchors(points, drawing){
    return points.map(point => {
      const dom = drawing.hotspots.find(h => Math.hypot((h.x - point.x) * drawing.viewport.width / 1000, (h.y - point.y) * drawing.viewport.height / 1000) < 10);
      if(dom) return {...point, el: dom.el};
      const region = drawing.regions.filter(r => Visual.inside(point, r)).sort((a, b) => a.width * a.height - b.width * b.height)[0];
      return {...point, region: region && region.el, anchor: region && Visual.anchor(point, region.rect, drawing.viewport)};
    });
  }
  function drawPins(points, ctx){
    clearPins();
    const result = Visual.bindPoints(points, ctx.hotspots || [], ctx.viewport);
    if(!result.mapped.length) return result;
    pinHost = document.createElement('div'); pinHost.id = '__msElecPins';
    pinHost.style.cssText = 'all:initial;position:fixed;left:0;top:0;width:0;height:0;z-index:2147483646;pointer-events:none';
    const sr = pinHost.attachShadow({mode: 'open'});
    sr.innerHTML = '<style>.pin{position:absolute;transform:translate(-50%,-50%);width:24px;height:24px;border-radius:50%;background:#047857;border:2px solid white;box-shadow:0 0 0 1px #047857;color:white;text-align:center;font:800 14px/20px system-ui,sans-serif;pointer-events:none}</style>';
    const pins = result.mapped.map(point => {
      const node = document.createElement('span'); node.className = 'pin'; node.textContent = String(point.number); sr.appendChild(node); return {point, node};
    });
    pinRefresh = () => {
      for(const {point, node} of pins){
        const target = point.target; let position = null;
        if(target.el && target.el.isConnected && shown(target.el)){
          const r = topRect(target.el); if(r) position = {x: r.left + r.width / 2, y: r.top + r.height / 2};
        }else if(target.region && target.region.isConnected && shown(target.region)){
          const r = topRect(target.region); if(r) position = Visual.position(target.anchor, r);
        }
        node.hidden = !position;
        if(position){ node.style.left = position.x + 'px'; node.style.top = position.y + 'px'; }
      }
    };
    document.documentElement.appendChild(pinHost); pinRefresh();
    window.addEventListener('resize', pinRefresh); window.addEventListener('scroll', pinRefresh, true);
    return result;
  }
  const send = m => new Promise(res => {
    let settled = false;
    const done = result => { if(settled) return; settled = true; clearTimeout(timeout); res(result); };
    const timeout = setTimeout(() => done({error: 'La extensión ha tardado demasiado. Vuelve a analizar la pregunta.'}), m.type === 'elecAsk' ? 65000 : m.type === 'localAsk' ? 200000 : 20000);
    try{
      if(typeof browser !== 'undefined' && browser.runtime){ Promise.resolve(api.runtime.sendMessage(m)).then(done, e => done({error: e.message})); }
      else { const p = api.runtime.sendMessage(m, result => { const error = api.runtime.lastError; done(error ? {error: error.message} : result); }); if(p && p.then) p.then(done, e => done({error: e.message})); }
    }catch(e){ done({error: e.message}); }
  });
  $('[data-setup]').onclick=()=>send({type:'openSetup'});
  async function requirePermissions(interactive=false){
    const state=await send({type:'getSetupStatus'});permissionReady=state?.ready===true;
    $('.setupNotice').hidden=permissionReady;
    if(!permissionReady){fillStatus(state?.error||'Completa los permisos iniciales antes de comenzar.',true);if(interactive)await send({type:'openSetup'});}
    return permissionReady;
  }
  send({type:'getSetupStatus'}).then(state=>{permissionReady=state?.ready===true;$('.setupNotice').hidden=permissionReady;});
  let apiSettings = null;
  async function renderProviders(settings){
    apiSettings = settings && settings.available ? settings : await send({type: 'getAISettings'});
    if(!apiSettings || !apiSettings.available) return;
    $('.providerSelect').innerHTML = Object.entries(Providers.NAMES).map(([value, name]) => `<option value="${value}" ${apiSettings.available[value] ? '' : 'disabled'}>${esc(name)}${apiSettings.available[value] ? '' : ' · sin token'}</option>`).join('');
    $('.providerSelect').value = apiSettings.provider;
    $('.geminiSlotRow').hidden = apiSettings.provider !== 'gemini';
    $('.geminiSlot').value = apiSettings.geminiSlot;
    $('.geminiSlot option[value=primary]').disabled = !apiSettings.primary;
    $('.geminiSlot option[value=secondary]').disabled = !apiSettings.secondary;
  }
  async function changeProvider(){
    const result = await send({type: 'setAIProvider', provider: $('.providerSelect').value, geminiSlot: $('.geminiSlot').value});
    $('.providerStatus').textContent = result && result.error || 'API seleccionada. Se usará en el próximo análisis.';
    await renderProviders(result);
  }
  $('.providerSelect').onchange = changeProvider; $('.geminiSlot').onchange = changeProvider;
  $('.apiConfig').onclick = event => { event.preventDefault(); send({type: 'openApp'}); };
  api.storage.onChanged.addListener((changes, area) => { if(area === 'local' && changes.ai) renderProviders(); });
  renderProviders();
  // ---------- IA local: sesión en una página propia de la extensión ----------
  let localOn = false, localState = {status: 'closed'};
  const loc = $('.loc');
  async function renderLocal(message){
    const status = await send({type:'localStatus'}); localState=status || {status:'closed'};
    const ready=localState.status==='ready', engine=localState.engine==='chrome'?'Gemini Nano':'Ollama';
    const state=ready?(localOn?(mode==='fast'?'en uso · Rápido':'preparada · Preciso usa API'):'lista · desactivada'):'sin preparar';
    loc.innerHTML=`<span class="chip ${localOn&&ready?'on':''}">⚡ IA local: ${esc(engine)} · ${state}</span><div class="note">${message?esc(message)+'<br>':''}${localState.error?esc(localState.error)+'<br>':''}${localOn?'Rápido usa tu ordenador, también con Autocompletar. Preciso usa tu API.':'Configura el modelo, pruébalo y pulsa Usar en Electude.'}</div><div class="row"><button class="sm" data-local-open>Configurar / descargar IA local</button>${localOn?'<button class="sm" data-local-off>Usar API</button>':ready?'<button class="sm" data-local-use>Usar local · Rápido</button>':''}</div>`;
    loc.querySelector('[data-local-open]').onclick=async()=>{const result=await send({type:'openLocalAI'});if(result?.error)renderLocal(result.error);};
    const off=loc.querySelector('[data-local-off]');if(off)off.onclick=()=>{localOn=false;cancelAnalysis();cancelFill('local');lastFinal=null;lastSig='';api.storage.local.set({localAI:false});renderLocal();scheduleAuto(100);};
    const use=loc.querySelector('[data-local-use]');if(use)use.onclick=()=>{localOn=true;api.storage.local.set({localAI:true});setMode('fast',true);renderLocal();};
  }
  api.storage.local.get('localAI').then(r=>{localOn=r.localAI===true;renderLocal();});
  api.storage.onChanged.addListener((changes,area)=>{
    if(area!=='local')return;
    if(changes.localAI)localOn=changes.localAI.newValue===true;
    if(changes.elecMode && changes.elecMode.newValue!==mode)setMode(changes.elecMode.newValue,true);
    if(changes.localEngine||changes.ollamaModel||changes.localAI){cancelAnalysis();cancelFill('local');lastFinal=null;lastSig='';scheduleAuto(300);}
    if(changes.localAI||changes.localAIStatus||changes.localEngine||changes.ollamaModel)renderLocal();
  });
  // filas con dos botones (✗ y ✓): son preguntas de «cert o fals» para CADA fila, puede haber varias correctas
  const isIconish = el => { if(!el.getBoundingClientRect) return false; const r = el.getBoundingClientRect(); return r.width >= 10 && r.height >= 10 && r.width <= 50 && r.height <= 50 && Math.abs(r.width - r.height) < 14 && (el.innerText || el.textContent || '').trim().length <= 2; };
  function rowIcons(row){
    const all = [...row.querySelectorAll('*')].filter(x => isIconish(x) && readable(x));
    const top = all.filter(x => !all.some(y => y !== x && y.contains(x)));
    // solo los que están a la izquierda del texto (o en línea con él)
    return top.sort((a, b) => a.getBoundingClientRect().left - b.getBoundingClientRect().left);
  }
  function vfRows(){ return vfRowEls().map(cleanT); }
  function vfRowEls(){
    const rows = new Set();
    // Parejas de radios etiquetados: sus etiquetas pueden ser más anchas que un icono.
    for(const d of docs()){
      const groups = new Map();
      for(const el of rootOf(d).querySelectorAll('input[type=radio]')){
        if(!el.name || own(el) || (!readable(el) && ![...(el.labels || [])].some(readable))) continue;
        if(!groups.has(el.name)) groups.set(el.name, []); groups.get(el.name).push(el);
      }
      for(const controls of groups.values()){
        if(controls.length !== 2 || !controls.some(el => truthValue(el) === true) || !controls.some(el => truthValue(el) === false)) continue;
        let row = controls[0].parentElement;
        while(row && !row.contains(controls[1])) row = row.parentElement;
        if(row && !/^(BODY|HTML)$/.test(row.tagName) && (row.innerText || '').length < 350) rows.add(row);
      }
    }
    for(const d of docs()) for(const ic of rootOf(d).querySelectorAll('*')){
      if(!isIconish(ic) || !readable(ic) || (ic.closest && ic.closest('#__msElecHost,#__msElecPins'))) continue;
      const row = optionRow(ic); if(!row || rows.has(row)) continue;
      const t = (row.innerText || '').trim();
      if(rowIcons(row).length === 2 && t.length >= 2 && t.length < 300 && !/^\d+(?:\s+\d+)*$/.test(t) && readable(row)) rows.add(row);
    }
    return [...rows].filter(r => ![...rows].some(o => o !== r && r.contains(o))).sort((a,b) => { const ar = topRect(a), br = topRect(b); return ar.top - br.top || ar.left - br.left; });
  }
  const cleanT = el => {
    const copy = el.cloneNode(true); copy.querySelectorAll('[data-ms-elec-mark]').forEach(n => n.remove());
    return (copy.textContent || '').replace(/\s+/g, ' ').trim();
  };
  // Los cuestionarios pueden corregir al escribir, sin botón Comprovar.
  function fieldActivityBox(){
    const candidates = [];
    for(const d of docs()) for(const field of rootOf(d).querySelectorAll('input,select,textarea,[role=radio],[role=checkbox]')){
      if(own(field) || (!readable(field) && ![...(field.labels || [])].some(readable))) continue;
      if(field.tagName === 'INPUT' && !['text', 'number', 'tel', 'radio', 'checkbox'].includes(field.type)) continue;
      for(let n = field.parentElement, level = 0; n && level < 7; n = n.parentElement, level++){
        if(/^(BODY|HTML)$/.test(n.tagName)) break;
        const text = rowText(n), rect = n.getBoundingClientRect();
        const question = /\?|(?:^|\s)(?:quin|quina|quins|quines|que|qué|qual|cual|cuál|escriu|escribe|indica|calcula|selecciona|marca|which|what|enter)\b/i.test(text);
        if(text.length < 12 || text.length > 4500 || rect.height < 60 || rect.width < 160 || !question) continue;
        candidates.push({el: n, area: rect.width * rect.height}); break;
      }
    }
    candidates.sort((a, b) => a.area - b.area);
    return candidates.length ? candidates[0].el : null;
  }
  // El recuadro activo; la figura y sus números quedan fuera de este ámbito.
  function activityBox(){
    const rows = vfRowEls();
    const btns = [];
    for(const d of docs()) for(const b of rootOf(d).querySelectorAll('button,a,[role=button],input[type=button],input[type=submit],div,span')){
      if(b.closest && b.closest('#__msElecHost')) continue;
      const t = (b.innerText || b.value || '').trim();
      const normal = /^(comprovar|comprobar|check|corregir|enviar|validar|submit)$/i.test(t);
      const confirm = /^(?:ok|d['’]acord)$/i.test(t);
      if((normal || confirm) && b.children.length <= 2 && shown(b)) btns.push({button:b,confirm,normal});
    }
    const seeds = [...btns, ...rows.filter(shown).slice(0,1).concat(rows.slice(0,1)).map(button=>({button,confirm:false}))];
    for(const {button:s,confirm,normal} of seeds){
      for(let n = s.parentElement, k = 0; n && k < 8; n = n.parentElement || (n.getRootNode && n.getRootNode().host), k++){
        const t = (n.innerText || '').trim();
        const hasAnswers = n.querySelector('input:not([type=button]):not([type=submit]):not([type=hidden]),select,textarea,[role=radio],[role=checkbox]') || rows.some(r => n.contains(r)) || [...n.querySelectorAll('*')].some(el => isIconish(el) && shown(el));
        const grouped = !rows.length || rows.filter(r => r.ownerDocument === s.ownerDocument && shown(r)).every(r => n.contains(r));
        const hasQuestion = !rows.length || vfQuestion(n, rows.filter(r=>n.contains(r)).map(row=>({row}))).length >= 12;
        // El botón «Ok» también existe en avisos; exige pregunta y texto de respuesta cerca.
        if(confirm || (normal && !hasAnswers && k<=4)){
          if(/^(BODY|HTML)$/.test(n.tagName)||k>4)break;
          const quiz=Core.visibleQuiz(visibleText(n));
          const lines=quiz.split('\n');
          if(quiz.length>32 && quiz.length<=3600 && (lines.length>=2 || /\?\s+\S.{8}/.test(quiz)) && shown(n))return n;
          continue;
        }
        if(grouped && hasQuestion && t.length > 20 && hasAnswers && n.getBoundingClientRect().height > 60 && !/^(BODY|HTML)$/.test(n.tagName)) return n;
      }
    }
    const fieldBox = fieldActivityBox(); if(fieldBox) return fieldBox;
    if(rows.length >= 2){ let n = rows[0].parentElement; while(n && !rows.every(r => n.contains(r))) n = n.parentElement; if(n && !/^(BODY|HTML)$/.test(n.tagName)) return n; }
    for(const d of docs()) for(const list of rootOf(d).querySelectorAll('ul,ol')){
      if(own(list) || !shown(list)) continue;
      for(let n = list.parentElement, k = 0; n && k < 4 && !/^(BODY|HTML)$/.test(n.tagName); n = n.parentElement, k++){
        const text = visibleText(n), r = n.getBoundingClientRect();
        if(text.length <= 4500 && r.width >= 160 && r.height >= 100 && /(?:localitza|localiza|localice|locate|identifica).{0,80}(?:components|componentes|parts|peces|piezas)/i.test(text)) return n;
      }
    }
    return null;
  }
  // Referencias a controles reales: la IA elige IDs y nunca selectores ni código.
  const own = el => !!(el && el.closest && el.closest('#__msElecHost,#__msElecPins,[data-ms-elec-mark]'));
  const rowText = el => visibleText(el).replace(/\s+/g, ' ').trim();
  const controlHint = el => ['aria-label', 'title', 'alt', 'class', 'data-value', 'value'].map(a => el.getAttribute(a) || '').join(' ').toLowerCase() + ' ' + (el.textContent || '').trim();
  function truthValue(el){
    const values = ['data-value', 'value', 'aria-label', 'title', 'alt'].map(a => el.getAttribute(a) || '').concat([...(el.labels || [])].map(l => (l.innerText || '').trim()));
    for(const value of values){ const truth = Core.truthLabel(value); if(truth !== null) return truth; }
    return null;
  }
  function vfControlRoot(el, row){
    const candidate = el.closest('button,input,[role=radio],[role=checkbox],[role=button],[onclick]');
    if(candidate && candidate !== row && row.contains(candidate)) return candidate;
    let result = el;
    for(let n = el.parentElement; n && n !== row; n = n.parentElement){
      const r = n.getBoundingClientRect();
      if(r.width > 50 || r.height > 50 || Math.abs(r.width-r.height) >= 14) break;
      if(r.width >= 10 && r.height >= 10) result = n;
    }
    return result;
  }
  function vfControls(row){
    const native = [...row.querySelectorAll('input[type=radio]')];
    const icons = native.length === 2 ? native : [...new Set(rowIcons(row).map(el => vfControlRoot(el, row)))];
    if(icons.length !== 2) return null;
    const items = icons.map(el => {
      let value = truthValue(el);
      if(value === null){
        const labels = [el.textContent || '', ...[...el.querySelectorAll('img,use')].map(n => n.getAttribute('alt') || n.getAttribute('src') || n.getAttribute('href') || n.getAttribute('xlink:href') || '')];
        for(const label of labels){ const explicit = Core.truthLabel(label); if(explicit !== null){ value = explicit; break; }
          const hint = label.split(/[\/#._-]+/); const no = hint.some(w => /^(false|cross|wrong|cancel|close)$/.test(w)), yes = hint.some(w => /^(true|tick|check)$/.test(w));
          if(no !== yes){ value = yes; break; }
        }
      }
      return {el,value};
    });
    return Core.truthPair(items);
  }
  function statementText(row, controls){
    const originals = [row, ...row.querySelectorAll('*')], copy = row.cloneNode(true), clones = [copy, ...copy.querySelectorAll('*')];
    const remove = new Set();
    for(const control of [controls.no,controls.yes].filter(Boolean)){
      remove.add(control);
      for(const label of control.labels || []) if(row.contains(label) && Core.truthLabel(label.textContent) !== null) remove.add(label);
    }
    for(const node of remove){ const i = originals.indexOf(node); if(i > 0) clones[i]?.remove(); }
    copy.querySelectorAll('input,button,svg,img,[role=radio],[role=checkbox],[data-ms-elec-mark]').forEach(el => el.remove());
    return (copy.textContent || '').replace(/^[\s✗✕✖×✓✔]+/, '').replace(/\s+/g, ' ').trim();
  }
  function vfSelection(target){
    if(!target) return null;
    const state = el => { if(!el)return null; if('checked' in el)return el.checked; const flag=el.getAttribute('aria-checked')??el.getAttribute('aria-pressed')??el.getAttribute('aria-selected')??el.getAttribute('data-selected'); if(flag!==null)return flag==='true'||flag==='1'; return /\b(selected|checked)\b/.test(el.getAttribute('class')||'')?true:null; };
    const yes = state(target.yes), no = state(target.no);
    if(yes === true && no !== true) return true;
    if(no === true && yes !== true) return false;
    return null;
  }
  function labelFor(el){
    const labels = [...(el.labels || [])].map(rowText).filter(Boolean);
    if(labels.length) return labels.join(' ');
    const ids = (el.getAttribute('aria-labelledby') || '').split(/\s+/).filter(Boolean);
    const labelled = ids.map(id => { const n = el.getRootNode().getElementById(id); return n ? rowText(n) : ''; }).filter(Boolean).join(' ');
    if(labelled) return labelled;
    const named = el.getAttribute('aria-label') || el.getAttribute('placeholder'); if(named) return named;
    const row = el.closest('label,li,tr,[role=option]') || optionRow(el) || el.parentElement;
    const text = row ? rowText(row) : '';
    return text.length < 350 ? text : '';
  }
  function registryFor(box){
    const registry = {choices: [], vfs: [], fields: []}; if(!box) return registry;
    if(/(?:localitza|localiza|localice|locate).{0,80}(?:components|componentes|parts|peces|piezas)/i.test(visibleText(box))){ registry.drawing = true; return registry; }
    const vfEls = vfRowEls().filter(r => box.contains(r));
    for(const row of vfEls){
      const controls = vfControls(row), text = controls && statementText(row, controls);
      if(controls && text) registry.vfs.push({id: 'V' + (registry.vfs.length + 1), text, row, ...controls});
    }
    const inVF = el => registry.vfs.some(v => v.row.contains(el));
    const seen = new Set(), groups = new Map();
    const groupId = key => { if(!groups.has(key)) groups.set(key, 'G' + (groups.size + 1)); return groups.get(key); };
    for(const el of box.querySelectorAll('input[type=radio],input[type=checkbox],[role=radio],[role=checkbox]')){
      if(own(el) || inVF(el)) continue;
      const label = [...(el.labels || [])].find(readable), row = label || el.closest('label,li,tr') || optionRow(el) || el;
      if(!readable(el) && !readable(row)) continue;
      const text = labelFor(el); if(!text) continue;
      const kind = el.type === 'checkbox' || el.getAttribute('role') === 'checkbox' ? 'checkbox' : 'radio';
      const group = el.name ? kind + ':' + el.name : el.closest('[role=radiogroup]') || kind;
      registry.choices.push({id: 'O' + (registry.choices.length + 1), text, kind, group: groupId(group), el, click: readable(el) ? el : row, row});
      seen.add(row);
    }
    // Controles dibujados por Electude: una fila repetida con un único círculo/casilla.
    for(const el of box.querySelectorAll('*')){
      if(!isIconish(el) || !readable(el) || own(el) || inVF(el)) continue;
      const row = optionRow(el);
      if(!row || !box.contains(row) || seen.has(row) || row.querySelector('input,select,textarea,[role=radio],[role=checkbox]')) continue;
      const icons = rowIcons(row), text = rowText(row);
      if(icons.length !== 1 || !text || text.length > 350 || /^\d+$/.test(text)) continue;
      const icon = icons[0], ancestor = icon.closest('button,[role=button],[onclick]'), clickable = ancestor && row.contains(ancestor) ? ancestor : icon;
      if(clickable.form && clickable.type === 'submit') continue;
      const kind = /checkbox|multi/i.test(controlHint(icon)) ? 'checkbox' : 'radio';
      registry.choices.push({id: 'O' + (registry.choices.length + 1), text, kind, group: groupId('custom'), el: icon, click: clickable, row}); seen.add(row);
    }
    for(const el of box.querySelectorAll('input,textarea,select')){
      if(own(el) || inVF(el) || !readable(el)) continue;
      if(el.tagName === 'INPUT' && !['text', 'number', 'tel'].includes(el.type)) continue;
      const field = {id: 'C' + (registry.fields.length + 1), text: labelFor(el) || 'Campo ' + (registry.fields.length + 1), type: el.tagName === 'SELECT' ? 'select' : el.type || 'text', el};
      field.editable = !el.disabled && !el.readOnly && !el.closest('fieldset[disabled]');
      field.numericReference = Core.needsVision(rowText(box)) && /\b(numero|number)\b/.test(Core.normalize(rowText(box)));
      if(el.tagName === 'SELECT') field.options = [...el.options].filter(o => !o.disabled && !o.parentElement.disabled && o.value !== '').map(o => ({value: o.value, text: o.textContent.trim()}));
      registry.fields.push(field);
    }
    return registry;
  }
  function registryPrompt(registry){
    const printable = list => list.map(({id, text, kind, group, type, options, numericReference, editable, binding}) => ({id, text, kind, group, type, options, numericReference, editable, binding}));
    return '--- CONTROLES DE LA ACTIVIDAD ACTIVA (referencias exactas) ---\n' + JSON.stringify({opciones: printable(registry.choices), verdaderoFalso: printable(registry.vfs), campos: printable(registry.fields)}) + '\nUsa RESPUESTA: [O1] para elegir; VF: [V1] => V o F para CADA afirmación; CAMPO: C1 => valor para CADA campo. No inventes IDs. Si no hay controles identificados, usa el formato de ayuda manual.\n\n';
  }
  function activityFeedback(box){
    if(!box) return '';
    const rows = vfRowEls().filter(row => box.contains(row));
    if(!rows.length) return Core.feedback(visibleText(box));
    return Core.feedback(visibleText(box,null,el=>readable(el)&&!rows.some(row=>row===el||row.contains(el))));
  }
  function activityCompleted(box, registry){
    const controls = [...registry.choices.map(choice => choice.el), ...registry.fields.map(field => field.el), ...registry.vfs.flatMap(row => [row.yes, row.no])].filter(Boolean);
    return Core.completed({
      feedback: activityFeedback(box),
      locked: controls.length > 0 && controls.every(el => el.disabled || el.readOnly || el.getAttribute('aria-disabled') === 'true'),
      choices: registry.choices.map(choice => ({group: choice.group, selected: selected(choice.el) === true})),
      vfs: registry.vfs.map(row => ({answered: vfSelection(row) !== null})),
      fields: registry.fields.map(field => ({value: field.el.value}))
    });
  }
  let fillSettings = Core.settings(), rangeReady = true, lastFinal = null, filledSig = '', cancelledSig = '', applying = false;
  let aiPausedUntil = 0;
  const fillClock = new Core.Countdown();
  function fillStatus(message, error = false){ reportTrace.add('autocompletar',{message,error});const el = $('.fillStatus'); el.textContent = message; el.classList.toggle('error', error); }
  const current = ctx => ctx.runId === analysisSeq && ctx.url === location.href && ctx.signature === sig();
  function cancelFill(reason){ fillClock.cancel(reason); $('.fillCancel').hidden = true; }
  function selected(el){
    if(!el) return null;
    if('checked' in el) return el.checked;
    const aria = el.getAttribute('aria-checked') ?? el.getAttribute('aria-pressed') ?? el.getAttribute('aria-selected') ?? el.getAttribute('data-selected');
    if(aria !== null) return aria === 'true' || aria === '1';
    if(/\b(selected|checked|active)\b/.test(el.getAttribute('class') || '')) return true;
    return null;
  }
  function usable(el){ return el && el.isConnected && !el.disabled && el.getAttribute('aria-disabled') !== 'true' && !el.closest('fieldset[disabled]') && !own(el); }
  function clickAnswer(el){
    if(!shown(el)){const target=readable(el)?el:[...(el.labels||[])].find(readable);target?.scrollIntoView?.({block:'nearest',inline:'nearest',behavior:'instant'});}
    if(!usable(el) || (!readable(el) && ![...(el.labels || [])].some(readable))) throw new Error('Un control ha dejado de estar disponible.');
    if(el.tagName === 'A' || (el.form && el.type === 'submit')) throw new Error('Este control puede enviar o cambiar la actividad; selecciónalo tú.');
    const w = el.ownerDocument.defaultView, rect = el.getBoundingClientRect();
    const init = {bubbles: true, cancelable: true, composed: true, view: w, clientX: rect.left + rect.width / 2, clientY: rect.top + rect.height / 2, button: 0};
    if(w.PointerEvent)for(const type of ['pointerdown','pointerup'])el.dispatchEvent(new w.PointerEvent(type,{...init,pointerId:1,pointerType:'mouse',isPrimary:true,buttons:type==='pointerdown'?1:0}));
    for(const type of ['mousedown', 'mouseup']) el.dispatchEvent(new w.MouseEvent(type, {...init, buttons: type === 'mousedown' ? 1 : 0}));
    if(el.tagName === 'INPUT' && typeof el.click === 'function') el.click();
    else el.dispatchEvent(new w.MouseEvent('click', {...init, buttons: 0}));
  }
  function fieldValue(field, raw){
    const el = field.el; let value = String(raw).trim();
    if(field.numericReference){
      const number = Number(value.replace(',', '.'));
      if(!Number.isInteger(number) || number < 0 || number > 999) throw new Error('Esta pregunta pide el número de una etiqueta del dibujo.');
      value = String(number);
    }
    if(field.type === 'select'){
      const exact = field.options.filter(o => o.value === value);
      const byText = field.options.filter(o => Core.normalize(o.text) === Core.normalize(value));
      const matches = exact.length ? exact : byText;
      if(matches.length !== 1) throw new Error('El valor no coincide con una opción del desplegable.');
      value = matches[0].value;
    }
    if(field.type === 'number'){
      value = value.replace(',', '.');
      if(!/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?$/i.test(value) || !Number.isFinite(Number(value))) throw new Error('El campo numérico necesita un número, sin unidades.');
    }
    const probe = el.cloneNode(true); probe.value = value;
    if(probe.value !== value || (probe.checkValidity && !probe.checkValidity())) throw new Error('El valor no cumple el formato o los límites del campo.');
    return value;
  }
  function writeField(field, value){
    const el = field.el, w = el.ownerDocument.defaultView;
    if(!usable(el) || el.readOnly) throw new Error('El campo ya no es editable.');
    const proto = el.tagName === 'SELECT' ? w.HTMLSelectElement.prototype : el.tagName === 'TEXTAREA' ? w.HTMLTextAreaElement.prototype : w.HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, value);
    el.dispatchEvent(new w.Event('input', {bubbles: true, composed: true}));
    el.dispatchEvent(new w.Event('change', {bubbles: true, composed: true}));
    if(el.value !== value) throw new Error('Electude no ha aceptado el valor del campo.');
  }
  function prepareActions(plan, registry){
    return plan.actions.map(action => {
      const list = action.type === 'vf' ? registry.vfs : action.type === 'choice' ? registry.choices : registry.fields;
      const target = list.find(t => t.id === action.id);
      if(!target) throw new Error('La estructura de la pregunta ha cambiado. Vuelve a analizarla.');
      const conflict=()=>{throw new Error('La sugerencia cambiaría una respuesta que ya has introducido. Revisa la propuesta y decide qué conservar.');};
      if(action.type==='field'){
        const value=fieldValue(target,action.value);
        if(String(target.el.value??'').trim()&&String(target.el.value)!==value)conflict();
        return {...action,value};
      }
      if(action.type==='vf'&&vfSelection(target)!==null&&vfSelection(target)!==action.value)conflict();
      if(action.type==='choice'){
        if(action.value===false&&selected(target.el)===true)conflict();
        if(action.value===true&&target.kind==='radio'&&registry.choices.some(choice=>choice.id!==target.id&&choice.group===target.group&&selected(choice.el)===true))conflict();
      }
      const control = action.type === 'vf' ? (action.value ? target.yes : target.no) : target.click;
      if(!usable(control) || (action.type === 'choice' && !usable(target.el))) throw new Error('Hay un control de respuesta desactivado.');
      if(action.type === 'choice' && action.value === false && selected(target.el) === null) throw new Error('No puedo comprobar qué casillas están marcadas en este ejercicio.');
      return action;
    });
  }
  async function confirmVFSelections(actions, ctx){
    const registry = registryFor(activityBox());
    const pending = actions.filter(action => vfSelection(registry.vfs.find(row => row.id === action.id)) !== action.value);
    if(!pending.length) return;
    await new Promise(resolve => setTimeout(resolve, 100));
    if(!current(ctx) || cancelledSig === ctx.signature) throw new Error('Ha cambiado la actividad durante la comprobación.');
    const pairs = [];
    for(const action of actions){
      const row = registryFor(activityBox()).vfs.find(row => row.id === action.id); if(!row) throw new Error('Ha cambiado una afirmación.');
      if(vfSelection(row) === action.value) continue;
      const rect = el => { const r = el && topRect(el); return r && {left:r.left/innerWidth*1000,top:r.top/innerHeight*1000,width:r.width/innerWidth*1000,height:r.height/innerHeight*1000}; };
      pairs.push({id: row.id, no: rect(row.no), yes: rect(row.yes)});
    }
    if(!pairs.length) return;
    const view = {width:innerWidth,height:innerHeight,x:scrollX,y:scrollY};
    host.style.visibility = 'hidden';
    let result; try{ result = await send({type:'elecVerifyVF',pairs}); }finally{ host.style.visibility = ''; }
    if(!current(ctx) || cancelledSig === ctx.signature || view.width !== innerWidth || view.height !== innerHeight || view.x !== scrollX || view.y !== scrollY) throw new Error('La vista cambió; revisa las selecciones manualmente.');
    const failed = pairs.filter(pair => result?.rows?.find(row => row.id === pair.id)?.value !== actions.find(a => a.id === pair.id).value);
    if(result?.error || failed.length) throw new Error('No se ha confirmado la selección de ' + (failed.map(row => row.id).join(', ') || 'cierto/falso') + '. Revisa los botones antes de comprobar.');
  }
  async function confirmChoiceSelections(actions,ctx){
    const registry=registryFor(activityBox()),unknown=actions.filter(action=>selected(registry.choices.find(item=>item.id===action.id)?.el)===null);
    if(!unknown.length)return;
    const choices=unknown.map(action=>{const target=registry.choices.find(item=>item.id===action.id),r=topRect(target.el);return{id:action.id,rect:{left:r.left/innerWidth*1000,top:r.top/innerHeight*1000,width:r.width/innerWidth*1000,height:r.height/innerHeight*1000}};});
    const view=[innerWidth,innerHeight,scrollX,scrollY].join('|');host.style.visibility='hidden';
    let result;try{result=await send({type:'elecVerifyChoices',choices});}finally{host.style.visibility='';}
    if(!current(ctx)||cancelledSig===ctx.signature||view!==[innerWidth,innerHeight,scrollX,scrollY].join('|'))throw new Error('La vista cambió durante la comprobación del clic.');
    if(result?.error||unknown.some(action=>result?.rows?.find(row=>row.id===action.id)?.value!==action.value))throw new Error('Se ha enviado el clic, pero no se ha podido confirmar la opción marcada. Revisa la selección antes de comprobar.');
  }
  async function waitForSelection(action,ctx,initial){
    const end=Date.now()+1000;
    while(true){
      if(!current(ctx)||cancelledSig===ctx.signature||!fillSettings.enabled||document.hidden)throw new Error('Se ha cancelado la aplicación de esta respuesta.');
      const fresh=registryFor(activityBox());
      if(Core.structureKey(fresh)!==Core.structureKey(initial))throw new Error('Han cambiado los controles de la pregunta.');
      const target=(action.type==='vf'?fresh.vfs:fresh.choices).find(item=>item.id===action.id);
      const value=action.type==='vf'?vfSelection(target):selected(target?.el);
      if(value===action.value)return;
      if(value===null&&Date.now()>=end-700)return;
      if(Date.now()>=end)throw new Error('El clic en '+action.id+' no se ha reflejado en Electude. Revisa la selección; no se enviará otro clic a ciegas.');
      await new Promise(resolve=>setTimeout(resolve,50));
    }
  }
  async function applyAnswer(r, ctx){
    if(!fillSettings.enabled || !rangeReady || !Core.matchesMode(r, ctx.useMode) || document.hidden || !current(ctx) || cancelledSig === ctx.signature) return;
    const activeBox = activityBox();
    if(activityCompleted(activeBox, registryFor(activeBox))){ fillStatus('La pregunta ya está respondida. No se modifica.'); return; }
    if(applying||!await requirePermissions()||applying)return;
    if(!current(ctx)||activityCompleted(activityBox(),registryFor(activityBox())))return;
    let count = 0;
    try{
      const review = Core.assessVF(r.text, ctx.vfContext); if(!review.ok) throw new Error(review.reason);
      const registry = registryFor(activityBox()), plan = Core.plan(Core.parse(r.text), registry);
      if(!plan.ok) throw new Error(plan.reason);
      const actions = prepareActions(plan, registry);
      applying = true;
      for(const action of actions){
        if(!fillSettings.enabled || document.hidden || !current(ctx) || cancelledSig === ctx.signature) throw new Error('Ha cambiado la pregunta; se ha detenido el autocompletado.');
        // Resuelve de nuevo cada ID por si Electude ha recreado una fila al marcar otra.
        const fresh = registryFor(activityBox());
        if(Core.structureKey(fresh) !== Core.structureKey(registry)) throw new Error('La estructura de la actividad ha cambiado.');
        const list = action.type === 'vf' ? fresh.vfs : action.type === 'choice' ? fresh.choices : fresh.fields;
        const target = list.find(t => t.id === action.id);
        if(action.type === 'field'){if(String(target.el.value)!==action.value)writeField(target, action.value);}
        else if(action.type === 'vf'){
          const control = action.value ? target.yes : target.no;
          if(vfSelection(target) !== action.value) clickAnswer(control);
          await waitForSelection(action,ctx,registry);
        }else{
          if(selected(target.el) !== action.value) clickAnswer(target.click);
          await waitForSelection(action,ctx,registry);
        }
        count++;fillStatus('Aplicando respuesta: '+count+' de '+actions.length+' controles.');
      }
      if(registry.choices.length)await confirmChoiceSelections(actions.filter(action=>action.type==='choice'),ctx);
      if(registry.vfs.length) await confirmVFSelections(actions.filter(a => a.type === 'vf'), ctx);
      if(!current(ctx) || cancelledSig === ctx.signature || !fillSettings.enabled) throw new Error('Autocompletado cancelado durante la comprobación.');
      filledSig = ctx.signature;
      fillStatus('✓ Respuesta rellenada. Revisa la explicación y pulsa «Comprovar».');
    }catch(e){
      recordError('aplicarRespuesta', e); cancelledSig = ctx.signature;
      fillStatus((count ? 'Se han aplicado ' + count + ' controles. ' : '') + e.message, true);
    }finally{ applying = false; $('.fillCancel').hidden = true; }
  }
  function queueFill(r, ctx){
    if(ctx.provisional || !r || r.error || !current(ctx)) return;
    lastFinal = {r, ctx};
    if(!fillSettings.enabled || !rangeReady || document.hidden || filledSig === ctx.signature || cancelledSig === ctx.signature) return;
    cancelFill('replaced');
    const activeBox = activityBox();
    if(activityCompleted(activeBox, registryFor(activeBox))){ fillStatus('La pregunta ya está respondida. No se inicia otra cuenta atrás.'); return; }
    if(ctx.feedback || ctx.registry.fields.some(field => field.editable === false)){
      fillStatus('Esta pregunta ya está corregida o bloqueada. La sugerencia es para revisar; no se modifica el intento.');
      return;
    }
    if(ctx.requiresVision && !(ctx.shot && ctx.shot.dataUrl)){
      fillStatus('Necesito ver la imagen para identificar la pieza. No se rellenará sin captura.', true);
      return;
    }
    if(!Core.matchesMode(r, ctx.useMode)){
      fillStatus('La respuesta no corresponde al modo solicitado. Vuelve a analizar con el modo elegido.');
      return;
    }
    const review = Core.assessVF(r.text, ctx.vfContext);
    if(!review.ok){ fillStatus(review.reason, true); return; }
    const plan = Core.plan(Core.parse(r.text), ctx.registry);
    if(!plan.ok){ fillStatus(plan.reason, true); return; }
    $('.fillCancel').hidden = false;
    try{
      fillClock.start({delay: Core.delay(fillSettings), valid: () => fillSettings.enabled && rangeReady && !document.hidden && cancelledSig !== ctx.signature && current(ctx),
        onTick: left => fillStatus((ctx.useMode === 'fast' ? 'Respuesta rápida' : 'Respuesta precisa') + ' · clic automático en ' + left + ' s · intervalo ' + fillSettings.min + '–' + fillSettings.max + ' s.'),
        onCancel: reason => { $('.fillCancel').hidden = true; if(reason === 'stale') fillStatus('Autocompletado cancelado: cambió la pregunta o la pestaña.'); },
        run: () => applyAnswer(r, ctx)});
    }catch(error){
      recordError('autocompletar', error); cancelFill('error');
      fillStatus('No se ha podido iniciar el clic automático: ' + error.message + '. La sugerencia se conserva; pulsa Analizar para repetir.', true);
    }
  }
  function setFill(value, save){
    cancelFill('settings'); fillSettings = Core.settings(value); rangeReady = true;
    $('.fillToggle').setAttribute('aria-pressed', String(fillSettings.enabled));
    $('.fillToggle').textContent = 'Autocompletar: ' + (fillSettings.enabled ? 'ON' : 'OFF');
    $('.fillMin').value = fillSettings.min; $('.fillMax').value = fillSettings.max;
    fab.classList.toggle('auto', autoOn || fillSettings.enabled);
    fillStatus(fillSettings.enabled ? 'Activado · modo ' + (mode === 'fast' ? 'Rápido' : 'Preciso') + ' · clic automático entre ' + fillSettings.min + ' y ' + fillSettings.max + ' s después de su respuesta.' : 'Desactivado. Intervalo guardado: ' + fillSettings.min + '–' + fillSettings.max + ' s.');
    if(save) api.storage.local.set({elecFill: fillSettings}).catch(() => fillStatus('El ajuste está activo, pero no se ha podido guardar.', true));
    setMode(mode, false);
    if(fillSettings.enabled){ if(lastFinal && current(lastFinal.ctx)) queueFill(lastFinal.r, lastFinal.ctx); else scheduleAuto(300); }
  }
  $('.fillToggle').onclick = () => {
    const next = !fillSettings.enabled, r = Core.range($('.fillMin').value, $('.fillMax').value);
    if(next && r.error){ fillStatus(r.error, true); return; }
    cancelledSig = ''; filledSig = ''; setFill({...fillSettings, ...(r.error ? {} : r), enabled: next}, true);
  };
  const updateRange = () => {
    cancelFill('settings'); const r = Core.range($('.fillMin').value, $('.fillMax').value);
    rangeReady = !r.error;
    if(r.error){ fillStatus(r.error, true); return; }
    setFill({...fillSettings, ...r}, true);
  };
  for(const s of ['.fillMin', '.fillMax']) $(s).addEventListener('input', updateRange);
  $('.fillCancel').onclick = () => { cancelledSig = lastFinal ? lastFinal.ctx.signature : sig(); cancelFill('user'); fillStatus('Esta respuesta se ha cancelado. Puedes rellenarla tú o volver a analizarla.'); };
  api.storage.local.get('elecFill').then(r => setFill(r.elecFill)).catch(() => {});
  if(api.storage.onChanged) api.storage.onChanged.addListener((changes, area) => {
    if(area === 'local' && changes.ai){
      const before = Providers.cleanKeys(changes.ai.oldValue || {}), after = Providers.cleanKeys(changes.ai.newValue || {});
      if(JSON.stringify(before) !== JSON.stringify(after)){
        aiPausedUntil = 0;
        if(Object.keys(Providers.NAMES).some(p => Providers.hasKey(before, p))) cancelAnalysis();
        cancelFill('keys'); lastFinal = null; lastSig = ''; scheduleAuto(400);
      }
    }
    if(area === 'local' && changes.elecFill && JSON.stringify(Core.settings(changes.elecFill.newValue)) !== JSON.stringify(fillSettings)) setFill(changes.elecFill.newValue);
  });
  const hash = s => { let h = 5381; for(let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0; return (h >>> 0).toString(36) + s.length; };
  // respuestas guardadas: si vuelves a la misma pregunta, sale al instante
  async function cacheGet(k){ try{ const r = await api.storage.local.get('ansCache'); const c = (r && r.ansCache) || {}; return c[k]&&Date.now()-c[k].t<7*86400000 ? Object.assign({}, c[k].r) : null; }catch(e){ return null; } }
  async function cacheSet(k, v){ try{ const r = await api.storage.local.get('ansCache'); const c = (r && r.ansCache) || {}; c[k] = {t: Date.now(), r: {text: v.text, model: v.model, secs: v.secs, precise: v.precise === true,local:v.local===true}}; const ks = Object.keys(c).sort((a, b) => c[b].t - c[a].t); ks.slice(150).forEach(x => delete c[x]); await api.storage.local.set({ansCache: c}); }catch(e){} }
  function render(r, ctx){
    if(lastAttempt?.ctx===ctx)lastAttempt.result=r;
    const {vr, shot, single} = ctx;
    if(!current(ctx)) return;
    fab.title=r?.error?'Mi Estudio · revisa el error del análisis':'Mi Estudio · sugerencia disponible';
    answeredSig = ctx.signature;
    try{
      if(r && !r.error){
        r = {...r, text: Core.adaptFields(r.text, ctx.registry)};
        if(Core.repeatsRejected(r.text, ctx.rejected)) r = {error: 'Esta propuesta repite el valor que Electude ya marcó como incorrecto. No se ha aplicado.'};
      }
      if(!r || r.error){
        lastFinal = null; cancelFill('error');
        if(r && r.quota) aiPausedUntil = Math.max(aiPausedUntil, r.retryAt || Date.now() + 60000);
        if(fillSettings.enabled) fillStatus(r && r.quota ? 'Autocompletado en pausa por la cuota de IA. Revisa cuándo se podrá reintentar o cambia el proveedor en Ajustes.' : 'No se ha podido obtener una respuesta final. Revisa el error y vuelve a analizar.', true);
        out.innerHTML = `<div class="err">${esc(r && r.error || 'No se pudo contactar con la IA.')}</div>` + (r && r.nokey ? '<div class="row"><button class="sm" data-cl>✳ Preguntar en Claude</button><button class="sm" data-app>🔑 Añadir clave</button></div>' : '');
        const b = out.querySelector('[data-app]'); if(b) b.onclick = () => send({type: 'openApp'});
        const c = out.querySelector('[data-cl]'); if(c) c.onclick = () => send({type: 'openClaude', q: r.prompt || ''});
        if(r && r.needVision){
          out.insertAdjacentHTML('beforeend', '<div class="row"><button class="sm" data-shot>Abrir preparación de permisos</button></div>');
          out.querySelector('[data-shot]').onclick = () => send({type: 'askPerm'});
        }
        if(r && r.quota){
          out.insertAdjacentHTML('beforeend', '<div class="row"><button class="sm" data-quota-app>Ajustes de IA</button><a class="sm" href="https://aistudio.google.com/usage" target="_blank" rel="noopener">Ver uso en AI Studio</a></div>');
          out.querySelector('[data-quota-app]').onclick = () => send({type: 'openApp'});
          const usage = out.querySelector('a[href]'); if(usage && r.provider === 'openai'){ usage.href = 'https://platform.openai.com/usage'; usage.textContent = 'Ver uso en OpenAI'; } else if(usage && r.provider === 'claude'){ usage.href = 'https://console.anthropic.com/settings/limits'; usage.textContent = 'Ver límites de Claude'; } else if(usage && r.provider === 'groq'){ usage.href = 'https://console.groq.com/settings/limits'; usage.textContent = 'Ver límites de Groq'; } else if(usage && r.provider === 'openrouter'){ usage.href = 'https://openrouter.ai/activity'; usage.textContent = 'Ver uso de OpenRouter'; }
          if(r.retryAt) out.insertAdjacentHTML('beforeend', '<div class="note">Reintento a partir de: ' + esc(new Date(r.retryAt).toLocaleString('es-ES')) + '.</div>');
        }
        return;
      }
      const txt = Core.display(r.text, ctx.registry).replace(/^\s*CAJA\s*:.*$/gim,'').replace(/\*\*/g, '').trim();
      const analysis = (txt.match(/AN[AÁ]LISIS\s*:\s*([\s\S]*?)(?=^\s*(RESPUESTA|VF|CAMPO|PUNTO|ACCI[OÓ]N|FIABILIDAD|POR QU[EÉ])\s*:)/im) || [])[1];
      const body = analysis ? txt.slice(txt.indexOf(analysis) + analysis.length) : txt;
      const why = (body.match(/POR QU[EÉ]\s*:\s*([\s\S]+)/i) || [])[1];
      const parsed=Core.parse(r.text), answerRefs=parsed.answers;
      const answers = answerRefs.map(ref =>
        Core.resolve(ref,ctx.registry.choices)?.text || ref.text || ref.id
      ).filter(Boolean);
      const vfs = parsed.vfs.map(ref => ({id:ref.id,s:Core.resolve(ref,ctx.registry.vfs)?.text || ref.text,t:ref.value,why:ref.why}));
      const pins = Visual.parsePoints(body);
      const acts = [...body.matchAll(/^\s*ACCI[OÓ]N\s*:\s*(.+)$/gim)].map(m => m[1].trim());
      const fields = parsed.fields;
      clearMarks();
      if(single && vfs.length && !answers.length){ vfs.filter(v => v.t).forEach(v => answers.push(v.s)); vfs.length = 0; }
      let html = '', notes = [];
      if(vr.length >= 2 && vfs.length){
        const rowsN = vr.map(norm), ok = v => { const n = norm(v.s); return rowsN.some(r => r === n || (n.length > 5 && (r.includes(n) || n.includes(r)) && Math.min(n.length, r.length) / Math.max(n.length, r.length) > 0.8)); };
        const bad = vfs.filter(v => !ok(v));
        if(bad.length){ for(const b of bad) vfs.splice(vfs.indexOf(b), 1); notes.push('⚠️ La IA ha respondido ' + bad.length + ' frase(s) que no están en el recuadro gris; las he quitado.' + (vfs.length < vr.length ? ' Vuelve a pulsar Analizar con Mayús para repetir.' : '')); }
      }
      if(answers.length){
        const unmarked=answers.filter((answer,index)=>ctx.unmarked||!(mark(answerRefs[index]?.id||answer,ctx.registry)||
          markVisibleChoice(answer,curBox,ctx.manualQuiz)||
          (answers.length===1&&ctx.manualQuiz&&!parsed.lowConfidence&&screenshotChoice(r.text,ctx))));
        if(unmarked.length){
          html += `<details class="an"><summary>Ver ${unmarked.length===1?'sugerencia':'sugerencias'}</summary><ul>${unmarked.map(answer=>`<li>${esc(answer)}</li>`).join('')}</ul></details>`;
          if(!ctx.unmarked){
            reportTrace.add('superposicion',{encontradas:answers.length-unmarked.length,propuestas:answers.length});
            notes.push('No se pudo localizar alguna opción visible. Puedes enviar el informe del ejercicio.');
          }
        }else{
          html = '<div class="note">✓ Opción sugerida resaltada en Electude.</div>';
        }
      }
      if(vfs.length){
        const review = Core.assessVF(r.text, ctx.vfContext);
        if(!review.ok) notes.push(esc(review.reason));
        for(let i = 0; i < vfs.length; i++){ const proof = review.rows.find(p => p.id === vfs[i].id); if(proof) vfs[i].why += (proof.supported ? ' · Apoyo en la lección: «' + proof.quote + '».' : ' · Sin apoyo verificable en la lección.') + ' Confianza: ' + proof.confidence + '.'; }
        const unmarked = vfs.filter(v=>ctx.unmarked||!markVF(v.id||v.s,v.t,ctx.registry));
        const totalMarked = vfs.length-unmarked.length;
        if(totalMarked) html += `<div class="note">✓ Resaltadas ${totalMarked === vfs.length ? 'todas las afirmaciones' : totalMarked + ' de ' + vfs.length + ' afirmaciones'} en Electude.</div>`;
        html += `<details class="an"><summary>${unmarked.length?'Ver sugerencias':'Ver justificación'}</summary><ul>${vfs.map(v=>`<li><b>${v.t?'Cierto':'Falso'}</b> · ${esc(v.s)}${v.why?`<small class="vw">${esc(v.why)}</small>`:''}</li>`).join('')}</ul></details>`;
      }
      if(pins.length){
        if(!ctx.unmarked&&shot && shot.dataUrl && !parsed.lowConfidence){ const result = drawPins(pins, ctx); notes.push(result.mapped.length ? '📍 Los números están anclados a puntos detectados en el dibujo. Sigue el orden de la lista; la identificación de las piezas es una sugerencia de la IA.' : 'No se han podido vincular las respuestas a puntos detectados. No se colocaron marcas aproximadas.'); if(result.rejected.length) notes.push('Puntos sin ubicación validada: ' + result.rejected.join(', ') + '. Revisa esos componentes antes de hacer clic.'); } else if(parsed.lowConfidence) notes.push('La IA indica fiabilidad baja. No se colocaron marcas sobre el dibujo.');
        html += `<div class="ans"><div class="top">📍 ${pins.length > 1 ? 'Orden de clics en el dibujo' : 'Haz clic en el dibujo'}</div><div class="vf">${pins.map((p, i) => `<div class="vfr"><span class="pill v">${i + 1}</span><span>${esc(p.label || 'Punto señalado')}</span></div>`).join('')}</div></div>`;
      }
      if(acts.length) html += `<div class="ans"><div class="top">👆 Qué hacer</div><div class="vf">${acts.map(a => `<div class="vfr"><span>${esc(a)}</span></div>`).join('')}</div></div>`;
      if(fields.length) html += `<div class="ans"><div class="top">✍️ Valores sugeridos</div><div class="vf">${fields.map(f => `<div class="vfr"><span>${esc((ctx.registry.fields.find(t => t.id === f.id) || {}).text || f.id)}: <b>${esc(f.value)}</b></span></div>`).join('')}</div></div>`;
      if(why && html) html += `<details class="an"><summary>Por qué</summary><div>${esc(why.trim())}</div></details>`;
      if(ctx.manualQuiz&&!html)html='<div class="warn">La IA no ha devuelto una sugerencia concreta. Comprueba la pregunta en «Lectura del ejercicio» y vuelve a analizar si falta contexto.</div>';
      if(analysis && analysis.trim()) html += `<details class="an"><summary>🧠 Ver cómo lo ha razonado</summary><div>${esc(analysis.trim())}</div></details>`;
      out.innerHTML = html || `<div class="why">${esc(txt)}</div>`;
      (ctx.pre || []).forEach(n => notes.unshift(n));
      if(r.model) notes.push((r.cached ? '⚡ Respuesta guardada (ya la habías analizado) · ' : '') + 'Modelo: ' + esc(r.model) + (r.local ? ' (en tu ordenador)' : '') + (r.secs ? ' · ' + r.secs + ' s' : ''));
      notes.forEach(n => out.insertAdjacentHTML('beforeend', `<div class="note">${n}</div>`));
      if(ctx.requiresVision&&!(shot&&shot.dataUrl)){
        out.insertAdjacentHTML('beforeend', '<div class="warn"><span>📸 <b>La IA no ha podido ver la pantalla</b>, solo el texto. Para preguntas sobre el dibujo (hacer clic, localizar piezas) necesita verla.</span><button class="sm" data-perm>Revisar preparación de permisos</button><span>o pulsa una vez el icono de la extensión 🧩 en esta pestaña.</span></div>');
        const p = out.querySelector('[data-perm]'); if(p) p.onclick = () => send({type: 'askPerm'});
      }
      if(!ctx.provisional) queueFill(r, ctx);
    }catch(e){ recordError('render', e); out.innerHTML = `<div class="err">${esc(e.message)}</div>`; }
  }
  let curBox = null, answeredSig = '', analysisSeq = 0, analysisSig = '', activeAnalysis = 0;
  function cancelAnalysis(){
    if(busy && activeAnalysis) send({type: 'elecCancel', requestId: activeAnalysis});
    analysisSeq++; activeAnalysis = 0; busy = false; analysisSig = ''; host.style.visibility = '';
    go.disabled = false; go.textContent = '🔍 Analizar la pregunta';
  }
  let staleT = null;
  function checkStale(){
    if(staleT !== null) return;
    staleT = setTimeout(() => {
      staleT = null;
      if(!answeredSig && !analysisSig && !lastFinal) return;
      let s = ''; try{ s = sig(); }catch(e){ return; }
      const previous = analysisSig || answeredSig || (lastFinal && lastFinal.ctx.signature);
      if(s && s !== previous){
        if(busy && analysisSig){ cancelAnalysis(); lastSig = ''; scheduleAuto(100); }
        answeredSig = ''; lastFinal = null; cancelFill('stale'); clearMarks();
        fillStatus(fillSettings.enabled ? 'Ha cambiado la pregunta. Esperando su análisis…' : 'Autocompletar desactivado.');
        if(!autoOn && !fillSettings.enabled) out.innerHTML = '<div class="note">↪️ Ha cambiado la pregunta. Pulsa <b>🔍 Analizar la pregunta</b>.</div>';
      }
    }, 150);
  }
  async function analyze(force){
    if(busy || applying || document.hidden) return;
    if(force===true)reportPausedSig='';
    const initialBox = activityBox(), initialRegistry = registryFor(initialBox);
    if(activityCompleted(initialBox, initialRegistry)){
      cancelFill('completed'); clearMarks(); lastSig = sig();
      fillStatus('Pregunta ya respondida. Se omite el análisis para ahorrar cuota.');
      out.innerHTML = '<div class="note">✓ Esta respuesta ya está completada o corregida. No se ha consultado a la IA.</div>';
      return;
    }
    const pendingSignature=sig();
    if(!await requirePermissions(force===true)){if(force===true)pendingPermissionIntent=true;return;}
    if(busy||applying||document.hidden||pendingSignature!==sig())return;
    if(activityCompleted(initialBox,registryFor(initialBox)))return;
    busy = true; cancelFill('analysis'); lastFinal = null; filledSig = ''; cancelledSig = '';
    clearMarks(); answeredSig = '';
    const runId = ++analysisSeq, initialSig = sig(), requirePrecise = mode === 'precise';
    let useMode = mode;
    activeAnalysis = runId; analysisSig = initialSig; lastSig = initialSig;
    go.disabled = true; go.innerHTML = '<span class="spin"></span> Analizando…'; out.innerHTML = '';
    fab.title='Mi Estudio · analizando el ejercicio';
    if(fillSettings.enabled) fillStatus('Esperando la respuesta final de la IA…');
    let tick = null;
    try{
      curBox = activityBox();
      const registry = registryFor(curBox), vr = registry.vfs.map(v => v.text);
      const question = curBox ? visibleText(curBox) : pageText();
      const hasControls=Boolean(registry.choices.length||registry.vfs.length||registry.fields.length);
      const manualQuiz=!hasControls&&!registry.drawing ? Core.visibleQuiz(question) : '';
      renderReading(curBox,registry,question);
      lastAttempt={at:new Date().toISOString(),question,controls:reportRegistry(registry),ctx:null,result:null,rawResult:null,prompt:''};reportTrace.add('analizar',{modo:mode,controles:JSON.parse(Core.structureKey(registry))});
      const imageOption = curBox && [...curBox.querySelectorAll('img,canvas,svg')].some(el=>{
        if(!readable(el))return false;
        const rect=el.getBoundingClientRect();
        return rect.width>=90&&rect.height>=65;
      });
      const requiresVision = Core.needsVision(question)||!!registry.drawing||!!imageOption, feedback = activityFeedback(curBox);
      const rejected = feedback === 'incorrect' ? registry.fields.filter(field => String(field.el.value || '').trim()).map(field => ({id: field.id, value: String(field.el.value).slice(0, 100)})) : [];
      const settings = await api.storage.local.get('ai');
      const localConfig = await api.storage.local.get(['localEngine','ollamaModel']);
      if(runId!==analysisSeq || initialSig!==sig()) return;
      const vfSource = vr.length ? {question: vfQuestion(curBox, registry.vfs), rows: registry.vfs.map(({id,text}) => ({id,text})), theory: theoryContext(curBox)} : null;
      const packet = vfSource ? Core.vfPacket(vfSource, localOn&&useMode==='fast' ? (localConfig.localEngine==='chrome'?6000:10000) : Providers.provider(settings.ai || {}) === 'groq' ? 7500 : 15000) : null;
      const vfContext = vfSource ? {...vfSource, theory: packet.theory} : null;
      const ctx = {vr, vfContext, registry, single: registry.choices.length > 0 && !vr.length, signature: initialSig, runId, url: location.href, useMode, requirePrecise, requiresVision, manualQuiz:!!manualQuiz, feedback, rejected};
      if(lastAttempt)lastAttempt.ctx=ctx;
      // Las opciones dibujadas pueden no exponer texto ni controles HTML.
      const wantsImage = requiresVision || (Boolean(manualQuiz) && !(localOn&&useMode==='fast'&&localConfig.localEngine==='chrome'));
      const drawing = wantsImage ? collectDrawing() : null;
      let shot=null;
      if(drawing){
        ctx.viewport=drawing.viewport;
        if(manualQuiz){
          const surfaces=new Set(curBox?[curBox]:[]);
          for(const d of docs())for(const element of rootOf(d).querySelectorAll('canvas,svg,iframe')){
            if(!own(element)&&shown(element))surfaces.add(element);
          }
          ctx.choiceView={version:capturedViewVersion,surfaces:[...surfaces].map(el=>({el,rect:topRect(el)})).filter(({rect})=>rect&&rect.width>=150&&rect.height>=65)};
        }
        const captureScroll=[scrollX,scrollY];
        host.style.visibility='hidden';
        await new Promise(resolve=>setTimeout(resolve,100));
        if(!current(ctx)||document.hidden)return;
        shot=await send({type:'elecShot',viewport:drawing.viewport,regions:drawing.regions.map(({x,y,width,height})=>({x,y,width,height})),hotspots:drawing.hotspots.map(({x,y,label})=>({x,y,label}))});
        const sameView=innerWidth===drawing.viewport.width&&innerHeight===drawing.viewport.height&&scrollX===captureScroll[0]&&scrollY===captureScroll[1]&&drawing.regions.every(region=>region.el.isConnected&&Visual.sameRect(region.rect,topRect(region.el)));
        if(!sameView){
          if(requiresVision){render({error:'La vista cambió durante la captura. Mantén el dibujo quieto y vuelve a analizar.'},ctx);return;}
          shot=null;
        }
      }
      if(activeAnalysis === runId) host.style.visibility = ''; ctx.shot = shot;
      if(!current(ctx)) return;
      ctx.hotspots = drawing ? bindHotspotAnchors(shot?.hotspots||[],drawing) : [];
      const img = shot && shot.dataUrl || null;
      if(requiresVision && !img){
        render({error: 'Esta pregunta necesita una captura legible. Comprueba que Electude sea la pestaña activa y revisa la preparación de permisos antes de volver a analizar. No se ha consultado a la IA sin la imagen.', needVision: true}, ctx);
        return;
      }
      const state = '\n--- ESTADO DE LA ACTIVIDAD ---\n' + JSON.stringify({requiereImagen: requiresVision, estado: feedback, valoresYaIncorrectos: rejected}) + '\nSi hay valoresYaIncorrectos, descarta esa combinación; no copies el número ya escrito en el campo.\n';
      const hotspotPrompt = '\n--- PUNTOS DE CLIC DETECTADOS (H sobre la captura) ---\n' + JSON.stringify((ctx.hotspots || []).map(({id,x,y,label}) => ({id,x: Math.round(x),y: Math.round(y),label}))) + '\nPara localizar piezas usa PUNTO: nombre | id=Hn. Sin inventar coordenadas ni repetir IDs.\n';
      const manualPrompt = manualQuiz
        ? '--- PREGUNTA VISIBLE PARA RESPONDER A MANO ---\n'+manualQuiz.slice(0,6500)+'\n'+
          'Interpreta las opciones visibles del enunciado o de la captura. Después de RESPUESTA: copia el texto completo de la opción elegida tal como aparece, en el mismo idioma. Si la pregunta es abierta, escribe la respuesta directa. Justifica aparte con POR QUÉ. El inventario vacío indica que la extensión no puede hacer clic.\n'+
          (img&&ctx.choiceView?.surfaces.length?'Si ves claramente una única opción elegida en la captura, añade después de RESPUESTA una línea CAJA: x1,y1,x2,y2. Usa coordenadas enteras de 0 a 1000 relativas a la captura completa, con origen arriba a la izquierda. Delimita únicamente la fila elegida de la pregunta, desde su icono hasta el final de su texto. Omite CAJA si la opción no se ve completa, si hay varias respuestas o si la respuesta es abierta. Esta caja solo sirve para mostrar el resaltado.\n':'')+'\n'
        : '';
      const ptxt = packet ? packet.text : manualPrompt + registryPrompt(registry) + state + hotspotPrompt + pageText();
      if(lastAttempt?.ctx===ctx)lastAttempt.prompt=ptxt;
      const identity = Providers.fingerprint(JSON.stringify(Providers.cleanKeys(settings.ai || {})) + JSON.stringify({local:localOn&&useMode==='fast',...localConfig}));
      const key = (vr.length ? 'vf3_' : 'q8_') + hash(identity + '|' + location.href + '|' + ptxt + '|' + useMode + '|' + requirePrecise + '|' + (img ? hash(img) : 'text'));
      if(force !== true){ const c = await cacheGet(key); if(c){ render({...c, cached: true}, ctx); return; } }
      if(!current(ctx)) return;
      const useLocal=localOn&&useMode==='fast',t0=Date.now();
      tick=setInterval(()=>{if(runId===analysisSeq)go.innerHTML=`<span class="spin"></span> ${useLocal?'Respondiendo en tu ordenador':'Consultando tu API'}… ${Math.round((Date.now()-t0)/1000)} s`;},400);
      let result=await send({type:useLocal?'localAsk':'elecAsk',requestId:runId,vf:!!vfContext,text:ptxt,image:img,requiresVision,manualQuiz:!!manualQuiz,url:ctx.url,mode:useMode,requirePrecise});
      if(result?.error&&useLocal)result={...result,error:'IA local: '+result.error+' No se ha consultado la API. Pulsa Usar API en el apartado de IA local si quieres cambiar.'};
      if(lastAttempt?.ctx===ctx){lastAttempt.rawResult=result;lastAttempt.result=result;}
      if(!current(ctx)) return;
      if(activityCompleted(activityBox(), registryFor(activityBox()))){
        clearMarks(); fillStatus('Ya has respondido esta pregunta. No se aplicará la respuesta que estaba en curso.');
        return;
      }
      if(result && !result.error){
        result = {...result, text: Core.adaptFields(result.text, registry), secs: Math.round((Date.now() - t0) / 100) / 10};
        if(Core.repeatsRejected(result.text, rejected)) result = {error: 'La IA ha repetido un valor que Electude ya marcó como incorrecto. No se aplicó; revisa la imagen antes de repetir.'};
        else if(current(ctx)&&!Core.parse(result.text).lowConfidence&&Core.assessVF(result.text,vfContext).ok&&(registry.drawing||Core.plan(Core.parse(result.text),registry).ok)) cacheSet(key, result);
      }
      if(fillSettings.enabled) ctx.pre = ['Autocompletar utiliza el modo ' + (useMode === 'fast' ? 'Rápido' : 'Preciso') + ' seleccionado.'];
      render(result, ctx);
    }catch(e){ recordError('analizar', e); if(runId === analysisSeq && sig() === initialSig) out.innerHTML = `<div class="err">${esc(e.message)}</div>`; }
    finally{
      clearInterval(tick);
      if(activeAnalysis === runId){
        host.style.visibility = ''; busy = false; analysisSig = ''; activeAnalysis = 0;
        go.disabled = false; go.textContent = '🔍 Analizar la pregunta';
        if(autoOn || fillSettings.enabled){ if(sig() !== initialSig || runId !== analysisSeq){ lastSig = ''; scheduleAuto(100); } }
      }
    }
  }
  go.onclick = () => analyze(true);
  let mode = 'precise';
  const setMode = (m, save) => {
    mode = m === 'fast' ? 'fast' : 'precise';
    root.querySelectorAll('.mode button').forEach(b => {
      b.classList.toggle('on', b.dataset.m === mode);
      b.setAttribute('aria-pressed', String(b.dataset.m === mode));
      b.disabled = false;
      if(b.dataset.m === 'fast') b.title = 'Modelo ligero: más rápido, se equivoca más';
    });
    if(save){ api.storage.local.set({elecMode: mode}); cancelAnalysis(); cancelFill('mode'); lastFinal = null; lastSig = ''; scheduleAuto(300); }
  };
  root.querySelectorAll('.mode button').forEach(b => b.onclick = () => setMode(b.dataset.m, true));
  setMode('precise');
  try{ const g = api.storage.local.get('elecMode'); if(g && g.then) g.then(r => setMode(r.elecMode || 'precise')); else api.storage.local.get('elecMode', r => setMode(r.elecMode || 'precise')); }catch(e){}
  let updChecked = false;
  async function showUpdate(){
    if(updChecked) return; updChecked = true;
    const u = await send({type: 'checkUpdate'});
    if(u && u.newer){
      $('.upd').innerHTML = `<div class="warn"><span>🆕 <b>Hay una versión nueva de la extensión</b> (tienes la v${esc(u.mine)}, nueva v${esc(u.latest)}).</span><button class="sm" data-u>Cómo actualizarla</button></div>`;
      $('.upd [data-u]').onclick = () => send({type: 'openUpdate'});
      fab.title = 'Hay una versión nueva de la extensión';
    }
  }
  setTimeout(showUpdate, 1500);
  function reportRegistry(registry){
    const element=el=>el?{tag:el.tagName,type:el.type||'',role:el.getAttribute?.('role')||'',disabled:!!el.disabled,readOnly:!!el.readOnly}:null;
    return{choices:registry.choices.map(item=>({id:item.id,text:item.text,group:item.group,kind:item.kind,selected:selected(item.el),control:element(item.el)})),vfs:registry.vfs.map(item=>({id:item.id,text:item.text,binding:item.binding,selected:vfSelection(item),yes:element(item.yes),no:element(item.no)})),fields:registry.fields.map(item=>({id:item.id,text:item.text,type:item.type,value:String(item.el?.value??''),options:item.options,control:element(item.el)})),drawing:!!registry.drawing};
  }
  $('.reportError').onclick=async()=>{
    const button=$('.reportError'),status=$('.reportStatus');if(button.disabled)return;button.disabled=true;
    try{
      const box=activityBox(),signature=sig(),registry=registryFor(box),attempt=lastAttempt,ctx=attempt?.ctx,result=attempt?.result||{};
      const report={activity:{url:location.href,signature:hash(signature),question:box?visibleText(box):'',controls:reportRegistry(registry),feedback:activityFeedback(box),sameAsAnalysis:ctx?.signature===signature},analysis:{at:attempt?.at||null,question:attempt?.question||'',controls:attempt?.controls||{},prompt:attempt?.prompt||'',mode:ctx?.useMode||mode,provider:result.provider||apiSettings?.provider||'',model:result.model||'',local:result.local===true,cached:result.cached===true,pending:busy,rawText:attempt?.rawResult?.text||result.text||'',text:result.text||'',error:result.error||'',requiresVision:!!ctx?.requiresVision,viewport:ctx?.viewport||null,vfContext:ctx?.vfContext||null,hotspots:(ctx?.hotspots||[]).map(({id,x,y,label})=>({id,x,y,label}))},autofill:{...fillSettings,status:$('.fillStatus').textContent,filled:filledSig===signature,cancelled:cancelledSig===signature},lastError,events:reportTrace.list(),environment:{browser:navigator.userAgent,language:navigator.language,viewport:{width:innerWidth,height:innerHeight}}};
      reportPausedSig=signature;cancelledSig=signature;lastSig=signature;pendingPermissionIntent=null;cancelFill('report');cancelAnalysis();cancelCd();
      fillStatus('Informe abierto. La respuesta y el avance de este ejercicio quedan pausados.');
      status.textContent='Preparando informe para revisar…';
      const response=await send({type:'createErrorReport',report,analysisImage:ctx?.shot?.dataUrl||null});
      if(response?.error)throw new Error(response.error);
      status.textContent=response?.opened?'Informe abierto. Descárgalo y adjúntalo en este chat.':'No se pudo abrir el informe. Puedes usar Copiar diagnóstico.';
    }catch(error){recordError('informe',error);status.textContent='No se pudo preparar el informe: '+error.message;}
    finally{button.disabled=false;}
  };
  $('.diag').onclick = async ev => {
    ev.preventDefault();
    const D = docs(), path = el => { const p = []; for(let n = el, k = 0; n && k < 6 && n.tagName; n = n.parentElement || (n.getRootNode && n.getRootNode().host), k++) p.unshift(n.tagName.toLowerCase() + (n.id ? '#' + n.id : '') + (typeof n.className === 'string' && n.className ? '.' + n.className.trim().split(/\s+/).slice(0, 2).join('.') : '')); return p.join(' > '); };
    const ifr = [...document.querySelectorAll('iframe')].map(f => { let same = false; try{ same = !!f.contentDocument; }catch(e){} return (f.src || '').replace(/\?.*/, '').slice(0, 80) + (same ? ' (accesible)' : ' (otro origen)'); });
    const icons = []; for(const d of D) for(const el of rootOf(d).querySelectorAll('*')) if(isIconish(el) && !(el.closest && el.closest('#__msElecHost'))) icons.push(path(el));
    const info = {ultimoError: lastError, modo: mode, autocompletar: fillSettings.enabled, v: api.runtime.getManifest().version, url: location.href.replace(/\?.*/, ''), zonas: D.length, iframes: ifr, filasVF: vfRows(), iconos: icons.slice(0, 12), controles: JSON.parse(Core.structureKey(registryFor(activityBox()))),estado:$('.fillStatus').textContent,texto: pageText().slice(0, 1800)};
    const s = JSON.stringify(info, null, 1);
    try{ await navigator.clipboard.writeText(s); ev.target.textContent = '✅ Copiado: pégalo en el chat'; }catch(e){ out.innerHTML = '<div class="why" style="font-size:11px">' + esc(s) + '</div>'; }
  };
  // ---------- pasar a la siguiente después de que TÚ compruebes y salga «Correcte» ----------
  // No elige ni comprueba respuestas: solo pulsa la flecha de «siguiente» por ti.
  let nextOn = false, fbWas = false, cdTimer = null;
  const OKFB = /^\s*(correcte|correcto|correct|ben fet|molt bé|muy bien)\b/i;
  const visible = el => { const r = el.getBoundingClientRect(); const cs = el.ownerDocument.defaultView.getComputedStyle(el); return r.width > 0 && r.height > 0 && cs.visibility !== 'hidden' && cs.display !== 'none'; };
  const disabled = el => el.disabled || el.getAttribute('aria-disabled') === 'true' || /disabled|inactive/i.test(el.getAttribute('class') || '') || parseFloat(el.ownerDocument.defaultView.getComputedStyle(el).opacity) < 0.6;
  function okFeedback(){
    const box = activityBox(), registry = registryFor(box), rows = [...registry.choices.map(t => t.row), ...registry.vfs.map(t => t.row)];
    for(const d of docs()) for(const el of rootOf(d).querySelectorAll('div,p,span,section')){
      if(el.closest('#__msElecHost')) continue;
      if(rows.some(row => row === el || row.contains(el)) || el.closest('label,button,[role=radio],[role=checkbox]')) continue;
      if(box && !box.contains(el) && !el.closest('[role=status],[role=alert],[class*=feedback],[class*=result],[class*=success]')) continue;
      const t = (el.innerText || '').trim(); if(t.length > 400 || Core.feedback(t) !== 'correct') continue;
      if(shown(el)) return el;
    }
    return null;
  }
  function findNext(near){
    const all = [];
    for(const d of docs()) all.push(...d.querySelectorAll('button,a,[role=button],[onclick]'));
    const c = all.filter(el => !el.closest('#__msElecHost') && shown(el) && !disabled(el));
    const hint = el => ((el.getAttribute('aria-label') || '') + ' ' + (el.getAttribute('title') || '') + ' ' + (el.getAttribute('class') || '') + ' ' + (el.id || '') + ' ' + (el.innerText || '')).toLowerCase();
    const named = c.filter(el => /(next|seg[uü]ent|siguiente|endavant|forward|chevron-right|arrow-right|continua|continuar)/.test(hint(el)) && !/(prev|anterior|back|enrere|left)/.test(hint(el)));
    if(named.length) return named.sort((a, b) => b.getBoundingClientRect().left - a.getBoundingClientRect().left)[0];
    // flechas sin nombre: botones pequeños sin texto, debajo del recuadro de la respuesta; la de más a la derecha
    const nb = near ? near.getBoundingClientRect() : null;
    const icons = c.filter(el => { const r = el.getBoundingClientRect(); return !(el.innerText || '').trim() && r.width <= 70 && r.height <= 70 && (!nb || (r.top >= nb.top - 10 && r.top - nb.bottom < 200)); });
    if(icons.length >= 2) return icons.sort((a, b) => b.getBoundingClientRect().left - a.getBoundingClientRect().left)[0];
    return null;
  }
  function cancelCd(){ clearTimeout(cdTimer); cdTimer = null; $('.cd').classList.remove('on'); }
  $('.cdx').onclick = cancelCd;
  function startCd(fb){
    if(cdTimer !== null) return;
    const cd = $('.cd'), t = $('.cdt'), question = sig();
    t.textContent = '✅ Correcte · siguiente en 0,50 s'; cd.classList.add('on');
    cdTimer = setTimeout(() => {
      cancelCd();
      if(!permissionReady||!nextOn || document.hidden || sig() !== question || !okFeedback()) return;
      const nx = findNext(fb);
      if(nx) nx.click(); else { t.textContent = 'No encuentro el botón de siguiente: pásalo tú.'; cd.classList.add('on'); setTimeout(() => cd.classList.remove('on'), 2500); }
    }, 500);
  }
  function checkNext(){
    if(!permissionReady){cancelCd();return;}
    if(reportPausedSig&&reportPausedSig===sig()){cancelCd();return;}
    if(!nextOn) return;
    const fb = okFeedback(), now = !!fb;
    if(now && !fbWas) startCd(fb);
    if(!now && cdTimer) cancelCd();
    fbWas = now;
  }
  function setNext(v, save){ nextOn = v; $('.nextChk').checked = v; fbWas = !!okFeedback(); if(save) api.storage.local.set({elecNext: v}); if(!v) cancelCd(); }
  $('.nextChk').onchange = ev => setNext(ev.target.checked, true);
  try{ const g = api.storage.local.get('elecNext'); if(g && g.then) g.then(r => setNext(!!r.elecNext)); else api.storage.local.get('elecNext', r => setNext(!!r.elecNext)); }catch(e){}
  // ---------- modo automático: analiza solo cuando cambia el ejercicio ----------
  let autoOn = false, lastSig = '', busy = false;
  function navigationIdentity(box){
    const parts = [];
    for(const d of docs()) for(const el of rootOf(d).querySelectorAll('[aria-current],.active,.current,.selected,[aria-selected=true]')){
      if(own(el) || !shown(el)) continue;
      const text = (el.textContent || '').trim(), r = el.getBoundingClientRect();
      if(!/^\d{1,3}$/.test(text) || r.width > 48 || r.height > 48 || el.closest('label,[role=radio],[role=checkbox]')) continue;
      if(box&&box.contains(el)&&(el.closest('li,tr')||r.top>box.getBoundingClientRect().top+42))continue;
      parts.push(text + ':' + (el.getAttribute('aria-current') || el.className));
    }
    if(box){
      const br = box.getBoundingClientRect();
      let dot=0;for(const el of box.querySelectorAll('span,div,[role=tab]')){
        if(own(el) || !shown(el) || el.closest('label,li,tr,[role=radio],[role=checkbox]')) continue;
        const r = el.getBoundingClientRect(), text = (el.textContent || '').trim();
        if(r.width < 6 || r.width > 38 || r.height < 6 || r.height > 38 || r.top < br.top - 1 || r.bottom > br.top + 42 || text && !/^\d{1,3}$/.test(text)) continue;
        const css = el.ownerDocument.defaultView.getComputedStyle(el);
        if(parseFloat(css.borderRadius) < Math.min(r.width,r.height) * .4) continue;
        const color=(css.backgroundColor||'').match(/[\d.]+/g)?.map(Number)||[],active=el.getAttribute?.('aria-current')==='step'||el.getAttribute?.('aria-selected')==='true'||/\b(active|current)\b/.test(typeof el.className==='string'?el.className:'')||/purple/i.test(css.backgroundColor||'')||color.length>=3&&color[0]>color[1]+20&&color[2]>color[1]+20;
        if(active)parts.push('dot:'+dot+':'+text);dot++;
      }
    }
    return parts.join('|');
  }
  function sig(){
    const box = activityBox();
    const registry=registryFor(box),text = Core.questionText(box ? visibleText(box) : pageText()).replace(/[✗✕✖×✓✔]/g,'').replace(/\s+/g,' ').trim();
    return location.href + '|' + navigationIdentity(box) + '|' + text + '|' + Core.structureKey(registry);
  }

  let observedSig = '', stableSince = 0;
  function observeQuestion(){
    const signature = sig();
    if(signature !== observedSig){ observedSig = signature; stableSince = Date.now(); checkStale(); }
    return signature;
  }
  const autoScheduler = new Core.Scheduler(async () => {
    if((!autoOn && !fillSettings.enabled) || document.hidden || applying) return;
    const s = observeQuestion();if(reportPausedSig===s)return;
    if(busy){ autoScheduler.schedule(400); return; }
    if(Date.now() < aiPausedUntil) return;
    if(Date.now() - stableSince < 350){ autoScheduler.schedule(350 - (Date.now() - stableSince)); return; }
    const box = activityBox(), r = registryFor(box), hasControls = r.choices.length || r.vfs.length || r.fields.length;
    if(activityCompleted(box, r)){ lastSig = s; return; }
    if(!s || s === lastSig || !box || (!hasControls && !r.drawing && !Core.visibleQuiz(visibleText(box))) || okFeedback()) return;
    lastSig = s; await analyze();
  });
  function setAuto(v, save){
    autoOn = v; $('.autoChk').checked = v; fab.classList.toggle('auto', v || fillSettings.enabled);
    if(save) api.storage.local.set({elecAuto: v});
    if(v){ lastSig = ''; scheduleAuto(100); } else if(!fillSettings.enabled) autoScheduler.cancel();
  }
  function scheduleAuto(ms = 400){
    if(!autoOn && !fillSettings.enabled) return;
    autoScheduler.schedule(ms);
  }
  $('.autoChk').onchange = ev => setAuto(ev.target.checked, true);
  try{ const g = api.storage.local.get('elecAuto'); if(g && g.then) g.then(r => setAuto(!!r.elecAuto)); else api.storage.local.get('elecAuto', r => setAuto(!!r.elecAuto)); }catch(e){}
  const watched = new WeakSet(), linkedFrames = new WeakSet();
  function manualChange(event){
    if(!event.isTrusted || own(event.target) || !Core.editsAnswer(event)) return;
    const box=activityBox(),registry=registryFor(box);
    const targets=[...registry.choices.map(item=>item.row||item.el),...registry.vfs.map(item=>item.row),...registry.fields.map(item=>item.el)];
    const answerTarget=targets.some(target=>target&&(target===event.target||target.contains(event.target)));
    if(answerTarget){
      cancelledSig = sig(); cancelFill('user');
      if(fillSettings.enabled) fillStatus('Has intervenido en la respuesta. Autocompletado cancelado para este ejercicio; pulsa Analizar para reactivarlo.');
    }
  }
  const watch = d => {
    if(!d || watched.has(d)) return; watched.add(d);
    try{
      if(d!==document)d.addEventListener('scroll',invalidateCapturedView,true);
      for(const type of ['pointerdown', 'input', 'change', 'keydown']) d.addEventListener(type, manualChange, true);
      new MutationObserver(muts => {
        const relevant = muts.some(m => !own(m.target) && !(m.addedNodes.length && !m.removedNodes.length && [...m.addedNodes].every(n => n.nodeType === 1 && own(n))));
        if(!relevant) return;
        if(nextOn) checkNext();
        checkStale();
        if(muts.some(m => m.type === 'childList')) startWatch();
        if((autoOn || fillSettings.enabled) && !busy) scheduleAuto();
      }).observe(d.body || d.documentElement || d, {childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ['class', 'style', 'hidden', 'aria-hidden', 'src', 'aria-current', 'aria-selected', 'aria-checked', 'disabled', 'value']});
    }catch(e){}
  };
  const startWatch = () => {
    const all = docs(); all.forEach(watch);
    for(const d of all) for(const f of rootOf(d).querySelectorAll('iframe,frame')){
      if(linkedFrames.has(f)) continue; linkedFrames.add(f);
      f.addEventListener('load', () => { startWatch(); cancelFill('stale'); scheduleAuto(); });
    }
  };
  if(document.body) startWatch(); else document.addEventListener('DOMContentLoaded', startWatch);
  // El sondeo cubre cambios de página hechos con CSS, canvas o sin un nodo nuevo.
  setInterval(() => { if(document.hidden) return; try{ if(nextOn) checkNext(); if(autoOn || fillSettings.enabled){ observeQuestion(); scheduleAuto(100); } }catch(error){ recordError('observar', error); } }, 500);
  for(const event of ['popstate', 'hashchange']) window.addEventListener(event, () => { cancelFill('stale'); scheduleAuto(100); });
  document.addEventListener('visibilitychange', () => {
    if(document.hidden){ cancelFill('stale'); cancelCd(); }
    else {if(pendingPermissionIntent!==null){const intent=pendingPermissionIntent;pendingPermissionIntent=null;analyze(intent);}else{if(lastFinal)queueFill(lastFinal.r,lastFinal.ctx);scheduleAuto(600);}}
  });
  api.runtime.onMessage.addListener(m=>{
    if(m?.type==='MS_ELEC_OPEN'){open(true);if(m.analyze)analyze();}
    if(m?.type==='MS_PERMISSIONS_STATE'){
      permissionReady=m.ready===true;$('.setupNotice').hidden=permissionReady;
      if(!permissionReady){cancelFill('permissions');cancelAnalysis();cancelCd();fillStatus('Permisos retirados. Completa la preparación inicial antes de continuar.',true);}
      else if(!document.hidden){if(pendingPermissionIntent!==null){const intent=pendingPermissionIntent;pendingPermissionIntent=null;analyze(intent);}else{lastSig='';scheduleAuto(300);}}
    }
  });
  const mount = () => { if(!document.getElementById('__msElecHost')) (document.body || document.documentElement).appendChild(host); };
  if(document.body) mount(); else document.addEventListener('DOMContentLoaded', mount);
  new MutationObserver(() => { if(!host.isConnected) mount(); }).observe(document.documentElement, {childList: true, subtree: false});
})();
