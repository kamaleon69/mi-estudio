// Mi Estudio · Ayuda IA en Electude: panel lateral que analiza el enunciado visible y señala la opción que la IA cree correcta.
// No pulsa nada ni envía respuestas: solo muestra la sugerencia y la explicación. Tú decides qué marcar.
(() => {
  if(window.__msElec) return; window.__msElec = true;
  const api = (typeof browser !== 'undefined' && browser.runtime) ? browser : chrome;
  const host = document.createElement('div'); host.id = '__msElecHost';
  host.style.cssText = 'all:initial;position:fixed;z-index:2147483647;top:0;right:0;';
  const root = host.attachShadow({mode: 'open'});
  root.innerHTML = `<style>
    *{box-sizing:border-box;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif}
    .fab{position:fixed;right:16px;bottom:16px;width:52px;height:52px;border-radius:50%;border:0;background:#2563eb;color:#fff;font-size:24px;cursor:pointer;box-shadow:0 4px 14px rgba(0,0,0,.3)}
    .fab:hover{background:#1d4ed8}
    .panel{position:fixed;top:0;right:0;width:min(380px,100vw);height:100vh;background:#fff;color:#111827;border-left:1px solid #d1d5db;box-shadow:-6px 0 24px rgba(0,0,0,.18);display:none;flex-direction:column}
    .panel.on{display:flex}
    .h{display:flex;align-items:center;justify-content:space-between;padding:12px 14px;border-bottom:1px solid #e5e7eb;font-weight:700;font-size:15px}
    .x{border:1px solid #d1d5db;background:#fff;border-radius:8px;width:30px;height:30px;cursor:pointer;font-size:14px}
    .b{padding:14px;overflow:auto;flex:1;font-size:14px;line-height:1.5}
    .go{width:100%;padding:12px;border:0;border-radius:10px;background:#2563eb;color:#fff;font-size:15px;font-weight:600;cursor:pointer}
    .go:disabled{opacity:.6;cursor:wait}
    .ans{margin-top:14px;border:2px solid #22c55e;background:#f0fdf4;border-radius:10px;padding:10px 12px}
    .ans b{display:block;color:#15803d;margin-bottom:4px}
    .why{margin-top:10px;white-space:pre-wrap}
    .note{margin-top:12px;font-size:12.5px;color:#6b7280}
    .err{margin-top:14px;border:1px solid #fca5a5;background:#fef2f2;border-radius:10px;padding:10px 12px;color:#991b1b}
    .row{display:flex;gap:8px;margin-top:10px}
    .sm{flex:1;padding:8px;border:1px solid #d1d5db;background:#fff;border-radius:8px;cursor:pointer;font-size:13px}
    .spin{display:inline-block;width:14px;height:14px;border:2px solid #fff;border-top-color:transparent;border-radius:50%;animation:s .8s linear infinite;vertical-align:-2px;margin-right:6px}
    @keyframes s{to{transform:rotate(360deg)}}
  </style>
  <button class="fab" title="Ayuda IA (Mi Estudio)">💡</button>
  <div class="panel"><div class="h"><span>💡 Ayuda IA · Mi Estudio</span><button class="x" title="Cerrar">✕</button></div>
  <div class="b"><button class="go">🔍 Analizar la pregunta</button><div class="out"></div>
  <div class="note">La IA puede equivocarse: léete la explicación antes de marcar. La extensión no marca nada por ti.</div></div></div>`;
  const $ = s => root.querySelector(s);
  const panel = $('.panel'), fab = $('.fab'), go = $('.go'), out = $('.out');
  const open = v => { panel.classList.toggle('on', v); fab.style.display = v ? 'none' : ''; };
  fab.onclick = () => open(true);
  $('.x').onclick = () => { open(false); clearMarks(); };
  const esc = s => String(s).replace(/[&<>"]/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;'}[c]));

  // documentos accesibles (la página y sus iframes del mismo origen)
  function docs(d = document, acc = []){
    acc.push(d);
    for(const f of d.querySelectorAll('iframe,frame')){ try{ if(f.contentDocument && f.contentDocument.body) docs(f.contentDocument, acc); }catch(e){} }
    return acc;
  }
  function pageText(){
    let t = docs().map(d => { try{ return d.body.innerText; }catch(e){ return ''; } }).join('\n');
    return t.replace(/\n{3,}/g, '\n\n').trim().slice(0, 9000);
  }
  // marcas en la página
  let marks = [];
  function clearMarks(){ marks.forEach(([el, o, b]) => { el.style.outline = o; if(b) b.remove(); }); marks = []; }
  const norm = s => String(s).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/^[\s(]*([a-h]|\d{1,2})[).:\-]\s+/, '').replace(/[«»"'.,;:¿?¡!()]/g, '').replace(/\s+/g, ' ').trim();
  function mark(answer){
    const want = norm(answer); if(want.length < 1) return false;
    let best = null, bestLen = 1e9;
    for(const d of docs()){
      for(const el of d.body.querySelectorAll('label,li,td,button,span,div,p,a,option')){
        if(el.closest && el.closest('#__msElecHost')) continue;
        const r = el.getBoundingClientRect(); if(!r.width || !r.height) continue;
        const t = norm(el.innerText || ''); if(!t || t.length > want.length * 3 + 40) continue;
        if(t === want || (want.length > 3 && (t.includes(want) || (t.length > 3 && want.includes(t) && t.length > want.length * 0.6)))){
          if(t.length < bestLen || (t.length === bestLen && best && best.contains(el))){ best = el; bestLen = t.length; }
        }
      }
    }
    if(!best) return false;
    const target = best.closest('label,li,tr,button') || best;
    const badge = target.ownerDocument.createElement('span');
    badge.textContent = '💡 IA'; badge.style.cssText = 'all:initial;display:inline-block;margin-left:8px;padding:1px 7px;border-radius:9px;background:#22c55e;color:#fff;font:600 12px system-ui,sans-serif;vertical-align:middle';
    marks.push([target, target.style.outline, badge]);
    target.style.outline = '3px solid #22c55e'; target.appendChild(badge);
    target.scrollIntoView({block: 'center', behavior: 'smooth'});
    return true;
  }

  const send = m => new Promise(res => { try{ const p = api.runtime.sendMessage(m, r => res(r)); if(p && p.then) p.then(res, e => res({error: e.message})); }catch(e){ res({error: e.message}); } });
  async function analyze(){
    clearMarks(); go.disabled = true; go.innerHTML = '<span class="spin"></span> Analizando…'; out.innerHTML = '';
    try{
      host.style.visibility = 'hidden'; await new Promise(r => setTimeout(r, 120));
      const shot = await send({type: 'elecShot'});
      host.style.visibility = '';
      const r = await send({type: 'elecAsk', text: pageText(), image: shot && shot.dataUrl || null, url: location.href});
      if(!r || r.error){
        out.innerHTML = `<div class="err">${esc(r && r.error || 'No se pudo contactar con la IA.')}</div>` + (r && r.nokey ? '<div class="row"><button class="sm" data-app>Abrir Mi Estudio → Ajustes</button></div>' : '');
        const b = out.querySelector('[data-app]'); if(b) b.onclick = () => send({type: 'openApp'});
        return;
      }
      const txt = String(r.text || '').trim();
      const blocks = txt.split(/\n(?=\s*\**\s*RESPUESTA\s*\**\s*:)/i);
      let html = '', marked = 0;
      for(const bl of blocks){
        const a = bl.match(/RESPUESTA\s*\**\s*:\s*\**\s*([^\n]+)/i), w = bl.match(/POR QU[EÉ]\s*\**\s*:\s*\**\s*([\s\S]+)/i);
        if(a){ const ans = a[1].replace(/\*+/g, '').trim(); if(mark(ans)) marked++; html += `<div class="ans"><b>✅ Opción sugerida</b>${esc(ans)}${w ? `<div class="why">${esc(w[1].replace(/\*+/g, '').trim())}</div>` : ''}</div>`; }
        else if(bl.trim()) html += `<div class="why">${esc(bl.replace(/\*+/g, '').trim())}</div>`;
      }
      out.innerHTML = html || `<div class="why">${esc(txt)}</div>`;
      if(blocks.some(b => /RESPUESTA/i.test(b))) out.insertAdjacentHTML('beforeend', `<div class="note">${marked ? '🟩 He señalado en verde la opción en la página.' : 'No he encontrado la opción en la página para señalarla; mírala en el texto de arriba.'}</div>`);
      if(!(shot && shot.dataUrl)) out.insertAdjacentHTML('beforeend', '<div class="note">ℹ️ Solo he leído el texto. Para que la IA vea también la imagen (esquemas, fotos), pulsa una vez el icono de la extensión en esta pestaña y vuelve a analizar.</div>');
    }catch(e){ out.innerHTML = `<div class="err">${esc(e.message)}</div>`; }
    finally{ host.style.visibility = ''; go.disabled = false; go.textContent = '🔍 Analizar la pregunta'; }
  }
  go.onclick = analyze;
  api.runtime.onMessage.addListener(m => { if(m && m.type === 'MS_ELEC_OPEN'){ open(true); if(m.analyze) analyze(); } });
  const mount = () => { if(!document.getElementById('__msElecHost')) (document.body || document.documentElement).appendChild(host); };
  if(document.body) mount(); else document.addEventListener('DOMContentLoaded', mount);
  new MutationObserver(() => { if(!host.isConnected) mount(); }).observe(document.documentElement, {childList: true, subtree: false});
})();
