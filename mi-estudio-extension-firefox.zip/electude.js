// Mi Estudio · Tutor IA en Electude: panel lateral que te ayuda a ENTENDER el ejercicio sin darte la respuesta.
// - 💡 Pista (2 niveles): qué concepto trabaja, dónde mirar en la teoría y una pregunta para que razones.
// - 🤔 Si sale «Incorrecte»: qué confusión suele llevar a fallar y qué repasar (sin decir cuál es la buena).
// - 📘 Si sale «Correcte»: por qué es correcta, la idea clave y una pregunta parecida para practicar.
// No marca, no pulsa y no pasa ejercicios por ti.
(() => {
  if(window.__msElec) return; window.__msElec = true;
  const api = (typeof browser !== 'undefined' && browser.runtime) ? browser : chrome;
  const host = document.createElement('div'); host.id = '__msElecHost';
  host.style.cssText = 'all:initial;position:fixed;z-index:2147483647;top:0;right:0;';
  const root = host.attachShadow({mode: 'open'});
  root.innerHTML = `<style>
    *{box-sizing:border-box;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif}
    .fab{position:fixed;right:16px;bottom:16px;touch-action:none;width:52px;height:52px;border-radius:50%;border:0;background:#2563eb;color:#fff;font-size:24px;cursor:pointer;box-shadow:0 4px 14px rgba(0,0,0,.3)}
    .fab:hover{background:#1d4ed8}
    .panel{position:fixed;top:0;right:0;width:min(380px,100vw);height:100vh;background:#fff;color:#111827;border-left:1px solid #d1d5db;box-shadow:-6px 0 24px rgba(0,0,0,.18);display:none;flex-direction:column}
    .panel.on{display:flex}
    .h{display:flex;align-items:center;justify-content:space-between;padding:12px 14px;border-bottom:1px solid #e5e7eb;font-weight:700;font-size:15px}
    .x{border:1px solid #d1d5db;background:#fff;border-radius:8px;width:30px;height:30px;cursor:pointer;font-size:14px}
    .b{padding:14px;overflow:auto;flex:1;font-size:14px;line-height:1.5}
    .btn{width:100%;padding:12px;border:0;border-radius:10px;background:#2563eb;color:#fff;font-size:15px;font-weight:600;cursor:pointer;margin-top:8px}
    .btn.fail{background:#f59e0b} .btn.ok{background:#10b981}
    .btn:disabled{opacity:.6;cursor:wait}
    .btn[hidden]{display:none}
    .state{font-size:12.5px;color:#475569;margin-bottom:4px}
    .card{margin-top:14px;border-radius:14px;overflow:hidden;background:#fff;box-shadow:0 0 0 1px #c7d2fe,0 6px 18px rgba(37,99,235,.12)}
    .card .top{padding:8px 14px;background:linear-gradient(135deg,#3b82f6,#2563eb);color:#fff;font-size:12px;font-weight:700;letter-spacing:.06em;text-transform:uppercase}
    .card.fail{box-shadow:0 0 0 1px #fcd34d,0 6px 18px rgba(245,158,11,.15)} .card.fail .top{background:linear-gradient(135deg,#fbbf24,#f59e0b)}
    .card.ok{box-shadow:0 0 0 1px #6ee7b7,0 6px 18px rgba(16,185,129,.15)} .card.ok .top{background:linear-gradient(135deg,#10b981,#059669)}
    .sec{padding:10px 14px 0;white-space:pre-wrap}
    .sec:last-child{padding-bottom:12px}
    .sec i{display:block;font-style:normal;font-weight:700;font-size:11.5px;color:#64748b;text-transform:uppercase;letter-spacing:.05em;margin-bottom:2px}
    .sec.q{margin:10px 14px 12px;padding:10px 12px;border-radius:10px;background:#eff6ff;border:1px solid #93c5fd;color:#1e3a8a;font-weight:600}
    .sec.q i{color:#1d4ed8}
    .warn{margin-top:12px;padding:10px 12px;border-radius:10px;background:#fffbeb;border:1px solid #fcd34d;color:#78350f;font-size:13px;line-height:1.45;display:flex;flex-direction:column;gap:8px}
    .note{margin-top:12px;font-size:12.5px;color:#6b7280}
    .err{margin-top:14px;border:1px solid #fca5a5;background:#fef2f2;border-radius:10px;padding:10px 12px;color:#991b1b}
    .row{display:flex;gap:8px;margin-top:10px}
    .sm{flex:1;padding:8px;border:1px solid #d1d5db;background:#fff;border-radius:8px;cursor:pointer;font-size:13px}
    .warn .sm{background:#f59e0b;color:#fff;border:0;font-weight:700}
    .spin{display:inline-block;width:14px;height:14px;border:2px solid #fff;border-top-color:transparent;border-radius:50%;animation:s .8s linear infinite;vertical-align:-2px;margin-right:6px}
    @keyframes s{to{transform:rotate(360deg)}}
  </style>
  <button class="fab" title="Tutor IA (Mi Estudio) · arrástrame si tapo algo">💡</button>
  <div class="panel"><div class="h"><span>🎓 Tutor IA · Mi Estudio</span><button class="x" title="Cerrar">✕</button></div>
  <div class="b"><div class="upd"></div>
  <div class="state"></div>
  <button class="btn hint">💡 Dame una pista</button>
  <button class="btn fail" hidden>🤔 He fallado: ¿qué se me escapa?</button>
  <button class="btn ok" hidden>📘 Explícame por qué es correcta</button>
  <div class="out"></div>
  <div class="note">El tutor no te dice la respuesta: te ayuda a razonarla. Cuando aciertes, te explica el porqué para que se te quede.</div></div></div>`;
  const $ = s => root.querySelector(s);
  const panel = $('.panel'), fab = $('.fab'), out = $('.out'), state = $('.state');
  const bHint = $('.btn.hint'), bFail = $('.btn.fail'), bOk = $('.btn.ok');
  const open = v => { panel.classList.toggle('on', v); fab.style.display = v ? 'none' : ''; if(v) refresh(); };
  // botón movible (arrástralo si tapa algo de Electude); recuerda dónde lo dejas
  let drag = null, moved = false;
  const place = (x, y) => { x = Math.max(4, Math.min(innerWidth - 56, x)); y = Math.max(4, Math.min(innerHeight - 56, y)); fab.style.left = x + 'px'; fab.style.top = y + 'px'; fab.style.right = 'auto'; fab.style.bottom = 'auto'; };
  try{ const p = JSON.parse(localStorage.getItem('__msElecFab') || 'null'); if(p) place(p[0], p[1]); else fab.style.bottom = '90px'; }catch(e){ fab.style.bottom = '90px'; }
  fab.addEventListener('pointerdown', e => { const r = fab.getBoundingClientRect(); drag = [e.clientX - r.left, e.clientY - r.top, e.clientX, e.clientY]; moved = false; fab.setPointerCapture(e.pointerId); });
  fab.addEventListener('pointermove', e => { if(!drag) return; if(Math.abs(e.clientX - drag[2]) + Math.abs(e.clientY - drag[3]) > 6) moved = true; if(moved) place(e.clientX - drag[0], e.clientY - drag[1]); });
  fab.addEventListener('pointerup', () => { if(drag && moved){ const r = fab.getBoundingClientRect(); try{ localStorage.setItem('__msElecFab', JSON.stringify([r.left, r.top])); }catch(_){} } drag = null; });
  fab.onclick = () => { if(moved){ moved = false; return; } open(true); };
  $('.x').onclick = () => open(false);
  const esc = s => String(s).replace(/[&<>"]/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;'}[c]));

  // ---------- leer la página (la propia página, sus iframes del mismo origen y los shadow DOM abiertos) ----------
  function docs(d = document, acc = []){
    acc.push(d);
    const r = d.body || d;
    for(const el of r.querySelectorAll('*')){
      if(el.id === '__msElecHost') continue;
      if(el.shadowRoot) docs(el.shadowRoot, acc);
      if(el.tagName === 'IFRAME' || el.tagName === 'FRAME'){ try{ if(el.contentDocument && el.contentDocument.body) docs(el.contentDocument, acc); }catch(e){} }
    }
    return acc;
  }
  const rootOf = d => d.body || d;
  // ¿se ve de verdad en pantalla? (descarta los ejercicios anteriores que Electude deja escondidos o fuera del carrusel)
  function shown(el){
    if(!el || !el.getBoundingClientRect) return false;
    const w = (el.ownerDocument && el.ownerDocument.defaultView) || window, r = el.getBoundingClientRect();
    if(r.width < 2 || r.height < 2 || r.bottom < 0 || r.right < 0 || r.top > w.innerHeight || r.left > w.innerWidth) return false;
    try{ if(el.checkVisibility && !el.checkVisibility({opacityProperty: true, visibilityProperty: true})) return false; }catch(e){}
    for(let n = el.parentElement, k = 0; n && k < 15; n = n.parentElement, k++){
      const cs = w.getComputedStyle(n);
      if(cs.overflow !== 'visible' || cs.overflowX !== 'visible' || cs.overflowY !== 'visible'){
        const p = n.getBoundingClientRect();
        if(r.right <= p.left + 1 || r.left >= p.right - 1 || r.bottom <= p.top + 1 || r.top >= p.bottom - 1) return false;
      }
    }
    return true;
  }
  function visibleText(){
    const res = [], cache = new Map();
    const ok = el => { if(cache.has(el)) return cache.get(el); const v = shown(el); cache.set(el, v); return v; };
    for(const d of docs()){
      const r = rootOf(d), doc = d.ownerDocument || d;
      const tw = doc.createTreeWalker(r, NodeFilter.SHOW_TEXT);
      let lastBlock = null, line = '';
      for(let n = tw.nextNode(); n; n = tw.nextNode()){
        const t = n.textContent.replace(/\s+/g, ' '); if(!t.trim()) continue;
        const p = n.parentElement; if(!p || /^(SCRIPT|STYLE|NOSCRIPT)$/.test(p.tagName) || (p.closest && p.closest('#__msElecHost'))) continue;
        if(!ok(p)) continue;
        let b = p; while(b && b !== r && /^(inline|inline-block|contents)$/.test((doc.defaultView || window).getComputedStyle(b).display)) b = b.parentElement;
        if(b !== lastBlock){ if(line.trim()) res.push(line.trim()); line = ''; lastBlock = b; }
        line += t;
      }
      if(line.trim()) res.push(line.trim());
    }
    return res.join('\n');
  }
  const isIconish = el => { if(!el.getBoundingClientRect) return false; const r = el.getBoundingClientRect(); return r.width >= 10 && r.height >= 10 && r.width <= 50 && r.height <= 50 && Math.abs(r.width - r.height) < 14 && (el.innerText || el.textContent || '').trim().length <= 2; };
  function optionRow(el){
    let n = el;
    for(let k = 0; k < 5 && n && n.parentElement && n.tagName !== 'BODY'; k++, n = n.parentElement){
      const p = n.parentElement, sib = [...p.children].filter(c => c !== n && c.tagName === n.tagName && (c.className || '') === (n.className || '') && (c.innerText || '').trim());
      if(sib.length >= 1 && (n.innerText || '').trim().length < 300) return n;
    }
    return null;
  }
  function rowIcons(row){
    const all = [...row.querySelectorAll('*')].filter(x => isIconish(x) && shown(x));
    return all.filter(x => !all.some(y => y !== x && y.contains(x)));
  }
  function vfRowEls(){
    const rows = new Set();
    for(const d of docs()) for(const ic of rootOf(d).querySelectorAll('*')){
      if(!isIconish(ic) || (ic.closest && ic.closest('#__msElecHost'))) continue;
      const row = optionRow(ic); if(!row || rows.has(row)) continue;
      const t = (row.innerText || '').trim();
      if(rowIcons(row).length >= 2 && t.length >= 2 && t.length < 300 && shown(row)) rows.add(row);
    }
    return [...rows].filter(r => ![...rows].some(o => o !== r && o.contains(r)));
  }
  // el recuadro de la actividad (el gris con las opciones y el botón Comprovar)
  function activityBox(){
    const rows = vfRowEls(), btns = [];
    for(const d of docs()) for(const b of rootOf(d).querySelectorAll('button,a,[role=button],input[type=button],input[type=submit],div,span')){
      if(b.closest && b.closest('#__msElecHost')) continue;
      const t = (b.innerText || b.value || '').trim();
      if(t.length < 25 && /^(comprovar|comprobar|check|corregir|enviar|validar|submit)$/i.test(t) && b.children.length <= 2 && shown(b)) btns.push(b);
    }
    const seeds = btns.length ? btns : rows.slice(0, 1);
    for(const s of seeds){
      for(let n = s.parentElement, k = 0; n && k < 8; n = n.parentElement || (n.getRootNode && n.getRootNode().host), k++){
        const t = (n.innerText || '').trim();
        if(t.length > 20 && (rows.length < 2 || rows.every(r => n.contains(r))) && n.getBoundingClientRect().height > 60) return n;
      }
    }
    if(rows.length >= 2){ let n = rows[0].parentElement; while(n && !rows.every(r => n.contains(r))) n = n.parentElement; return n; }
    return null;
  }
  function pageText(){
    let t = ''; try{ t = visibleText(); }catch(e){}
    if(!t) t = docs().map(d => { try{ return d.body ? d.body.innerText : ''; }catch(e){ return ''; } }).join('\n');
    t = t.replace(/\n{3,}/g, '\n\n').trim();
    let box = null; try{ box = activityBox(); }catch(e){}
    const act = box ? (box.innerText || '').trim() : '';
    if(act && act.length > 10){
      const theory = t.split(act).join('').trim();
      return '--- TEORÍA ---\n' + theory.slice(0, 6000) + '\n\n--- ACTIVIDAD ACTIVA (el recuadro gris del ejercicio) ---\n' + act.slice(0, 2500);
    }
    return t.slice(0, 9000);
  }

  // ---------- estado del ejercicio: sin comprobar / «Correcte» / «Incorrecte» ----------
  const OKFB = /^\s*(correcte|correcto|correct|ben fet|molt bé|muy bien|resposta correcta|respuesta correcta)\b/i;
  const BADFB = /^\s*(incorrecte|incorrecto|incorrect|torna-ho a provar|vuelve a intentarlo|try again|no és correcte|no es correcto)\b/i;
  const FEED = /^(correcte|incorrecte|correcto|incorrecto|torna-ho a provar|vuelve a intentarlo|ben fet|molt bé|muy bien|resposta correcta|respuesta correcta)\b.*$/gim;
  function feedback(){
    for(const d of docs()) for(const el of rootOf(d).querySelectorAll('div,p,span,section')){
      if(el.closest('#__msElecHost')) continue;
      const t = (el.innerText || '').trim(); if(!t || t.length > 400) continue;
      if(BADFB.test(t) && shown(el)) return 'bad';
      if(OKFB.test(t) && shown(el)) return 'ok';
    }
    return '';
  }
  // firma de la pregunta (sin el texto de corrección), para saber cuándo cambia de ejercicio
  const sig = () => pageText().replace(FEED, '').replace(/\s+/g, ' ').trim();

  let curSig = '', level = 0, hints = [], busy = false;
  function refresh(){
    if(busy) return;
    let s = ''; try{ s = sig(); }catch(e){}
    if(s && s !== curSig){ curSig = s; level = 0; hints = []; out.innerHTML = ''; }
    const fb = feedback();
    bFail.hidden = fb !== 'bad';
    bOk.hidden = fb !== 'ok';
    bHint.hidden = fb === 'ok';
    bHint.textContent = level === 0 ? '💡 Dame una pista' : level === 1 ? '💡 Otra pista, más concreta' : '💡 Ya tienes todas las pistas';
    bHint.disabled = level >= 2;
    state.textContent = fb === 'ok' ? '✅ Has acertado este ejercicio.' : fb === 'bad' ? '❌ Esta vez no ha salido. Vamos a ver por qué.' : level ? `Pistas usadas: ${level} de 2` : 'Intenta responder tú primero. Si te atascas, pide una pista.';
  }

  // ---------- pedir ayuda al tutor ----------
  const send = m => new Promise(res => { try{ const p = api.runtime.sendMessage(m, r => res(r)); if(p && p.then) p.then(res, e => res({error: e.message})); }catch(e){ res({error: e.message}); } });
  // red de seguridad: si la IA se le escapa la solución en una pista, se quita esa frase
  const LEAK = /(la (respuesta|opci[oó]n) (correcta|buena|que (debes|tienes que|hay que) (marcar|elegir))|la correcta es|la buena es|(debes|tienes que|hay que) marcar|marca (la|el|las|los) |es (verdadera|falsa)\b|son (verdaderas|falsas)\b|=>\s*[VF]\b|\b(RESPUESTA|VF|PUNTO)\s*:)/i;
  function scrub(txt){
    let cut = 0;
    const clean = txt.split('\n').map(line => line.split(/(?<=[.!?])\s+/).filter(sn => { if(LEAK.test(sn)){ cut++; return false; } return true; }).join(' ')).join('\n');
    return {clean, cut};
  }
  const LABELS = ['CONCEPTO', 'DÓNDE MIRAR', 'RAZONA ASÍ', 'ERROR TÍPICO', 'REPASA', 'EXPLICACIÓN', 'RECUERDA', 'PREGUNTA', 'PARA PRACTICAR'];
  function sections(txt){
    const re = new RegExp('^\\s*(' + LABELS.join('|') + ')\\s*:\\s*', 'gim');
    const res = []; let m, last = null;
    while((m = re.exec(txt))){ if(last) last.body = txt.slice(last.end, m.index).trim(); last = {label: m[1].toUpperCase(), end: re.lastIndex}; res.push(last); }
    if(last) last.body = txt.slice(last.end).trim();
    return res.filter(s => s.body);
  }
  function render(r, stage, shot){
    if(!r || r.error){
      out.innerHTML = `<div class="err">${esc(r && r.error || 'No se pudo contactar con la IA.')}</div>` + (r && r.nokey ? '<div class="row"><button class="sm" data-cl>✳ Preguntar en Claude</button><button class="sm" data-app>🔑 Añadir clave</button></div>' : '');
      const b = out.querySelector('[data-app]'); if(b) b.onclick = () => send({type: 'openApp'});
      const c = out.querySelector('[data-cl]'); if(c) c.onclick = () => send({type: 'openClaude', q: r.prompt || ''});
      return false;
    }
    let txt = String(r.text || '').replace(/\*\*/g, '').trim(), cut = 0;
    if(stage !== 'repaso'){ const s = scrub(txt); txt = s.clean; cut = s.cut; }
    const secs = sections(txt);
    const title = stage === 'repaso' ? '📘 Por qué es correcta' : stage === 'fallo' ? '🤔 Qué se te puede estar escapando' : `💡 Pista ${level + 1} de 2`;
    const body = secs.length ? secs.map(s => `<div class="sec${/PREGUNTA|PARA PRACTICAR/.test(s.label) ? ' q' : ''}"><i>${esc(s.label.toLowerCase())}</i>${esc(s.body)}</div>`).join('') : `<div class="sec">${esc(txt)}</div>`;
    out.insertAdjacentHTML('afterbegin', `<div class="card ${stage === 'repaso' ? 'ok' : stage === 'fallo' ? 'fail' : ''}"><div class="top">${title}</div>${body}</div>`);
    if(cut) out.insertAdjacentHTML('afterbegin', '<div class="note">✂️ He quitado una frase de la pista porque daba la respuesta directamente.</div>');
    if(!(shot && shot.dataUrl) && !out.querySelector('[data-perm]')){
      out.insertAdjacentHTML('beforeend', '<div class="warn"><span>📸 <b>El tutor no ha podido ver la pantalla</b>, solo el texto. Para ejercicios con dibujos necesita verla.</span><button class="sm" data-perm>Permitir que vea la pantalla de Electude</button></div>');
      out.querySelector('[data-perm]').onclick = () => send({type: 'askPerm'});
    }
    if(r.model) out.insertAdjacentHTML('beforeend', `<div class="note">Modelo: ${esc(r.model)}</div>`);
    return true;
  }
  async function ask(stage){
    if(busy) return; refresh();
    busy = true;
    const btn = stage === 'repaso' ? bOk : stage === 'fallo' ? bFail : bHint, label = btn.textContent;
    [bHint, bFail, bOk].forEach(b => b.disabled = true);
    btn.innerHTML = '<span class="spin"></span> Pensando…';
    try{
      host.style.visibility = 'hidden'; await new Promise(r => setTimeout(r, 150));
      const shot = await send({type: 'elecShot'});
      host.style.visibility = '';
      const r = await send({type: 'elecAsk', stage, level: level + 1, prev: hints.slice(-2), text: pageText(), image: shot && shot.dataUrl || null});
      const ok = render(r, stage, shot);
      if(ok && stage === 'pista'){ hints.push(String(r.text || '').slice(0, 600)); level++; }
    }catch(e){ out.innerHTML = `<div class="err">${esc(e.message)}</div>`; }
    finally{ host.style.visibility = ''; busy = false; btn.textContent = label; [bHint, bFail, bOk].forEach(b => b.disabled = false); refresh(); }
  }
  bHint.onclick = () => ask('pista');
  bFail.onclick = () => ask('fallo');
  bOk.onclick = () => ask('repaso');

  // ---------- aviso de versión nueva ----------
  setTimeout(async () => {
    const u = await send({type: 'checkUpdate'});
    if(u && u.newer){
      $('.upd').innerHTML = `<div class="warn"><span>🆕 <b>Hay una versión nueva de la extensión</b> (tienes la v${esc(u.mine)}, nueva v${esc(u.latest)}).</span><button class="sm" data-u>Cómo actualizarla</button></div>`;
      $('.upd [data-u]').onclick = () => send({type: 'openUpdate'});
    }
  }, 1500);

  // ---------- vigilar cambios de ejercicio y de corrección (solo actualiza el panel, nunca pulsa nada) ----------
  let refT = null;
  const later = () => { if(!panel.classList.contains('on')) return; clearTimeout(refT); refT = setTimeout(refresh, 500); };
  const watch = d => { try{ new MutationObserver(later).observe(d.body || d.documentElement, {childList: true, subtree: true, characterData: true}); }catch(e){} };
  const startWatch = () => { docs().forEach(watch); document.querySelectorAll('iframe').forEach(f => f.addEventListener('load', () => { try{ watch(f.contentDocument); }catch(e){} later(); })); };
  if(document.body) startWatch(); else document.addEventListener('DOMContentLoaded', startWatch);
  api.runtime.onMessage.addListener(m => { if(m && m.type === 'MS_ELEC_OPEN') open(true); });
  const mount = () => { if(!document.getElementById('__msElecHost')) (document.body || document.documentElement).appendChild(host); };
  if(document.body) mount(); else document.addEventListener('DOMContentLoaded', mount);
  new MutationObserver(() => { if(!host.isConnected) mount(); }).observe(document.documentElement, {childList: true, subtree: false});
})();
